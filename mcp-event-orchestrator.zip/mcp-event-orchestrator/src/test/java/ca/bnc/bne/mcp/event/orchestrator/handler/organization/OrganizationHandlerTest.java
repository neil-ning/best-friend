package ca.bnc.bne.mcp.event.orchestrator.handler.organization;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import ca.bnc.bne.mcp.event.orchestrator.exception.model.AddSystemKeyException;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventAction;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventAction.BusinessObjectEnum;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventAction.TechnicalActionEnum;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventInformation;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventInformation.PartyActionEnum;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventInformation.PartyTypeEnum;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.PartyKey;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.Address;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.BasicInfo;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.Contact;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.OrganizationInput;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.OrganizationResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.StandardResponse;
import ca.bnc.bne.mcp.event.orchestrator.handler.EventTargetSystem;
import ca.bnc.bne.mcp.event.orchestrator.mapper.EventMapper;
import ca.bnc.bne.mcp.event.orchestrator.mapper.organization.OrganizationMapper;
import ca.bnc.bne.mcp.event.orchestrator.mapper.organization.OrganizationMapperImpl;
import ca.bnc.bne.mcp.event.orchestrator.service.bne.BneService;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@Disabled
public class OrganizationHandlerTest {

  @InjectMocks
  private OrganizationEventHandler organizationEventHandler;

  @Mock
  private BneService bneService;

  @Mock
  private EventMapper eventMapper;

  @Mock
  private OrganizationMapper organizationMapper;

  @BeforeEach
  void init() {
    MockitoAnnotations.initMocks(this);
    organizationEventHandler.setOrganizationMapper((OrganizationMapper) (new OrganizationMapperImpl()));
  }

  @Test
  public void testBuildOrganizationInputWithGcc() {
    StepVerifier.create(
        organizationEventHandler.buildOrganizationInputWithGccId(
            List.of("gcc1", "gcc2"), new OrganizationInput()))
                .expectNext(
                    new OrganizationInput().orgSystemId("gcc1"), new OrganizationInput().orgSystemId("gcc2"))
                .verifyComplete();
  }

  @Test
  public void testBuildOrganizationInputWithGcc_EmptyList() {
    Flux<OrganizationInput> flux =
        organizationEventHandler.buildOrganizationInputWithGccId(
            new ArrayList<>(), new OrganizationInput());
    StepVerifier.create(flux).expectNext(new OrganizationInput()).verifyComplete();
  }

  @Test
  public void testBuildOrganizationInputWithNewOrgBncId() {
    StepVerifier.create(
        organizationEventHandler.buildOrganizationInputWithNewOrgBncId(
            List.of("newBnc1", "newBnc2"), new OrganizationInput()))
                .expectNext(
                    new OrganizationInput().newOrgBncId("newBnc1"),
                    new OrganizationInput().newOrgBncId("newBnc2"))
                .verifyComplete();
  }

  @Test
  public void testBuildOrganizationInputWithNewOrgBnc_EmptyList() {
    Flux<OrganizationInput> flux =
        organizationEventHandler.buildOrganizationInputWithNewOrgBncId(
            new ArrayList<>(), new OrganizationInput());
    StepVerifier.create(flux).expectNext(new OrganizationInput()).verifyComplete();
  }

  @Test
  public void testBuildOrganizationRequest() {
    Mono<OrganizationInput> input1 =
        Mono.just(new OrganizationInput().basicInfo(new BasicInfo().nomCIE("legal"))).log();

    Mono<OrganizationInput> input2 =
        Mono.just(new OrganizationInput().address(new Address().rue("street"))).log();

    Mono<OrganizationInput> requestMono =
        organizationEventHandler.buildOrganizationRequest(List.of(input1, input2)).log();
    StepVerifier.create(requestMono)
                .expectNext(
                    new OrganizationInput()
                        .basicInfo(new BasicInfo().nomCIE("legal"))
                        .address(new Address().rue("street")))
                .verifyComplete();
  }

  @Test
  public void testAddGccSystemKeyToMcp_NoGccReturned() {
    Mono<StandardResponse> standardResponseMono =
        organizationEventHandler.addGccSystemKeyToMcp(
            "message", "bnce", new OrganizationResponse(), EventTargetSystem.GCC.label);
    StepVerifier.create(standardResponseMono)
                .expectNextMatches(
                    standardResponse -> standardResponse.getReturnStatusCode().equalsIgnoreCase("200"))
                .verifyComplete();
  }

  @Test
  public void testAddGccSystemKeyToMcp_GccReturned() {
    when(eventMapper.addNewGccIdToMcpSystemKeys(any(), anyString(), anyString(),any()))
        .thenReturn(Mono.just(new StandardResponse().returnStatusMessage("testMsg")));
    Mono<StandardResponse> standardResponseMono =
        organizationEventHandler.addGccSystemKeyToMcp(
            "message", "bnce", new OrganizationResponse().systemId("gcc"), EventTargetSystem.GCC.label);
    StepVerifier.create(standardResponseMono)
                .expectNextMatches(
                    standardResponse ->
                        standardResponse.getReturnStatusMessage().equalsIgnoreCase("testMsg"))
                .verifyComplete();
  }

  @Test
  public void testAddGccSystemKeyToMcp_Error() {
    when(eventMapper.addNewGccIdToMcpSystemKeys(any(), anyString(), anyString(), any()))
        .thenReturn(Mono.error(() -> new AddSystemKeyException("test")));
    Mono<StandardResponse> standardResponseMono =
        organizationEventHandler.addGccSystemKeyToMcp(
            "message", "bnce", new OrganizationResponse().systemId("gcc"), EventTargetSystem.GCC.label);
    StepVerifier.create(standardResponseMono).expectError(AddSystemKeyException.class).verify();
  }

  @Test
  public void testDeleteOrgSystemKey() {
    when(eventMapper.organizationFccFlux(anyString(), anyString()))
        .thenReturn(
            Flux.just(
                new OrganizationInput().noFcc("fcc1"), new OrganizationInput().noFcc("fcc2")));

    when(bneService.deleteOrganization(any(), any())).thenReturn(Mono.just(new OrganizationResponse()));

    PartyKey partyKey =
        new PartyKey()
            .bncId("bnc")
            .memberIds(List.of("gcc1", "gcc2"))
            .partyRole(PartyKey.PartyRoleEnum.MERGEE)
            .mergeInformation(List.of("merge1"));
    Mono<Void> message =
        organizationEventHandler.invoke(
            buildRequest(
                BusinessObjectEnum.SYSTEMKEY,
                partyKey,
                TechnicalActionEnum.DELETE,
                PartyActionEnum.MERGE,
                "message",
                EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(message).expectComplete().verify();
  }

  @Test
  public void testDeleteOrganizationContact() {
    when(eventMapper.organizationContactMono(anyString(), anyString()))
        .thenReturn(
            Mono.just(
                new OrganizationInput()
                    .contact(new Contact().email("email").fax("fax").phone("phone"))));
    when(bneService.deleteOrganization(any(), any()))
        .thenReturn(Mono.just(new OrganizationResponse().status(200).message("message")));

    PartyKey partyKey =
        new PartyKey()
            .bncId("bnc")
            .partyRole(PartyKey.PartyRoleEnum.MERGEE)
            .memberIds(List.of("gcc1", "gcc2"))
            .mergeInformation(List.of("merge1", "merge2"));
    Mono<Void> message =
        organizationEventHandler.invoke(
            buildRequest(
                BusinessObjectEnum.PTYCTCMETH,
                partyKey,
                TechnicalActionEnum.DELETE,
                PartyActionEnum.MERGE,
                "message",
                EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(message).expectComplete().verify();
  }

  @Test
  public void testDeleteOrganizationAddress() {
    when(eventMapper.organizationAddressMono(anyString(), anyString()))
        .thenReturn(
            Mono.just(
                new OrganizationInput().address(new Address().rue("rue").ceProvinceEtat("prov"))));
    when(bneService.deleteOrganization(any(), any()))
        .thenReturn(Mono.just(new OrganizationResponse().status(200).message("message")));

    PartyKey partyKey =
        new PartyKey()
            .bncId("bnc")
            .partyRole(PartyKey.PartyRoleEnum.MERGEE)
            .memberIds(List.of("gcc1", "gcc2"))
            .mergeInformation(List.of("merge1", "merge2"));
    Mono<Void> message =
        organizationEventHandler.invoke(
            buildRequest(
                BusinessObjectEnum.PTYADDR,
                partyKey,
                TechnicalActionEnum.DELETE,
                PartyActionEnum.MERGE,
                "message",
                EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(message).expectComplete().verify();
  }

  @Test
  public void testDeleteBaseOrg() {
    when(eventMapper.baseOrganizationMono(anyString(), anyString()))
        .thenReturn(
            Mono.just(
                new OrganizationInput()
                    .basicInfo(new BasicInfo().langue(BasicInfo.LangueEnum.EN).nomCIE("name"))));
    when(eventMapper.organizationAddressMono(any(), anyString()))
        .thenReturn(
            Mono.just(
                new OrganizationInput()
                    .basicInfo(new BasicInfo().langue(BasicInfo.LangueEnum.EN).nomCIE("name"))));
    when(eventMapper.organizationContactMono(anyString(), anyString()))
        .thenReturn(
            Mono.just(
                new OrganizationInput()
                    .basicInfo(new BasicInfo().langue(BasicInfo.LangueEnum.EN).nomCIE("name"))));
    when(bneService.deleteOrganization(any(), any()))
        .thenReturn(Mono.just(new OrganizationResponse().status(200).message("message")));

    PartyKey partyKey =
        new PartyKey()
            .bncId("bnc")
            .partyRole(PartyKey.PartyRoleEnum.MERGEE)
            .memberIds(List.of("gcc1", "gcc2"))
            .mergeInformation(List.of("merge1", "merge2"));
    Mono<Void> message =
        organizationEventHandler.invoke(
            buildRequest(
                BusinessObjectEnum.BASEORG,
                partyKey,
                TechnicalActionEnum.DELETE,
                PartyActionEnum.MERGE,
                "message",
                EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(message).expectComplete().verify();
  }

  @Test
  public void testUpdateSystemKey() {
    when(eventMapper.organizationFccFlux(anyString(), anyString()))
        .thenReturn(
            Flux.just(
                new OrganizationInput().noFcc("fcc1"), new OrganizationInput().noFcc("fcc2")));

    when(bneService.updateOrganization(any(), any()))
        .thenReturn(Mono.just(new OrganizationResponse().systemId("newGcc").status(200)));

    when(eventMapper.addNewGccIdToMcpSystemKeys(any(), anyString(), anyString(), any()))
        .thenReturn(Mono.just(new StandardResponse().returnStatusCode("0")));

    PartyKey partyKey =
        new PartyKey()
            .bncId("bnc")
            .memberIds(List.of("gcc1", "gcc2"))
            .partyRole(PartyKey.PartyRoleEnum.MERGEE)
            .mergeInformation(List.of("merge1"));

    Mono<Void> message =
        organizationEventHandler.invoke(
            buildRequest(
                BusinessObjectEnum.SYSTEMKEY,
                partyKey,
                TechnicalActionEnum.UPDATE,
                PartyActionEnum.EDIT,
                "message",
                EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(message).expectComplete().verify();
  }

  @Test
  public void testUpdateOrgContact() {
    when(eventMapper.organizationContactMono(anyString(), anyString()))
        .thenReturn(
            Mono.just(
                new OrganizationInput()
                    .contact(new Contact().email("email").fax("fax").phone("phone"))));
    when(bneService.updateOrganization(any(), any()))
        .thenReturn(Mono.just(new OrganizationResponse().status(200).message("message")));

    PartyKey partyKey =
        new PartyKey()
            .bncId("bnc")
            .partyRole(PartyKey.PartyRoleEnum.EDITEE)
            .memberIds(List.of("gcc1", "gcc2"));
    Mono<Void> message =
        organizationEventHandler.invoke(
            buildRequest(
                BusinessObjectEnum.PTYCTCMETH,
                partyKey,
                TechnicalActionEnum.UPDATE,
                PartyActionEnum.EDIT,
                "message",
                EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(message).expectComplete().verify();
  }

  @Test
  public void testUpdateOrgAddress() {
    when(eventMapper.organizationAddressMono(anyString(), anyString()))
        .thenReturn(
            Mono.just(
                new OrganizationInput().address(new Address().rue("rue").ceProvinceEtat("prov"))));
    when(bneService.updateOrganization(any(), any()))
        .thenReturn(Mono.just(new OrganizationResponse().status(200).message("message")));

    PartyKey partyKey =
        new PartyKey()
            .bncId("bnc")
            .partyRole(PartyKey.PartyRoleEnum.MERGER)
            .memberIds(List.of("gcc1", "gcc2"));
    Mono<Void> message =
        organizationEventHandler.invoke(
            buildRequest(
                BusinessObjectEnum.PTYADDR,
                partyKey,
                TechnicalActionEnum.UPDATE,
                PartyActionEnum.EDIT,
                "message",
                EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(message).expectComplete().verify();
  }

  @Test
  public void testUpdateBaseOrg() {
    when(eventMapper.baseOrganizationMono(anyString(), anyString()))
        .thenReturn(
            Mono.just(
                new OrganizationInput()
                    .basicInfo(new BasicInfo().langue(BasicInfo.LangueEnum.EN).nomCIE("name"))));
    when(eventMapper.organizationAddressMono(anyString(), anyString()))
        .thenReturn(
            Mono.just(
                new OrganizationInput()
                    .basicInfo(new BasicInfo().langue(BasicInfo.LangueEnum.EN).nomCIE("name"))));
    when(eventMapper.organizationContactMono(anyString(), anyString()))
        .thenReturn(
            Mono.just(
                new OrganizationInput()
                    .basicInfo(new BasicInfo().langue(BasicInfo.LangueEnum.EN).nomCIE("name"))));
    when(bneService.updateOrganization(any(), any()))
        .thenReturn(Mono.just(new OrganizationResponse().status(200).message("message")));

    PartyKey partyKey =
        new PartyKey()
            .bncId("bnc")
            .partyRole(PartyKey.PartyRoleEnum.UNMERGER)
            .memberIds(List.of("gcc1", "gcc2"));
    Mono<Void> message =
        organizationEventHandler.invoke(
            buildRequest(
                BusinessObjectEnum.BASEORG,
                partyKey,
                TechnicalActionEnum.UPDATE,
                PartyActionEnum.EDIT,
                "message",
                EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(message).expectComplete().verify();
  }

  @Test
  public void testCreateSystemKey() {
    when(eventMapper.organizationFccFlux(anyString(), anyString()))
        .thenReturn(
            Flux.just(
                new OrganizationInput().noFcc("fcc1"), new OrganizationInput().noFcc("fcc2")));

    when(bneService.createOrganization(any(), any()))
        .thenReturn(Mono.just(new OrganizationResponse().systemId("newGcc").status(200)));

    when(eventMapper.addNewGccIdToMcpSystemKeys(any(), anyString(), anyString(), any()))
        .thenReturn(Mono.just(new StandardResponse().returnStatusCode("0")));

    PartyKey partyKey =
        new PartyKey()
            .bncId("bnc")
            .memberIds(List.of("gcc1", "gcc2"))
            .partyRole(PartyKey.PartyRoleEnum.MERGEE)
            .mergeInformation(List.of("merge1"));
    Mono<Void> message =
        organizationEventHandler.invoke(
            buildRequest(
                BusinessObjectEnum.SYSTEMKEY,
                partyKey,
                TechnicalActionEnum.CREATE,
                PartyActionEnum.EDIT,
                "message",
                EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(message).expectComplete().verify();
  }

  @Test
  public void testCreateOrgContact() {
    when(eventMapper.organizationContactMono(anyString(), anyString()))
        .thenReturn(
            Mono.just(
                new OrganizationInput()
                    .contact(new Contact().email("email").fax("fax").phone("phone"))));
    when(bneService.createOrganization(any(), any()))
        .thenReturn(Mono.just(new OrganizationResponse().status(200).message("message")));

    PartyKey partyKey =
        new PartyKey()
            .bncId("bnc")
            .partyRole(PartyKey.PartyRoleEnum.EDITEE)
            .memberIds(List.of("gcc1", "gcc2"));
    Mono<Void> message =
        organizationEventHandler.invoke(
            buildRequest(
                BusinessObjectEnum.PTYCTCMETH,
                partyKey,
                TechnicalActionEnum.CREATE,
                PartyActionEnum.EDIT,
                "message",
                EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(message).expectComplete().verify();
  }

  @Test
  public void testCreateOrgAddress() {
    when(eventMapper.organizationAddressMono(anyString(), anyString()))
        .thenReturn(
            Mono.just(
                new OrganizationInput().address(new Address().rue("rue").ceProvinceEtat("prov"))));
    when(bneService.createOrganization(any(), any()))
        .thenReturn(Mono.just(new OrganizationResponse().status(200).message("message")));

    PartyKey partyKey =
        new PartyKey()
            .bncId("bnc")
            .partyRole(PartyKey.PartyRoleEnum.EDITEE)
            .memberIds(List.of("gcc1", "gcc2"));
    Mono<Void> message =
        organizationEventHandler.invoke(
            buildRequest(
                BusinessObjectEnum.PTYADDR,
                partyKey,
                TechnicalActionEnum.CREATE,
                PartyActionEnum.EDIT,
                "message",
                EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(message).expectComplete().verify();
  }

  @Test
  public void testCreateBaseOrg() {
    when(eventMapper.baseOrganizationMono(anyString(), anyString()))
        .thenReturn(
            Mono.just(
                new OrganizationInput()
                    .basicInfo(new BasicInfo().langue(BasicInfo.LangueEnum.EN).nomCIE("name"))));
    when(eventMapper.organizationAddressMono(anyString(), anyString()))
        .thenReturn(
            Mono.just(
                new OrganizationInput()
                    .basicInfo(new BasicInfo().langue(BasicInfo.LangueEnum.EN).nomCIE("name"))));
    when(eventMapper.organizationContactMono(anyString(), anyString()))
        .thenReturn(
            Mono.just(
                new OrganizationInput()
                    .basicInfo(new BasicInfo().langue(BasicInfo.LangueEnum.EN).nomCIE("name"))));

    when(bneService.createOrganization(any(), any()))
        .thenReturn(
            Mono.just(new OrganizationResponse().status(200).message("message").systemId("gcc")));
    when(eventMapper.addNewGccIdToMcpSystemKeys(any(), anyString(), anyString(), any()))
        .thenReturn(Mono.just(new StandardResponse().returnStatusCode("0")));

    PartyKey partyKey = new PartyKey().bncId("bnc").partyRole(PartyKey.PartyRoleEnum.UNMERGEE);

    Mono<Void> message =
        organizationEventHandler.invoke(
            buildRequest(
                BusinessObjectEnum.BASEORG,
                partyKey,
                TechnicalActionEnum.CREATE,
                PartyActionEnum.EDIT,
                "message",
                EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(message).expectComplete().verify();
  }

  private EventRequest buildRequest(
      BusinessObjectEnum bo,
      PartyKey partyKey,
      TechnicalActionEnum ta,
      PartyActionEnum pa,
      String messageId,
      EventRequest.TargetSystemEnum targetSystem) {

    return new EventRequest()
        .messageId(messageId)
        .eventInformation(
            new EventInformation()
                .partyKey(partyKey)
                .eventAction(new EventAction().technicalAction(ta).businessObject(bo))
                .partyAction(pa)
                .partyType(PartyTypeEnum.I)).targetSystem(targetSystem);
  }
}
