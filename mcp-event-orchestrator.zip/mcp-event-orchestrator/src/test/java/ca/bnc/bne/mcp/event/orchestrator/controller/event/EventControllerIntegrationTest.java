package ca.bnc.bne.mcp.event.orchestrator.controller.event;

import ca.bnc.bne.mcp.event.orchestrator.dto.okta.OktaResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.IndividualResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.Profile;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.socioDemo.GetIndividualSocioDemographicsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.socioDemo.SocioDemographicKeyRessource;
import ca.bnc.bne.mcp.event.orchestrator.mapper.EventMapper;
import ca.bnc.bne.mcp.event.orchestrator.restassured.McpEventHandleRestAssuredTests;
import ca.bnc.bne.mcp.event.orchestrator.service.bne.BneService;
import ca.bnc.bne.mcp.event.orchestrator.service.mcp.McpService;
import ca.bnc.bne.mcp.event.orchestrator.service.okta.OktaService;
import ca.bnc.bne.mcp.event.orchestrator.util.JsonFileUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.RestAssured;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.net.URISyntaxException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

/**
 * There are 2 options to create SpringBootTest Tests using RestAssured.
 *      io.restassured.module.webtestclient.RestAssuredWebTestClient
 *      io.restassured.RestAssured
 * io.restassured.RestAssured is selected so we could reuse the same rest assured tests specification for both integration and end to end testing.
 */

@Disabled("TODO : fixed it")
@ActiveProfiles("mock-webserver")
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, properties = "spring.main.web-application-type=reactive")
@AutoConfigureWebTestClient(timeout = "2000")
public class EventControllerIntegrationTest {
    @Autowired
    private EventMapper eventMapper;

    @Autowired
    private McpService mcpService;

    @MockBean
    private OktaService oktaService;

    @MockBean
    private BneService bneService;

    private MockWebServer mockWebServer;

    @Autowired
    WebTestClient webTestClient;

    @LocalServerPort
    private int port;

    @Value("${mock.webserver.port}")
    private int mockServerPort;

    private ObjectMapper objectMapper = new ObjectMapper();

    private McpEventHandleRestAssuredTests mcpEventHandleRestAssuredTests;

    @BeforeEach
    public  void setup() throws IOException {
        System.out.println("Setting up test");
        mockWebServer = new MockWebServer();
        mockWebServer.start(mockServerPort);

        RestAssured.baseURI = "http://localhost:" + this.port;
        mcpEventHandleRestAssuredTests = new McpEventHandleRestAssuredTests();
    }

    @AfterEach
    void tearDown() throws IOException {
        System.out.println("Tearing down test");
        mockWebServer.shutdown();
    }

    @Test
    public void testEditIndividual() throws IOException, URISyntaxException {
        specifyMocksEditIndividual();
        mcpEventHandleRestAssuredTests.testEditIndividual();
    }

    @Test
    public void testEditIndividualFromFile() throws IOException, URISyntaxException {
        specifyMocksEditIndividual();
        mcpEventHandleRestAssuredTests.testEditIndividualFromFile();
    }

    private void specifyMocksEditIndividual() throws IOException, URISyntaxException {
        when(oktaService.cacheToken("GCC")).thenReturn(Mono.just(new OktaResponse().accessToken("fake")));

        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(200)
                .addHeader("Content-Type", "application/json; charset=utf-8")
                .setBody(JsonFileUtil.writeString(new GetIndividualSocioDemographicsResponse().
                socioDemographic(new SocioDemographicKeyRessource().
                        genderCd(Profile.SexEnum._0.toString())))));

        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(200)
                .addHeader("Content-Type", "application/json; charset=utf-8")
                .setBody(JsonFileUtil.readString("service/mcp/get-individual-socio-resp.json")));

        when(bneService.createIndividual(any(), anyString())).thenReturn(Mono.just(new IndividualResponse().code(200).message("Success")));

        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(200)
                .addHeader("Content-Type", "application/json; charset=utf-8")
                .setBody(JsonFileUtil.readString("service/mcp/add-system-key-resp.json")));
        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(200)
                .addHeader("Content-Type", "application/json; charset=utf-8")
                .setBody(JsonFileUtil.readString("service/mcp/add-system-key-resp.json")));

        eventMapper.startUp(); // Cache octa token
    }
}
