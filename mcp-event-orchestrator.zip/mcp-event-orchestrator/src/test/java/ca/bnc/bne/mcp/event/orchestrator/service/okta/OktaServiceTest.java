package ca.bnc.bne.mcp.event.orchestrator.service.okta;

import ca.bnc.bne.mcp.event.orchestrator.dto.okta.OktaResponse;
import ca.bnc.bne.mcp.event.orchestrator.exception.model.OktaTokenException;
import java.io.IOException;

import javax.net.ssl.SSLException;

import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

public class OktaServiceTest {

  private MockWebServer mockWebServer;
  private OktaService oktaService;

  @BeforeEach
  void setUp() throws IOException {
    mockWebServer = new MockWebServer();
    mockWebServer.start();
  }

  @AfterEach
  void tearDown() throws IOException {
    mockWebServer.shutdown();
  }

  @BeforeEach
  void initialize() throws SSLException {
    String baseUrl = String.format("http://localhost:%s", mockWebServer.getPort());
    oktaService = new OktaService(baseUrl, "username", "password", "username1", "password1");
    oktaService.setGccContextPath("/");
  }

  @Test
  void testPostOktaToken_HappyPath() {
    MockResponse mockResponse =
        new MockResponse()
            .setBody(
                "{\"token_type\":\"Bearer\",\"expires_in\":3600,\"access_token\":\"token\",\"scope\":\"scope\"}")
            .setResponseCode(200)
            .addHeader("Content-Type", "application/json; charset=utf-8");

    mockWebServer.enqueue(mockResponse);
    Mono<OktaResponse> oktaResponseMono = oktaService.postOktaAccessToken("GCC");

    StepVerifier.create(oktaResponseMono)
                .expectNextMatches(oktaResponse -> oktaResponse.getAccessToken().equalsIgnoreCase("token"))
                .verifyComplete();
  }

  @Test
  void testPostOktaToken_Error() {
    MockResponse mockResponse =
        new MockResponse()
            .setBody(
                "{\"error\":\"invalid_scope\",\"error_description\":\"One or more scopes are not configured for the authorization server resource.\"}")
            .setResponseCode(400)
            .addHeader("Content-Type", "application/json; charset=utf-8");

    mockWebServer.enqueue(mockResponse);
    mockWebServer.enqueue(mockResponse);
    mockWebServer.enqueue(mockResponse);
    mockWebServer.enqueue(mockResponse);

    StepVerifier.create(oktaService.postOktaAccessToken("GCC"))
                .expectError(OktaTokenException.class)
                .verify();
  }

  @Test
  void testPostOktaToken_Cache() {
    MockResponse mockResponse =
        new MockResponse()
            .setBody(
                "{\"token_type\":\"Bearer\",\"expires_in\":3600,\"access_token\":\"token\",\"scope\":\"scope\"}")
            .setResponseCode(200)
            .addHeader("Content-Type", "application/json; charset=utf-8");

    mockWebServer.enqueue(mockResponse);

    Mono<OktaResponse> oktaResponseMono = oktaService.cacheToken("GCC");
    oktaResponseMono.subscribe(); // first call to cache value

    StepVerifier.create(oktaResponseMono)
                .expectNextMatches(r -> r.getAccessToken().equalsIgnoreCase("token"))
                .verifyComplete();
  }
}
