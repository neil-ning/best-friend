package ca.bnc.bne.mcp.event.orchestrator.controller.event;

import ca.bnc.bne.mcp.event.orchestrator.dto.okta.OktaResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.IndividualResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.Profile;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.socioDemo.GetIndividualSocioDemographicsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.socioDemo.SocioDemographicKeyRessource;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.StandardResponse;
import ca.bnc.bne.mcp.event.orchestrator.mapper.EventMapper;
import ca.bnc.bne.mcp.event.orchestrator.restassured.McpEventHandleRestAssuredTests;
import ca.bnc.bne.mcp.event.orchestrator.service.bne.BneService;
import ca.bnc.bne.mcp.event.orchestrator.service.mcp.McpService;
import ca.bnc.bne.mcp.event.orchestrator.service.okta.OktaService;
import io.restassured.RestAssured;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.time.LocalDateTime;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

/**
 * There are 2 options to create SpringBootTest Tests using RestAssured.
 *      io.restassured.module.webtestclient.RestAssuredWebTestClient
 *      io.restassured.RestAssured
 * io.restassured.RestAssured is selected so we could reuse the same rest assured tests specification for both integration and end to end testing.
 */

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, properties = "spring.main.web-application-type=reactive")
@AutoConfigureWebTestClient(timeout = "2000")
public class EventControllerTest {
    @Autowired
    private EventMapper eventMapper;

    @MockBean
    private OktaService oktaService;

    @MockBean
    private McpService mcpService;

    @MockBean
    private BneService bneService;

    @Autowired
    WebTestClient webTestClient;

    @LocalServerPort
    private int port;

    private McpEventHandleRestAssuredTests mcpEventHandleRestAssuredTests;

    @BeforeEach
    public  void setup(){
        RestAssured.baseURI = "http://localhost:" + this.port;
        mcpEventHandleRestAssuredTests = new McpEventHandleRestAssuredTests();
    }

    @Test
    public void testEditIndividual() throws IOException {
        specifyMocksEditIndividual();
        mcpEventHandleRestAssuredTests.testEditIndividual();
    }

    @Test
    public void testEditIndividualFromFile() throws IOException {
        specifyMocksEditIndividual();
        mcpEventHandleRestAssuredTests.testEditIndividualFromFile();
    }

    private void specifyMocksEditIndividual() {
        when(oktaService.cacheToken("GCC")).thenReturn(Mono.just(new OktaResponse().accessToken("fake")));
        when(mcpService.getSocioDemoMono(any(), any())).thenReturn(Mono.just(new GetIndividualSocioDemographicsResponse().
                socioDemographic(new SocioDemographicKeyRessource().
                        genderCd(Profile.SexEnum._0.toString()))));
        when(bneService.createIndividual(any(), anyString())).thenReturn(Mono.just(new IndividualResponse().code(200).message("Success")));
        when(mcpService.postSystemKeysByBncId(any(), any(), any())).thenReturn(Mono.just(new StandardResponse()
                .returnStatusCode("200")
                .returnDate(LocalDateTime.now().toString())
                .returnStatusMessage("test")));

        eventMapper.startUp(); // Application specific initialization
    }
}
