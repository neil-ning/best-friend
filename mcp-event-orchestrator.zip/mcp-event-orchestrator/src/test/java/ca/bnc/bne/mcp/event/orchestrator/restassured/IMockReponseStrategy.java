package ca.bnc.bne.mcp.event.orchestrator.restassured;

import com.fasterxml.jackson.core.JsonProcessingException;
import okhttp3.mockwebserver.MockResponse;
import org.json.JSONException;

import java.io.IOException;
import java.net.URISyntaxException;

public interface IMockReponseStrategy {

    MockResponse supply() throws IOException, URISyntaxException, JSONException;

    String endpoint();
}
