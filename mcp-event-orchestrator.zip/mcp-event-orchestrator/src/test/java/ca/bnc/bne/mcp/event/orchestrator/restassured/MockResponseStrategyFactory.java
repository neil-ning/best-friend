package ca.bnc.bne.mcp.event.orchestrator.restassured;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Set;

public class MockResponseStrategyFactory {

    private HashMap<String, IMockReponseStrategy> strategyHashMap = new HashMap<>();

    public MockResponseStrategyFactory() {

    }

    public void init(){
        Set<Class<? extends IMockReponseStrategy>> set = RestAssuredTestUtils.getAllMockResponseStrategies();
        set.forEach(c -> {
            try {
                IMockReponseStrategy strategy = c.getConstructor().newInstance();
                strategyHashMap.put(strategy.endpoint(), strategy);
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            }
        });
    }

    public void addStrategy(IMockReponseStrategy strategy) {

        if(strategy == null){
            throw new NullPointerException("strategy could not be null");
        }

        strategyHashMap.put(strategy.endpoint(), strategy);
    }

    public void replaceStrategy(IMockReponseStrategy strategy) {
        if(strategy == null){
            throw new NullPointerException("strategy could not be null");
        }
        if (strategyHashMap.containsKey(strategy.endpoint())) {
            strategyHashMap.replace(strategy.endpoint(), strategy);
        } else {
            strategyHashMap.put(strategy.endpoint(), strategy);
        }

    }

    public IMockReponseStrategy getStrategy(String endpoint) {

        return strategyHashMap.get(endpoint);

    }
}
