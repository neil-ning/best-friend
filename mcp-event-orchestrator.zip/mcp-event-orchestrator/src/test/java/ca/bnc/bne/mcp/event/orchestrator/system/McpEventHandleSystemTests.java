package ca.bnc.bne.mcp.event.orchestrator.system;

import ca.bnc.bne.mcp.event.orchestrator.restassured.McpEventHandleRestAssuredTests;
import io.restassured.RestAssured;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import java.io.IOException;

@Disabled
public class McpEventHandleSystemTests {
    private McpEventHandleRestAssuredTests mcpEventHandleRestAssuredTests;

    @BeforeEach
    void setUp() {
        RestAssured.baseURI = "http://c1b663a9-6f3a-43b0-a4f5-fb401bc04d8f.mock.pstmn.io";
        mcpEventHandleRestAssuredTests = new McpEventHandleRestAssuredTests();
    }

    @Test()
    void testEditIndividual() throws IOException {
        mcpEventHandleRestAssuredTests.testEditIndividual();
    }

    @Test()
    void testEditIndividualFromFile() throws IOException {
        mcpEventHandleRestAssuredTests.testEditIndividualFromFile();
    }
}
