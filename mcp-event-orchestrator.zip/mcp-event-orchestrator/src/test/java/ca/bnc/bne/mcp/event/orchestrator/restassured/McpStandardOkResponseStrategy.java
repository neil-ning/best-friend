package ca.bnc.bne.mcp.event.orchestrator.restassured;

import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.StandardResponse;
import ca.bnc.bne.mcp.event.orchestrator.util.JsonFileUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import okhttp3.mockwebserver.MockResponse;

import java.time.LocalDateTime;

public class McpStandardOkResponseStrategy implements IMockReponseStrategy {
    @Override
    public MockResponse supply() throws JsonProcessingException {

        MockResponse response = new MockResponse().setResponseCode(200)
                .addHeader("Content-Type", "application/json; charset=utf-8")
                .setBody(JsonFileUtil.writeString(new StandardResponse()
                        .returnStatusCode("0").returnStatusMessage("success")
                        .returnDate(LocalDateTime.now().toString())));

        return response;
    }

    @Override
    public String endpoint() {
        return "/parties/v2/bncId/partySysKey";
    }
}
