package ca.bnc.bne.mcp.event.orchestrator.restassured;

import ca.bnc.bne.mcp.event.orchestrator.util.JsonFileUtil;
import okhttp3.mockwebserver.MockResponse;
import org.json.JSONException;

import java.io.IOException;
import java.net.URISyntaxException;

public class McpGetSocioOkResponseStrategy implements IMockReponseStrategy {
    @Override
    public MockResponse supply() throws IOException, URISyntaxException, JSONException {
        return new MockResponse().setResponseCode(200)
                .addHeader("Content-Type", "application/json; charset=utf-8")
                .setBody(JsonFileUtil.readString("service/mcp/get-socio-ok-resp.json"));
    }

    @Override
    public String endpoint() {
        return "/mcp/v2/individual-socio-demographic-api/individuals/bncId/socio-demographic";
    }
}
