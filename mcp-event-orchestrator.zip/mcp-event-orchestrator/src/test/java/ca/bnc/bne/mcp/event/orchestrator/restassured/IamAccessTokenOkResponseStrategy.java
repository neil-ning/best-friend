package ca.bnc.bne.mcp.event.orchestrator.restassured;

import ca.bnc.bne.mcp.event.orchestrator.dto.okta.OktaResponse;
import ca.bnc.bne.mcp.event.orchestrator.util.JsonFileUtil;
import okhttp3.mockwebserver.MockResponse;
import org.json.JSONException;

import java.io.IOException;
import java.net.URISyntaxException;

public class IamAccessTokenOkResponseStrategy implements IMockReponseStrategy {
    @Override
    public MockResponse supply() throws IOException, URISyntaxException, JSONException {
        return new MockResponse()
                .addHeader("Content-Type", "application/json")
                .setResponseCode(200)
                .setBody(JsonFileUtil.writeString(new OktaResponse().accessToken("fakeAccessToken")));
    }

    @Override
    public String endpoint() {
        return "/ausb2snfqxccuEfI90h7/v1/token";
    }
}
