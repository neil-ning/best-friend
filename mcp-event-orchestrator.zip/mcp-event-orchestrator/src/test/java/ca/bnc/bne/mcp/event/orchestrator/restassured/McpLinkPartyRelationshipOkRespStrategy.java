package ca.bnc.bne.mcp.event.orchestrator.restassured;

import okhttp3.mockwebserver.MockResponse;

import java.io.IOException;
import java.net.URISyntaxException;

public class McpLinkPartyRelationshipOkRespStrategy implements IMockReponseStrategy{

    @Override
    public MockResponse supply() throws IOException, URISyntaxException {
        return new MockResponse()
                .addHeader("Content-Type", "application/json; charset=utf-8")
                .setResponseCode(201)
                .addHeader("schema", "party-relationships/fakeRelationshipId");
    }

    @Override
    public String endpoint() {
        return "/mcp/v1/partyrelationship-api/party-relationships";
    }
}
