package ca.bnc.bne.mcp.event.orchestrator.service.mcp;

import ca.bnc.bne.mcp.event.orchestrator.exception.model.AddSystemKeyException;
import ca.bnc.bne.mcp.event.orchestrator.exception.model.InvalidResponseException;
import ca.bnc.bne.mcp.event.orchestrator.exception.model.McpBusinessRuleException;
import ca.bnc.bne.mcp.event.orchestrator.exception.model.McpWriteException;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.*;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.organization.GetOrganizationResponseType;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyAddress.GetPtyAddressesResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyAddress.UpdatePtyAddressesRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyAddress.UpdatePtyAddressesResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyContact.GetPtyContactsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyContact.UpdatePtyContactsRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyContact.UpdatePtyContactsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyContact.UpdatePtyContactsWithBNCIDRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyIdentification.GetPtyIdentificationsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyRelationship.GetRelationshipsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyRelationship.PostRelationship;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyRelationship.RemovedRelationship;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.socioDemo.GetIndividualSocioDemographicsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.socioDemo.UpdateIndividualSocioDemographicsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.socioDemo.UpdateIndividualSocioDemographicsWithBNCIDRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.AddPartySysKeyRequestBncId;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.RemovePartySysKeyRequestBncId;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.StandardResponse;
import ca.bnc.bne.mcp.event.orchestrator.util.JsonFileUtil;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Hooks;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.lang.Exception;
import java.net.URISyntaxException;

public class McpServiceTest {

  private static ObjectMapper objectMapper;
  private MockWebServer mockMcpServer;
  private McpService mcpService;

  private static <T> T mapHelper(Class<T> clazz, String json) {
    try {
      return objectMapper.readValue(json, clazz);
    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
  }

  @BeforeEach
  void setUp() throws IOException {
    mockMcpServer = new MockWebServer();
    mockMcpServer.start();
    objectMapper =
        new ObjectMapper()
            .setSerializationInclusion(JsonInclude.Include.NON_EMPTY)
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, true)
            .configure(JsonParser.Feature.ALLOW_COMMENTS, true)
            .configure(MapperFeature.USE_STD_BEAN_NAMING, true)
            .configure(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true)
            .configure(SerializationFeature.WRAP_ROOT_VALUE, false)
            .configure(DeserializationFeature.UNWRAP_ROOT_VALUE, false)
            .configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, false)
            .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
            .findAndRegisterModules();
  }

  @AfterEach
  void tearDown() throws IOException {
    mockMcpServer.shutdown();
  }

  @BeforeEach
  void initialize() {
    String baseUrl = String.format("http://localhost:%s", mockMcpServer.getPort());
    WebClient.Builder builder = WebClient.builder();
    mcpService = new McpService(baseUrl, "clientId", builder);
    mcpService.setEndpoint(new McpService.Endpoint()
                                          .setUriCreateIndividual("mcp/v2/individual-api/individuals?originSrcCd={originSrcCd}")
                                          .setUriModifyIndividualBase("mcp/v2/individual-api/individuals/base")
                                          .setUriModifyIndividualContact("mcp/v2/partycontact-api/parties/{bncId}/contacts")
                                          .setUriModifyIndividualAddress("mcp/v2/partyaddress-api/parties/{bncId}/addresses")
                                          .setUriModifyIndividualSocio("mcp/v2/individual-socio-demographic-api/individuals/{bncId}/socio-demographic")
                                          .setUriLinkIndividual("mcp/v1/partyrelationship-api/party-relationships")
                                          .setUriUnlinkIndividual("mcp/v1/partyrelationship-api/party-relationships/{uid}")
                                          .setUriDeleteSystemKeys("parties/v2/{bncId}/partySysKey"));

    Hooks.onOperatorDebug();
  }

  @Test
  public void testGetOrganizationByBncId_HappyPath() {
    MockResponse mockResponse =
        new MockResponse()
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody(
                "{\"organization\":{\"ptyUID\":\"878451872497325101\",\"ptyTypeCd\":\"O\",\"ptyCltSinceDt\":\"2000-01-31\",\"ptyDataQualityStatus\":\"UNVERIFIED\",\"ptyUndesirableStatus\":\"UNDES\",\"ptyUndesirableStatusDt\":\"2000-01-31\",\"ptyUpdDt\":\"2020-08-11T14:38:35.190Z\",\"prefContactLangCd\":\"EN\",\"orgConstitutionDt\":\"2000-01-31\",\"orgLglFormCd\":\"CORP\",\"orgLglFormTypeCd\":\"CORPORATE\",\"orgHomeJurisdGeoAreaCd\":\"CA\",\"orgHomeJurisdGeoAreaTypeCd\":\"PAISO\",\"orgOperationStartDt\":\"2000-01-31\",\"orgDtFiscalYearEndDay\":31,\"orgDtFiscalYearEndMth\":12,\"orgTotalAnnualSalesIncomeUID\":\"879651872497326301\",\"orgTotalAnnualSalesIncome\":1000000,\"orgTotalAnnualSalesIncomeUpdDt\":\"2020-08-11T14:38:35.190Z\",\"orgTotalNumberEmpUID\":\"879651872497326301\",\"orgTotalNumberEmp\":100,\"orgTotalNumberEmpUpdDt\":\"2020-08-11T14:38:35.190Z\",\"orgProfileUpdDt\":\"2020-08-11T14:38:35.190Z\",\"orgProfileVerifiedDt\":\"2020-08-11T14:38:35.190Z\",\"orgUpdDt\":\"2020-08-11T14:38:35.191Z\",\"organizationNames\":[{\"orgNmUID\":\"879651872497326301\",\"orgName\":\"The name of my organization\",\"orgNmTypeCd\":\"LGLNAME\",\"orgNmEffctvDt\":\"2020-08-11T14:38:35.191Z\",\"orgNmEndDt\":\"2020-08-11T14:38:35.191Z\",\"orgNmUpdDt\":\"2020-08-11T14:38:35.191Z\"}],\"partyMembers\":[{\"ptyMemberUID\":\"879651874257326301\",\"srcCd\":68,\"memberIdNo\":\"TEST0000000000\",\"ptyMemberUpdDt\":\"2020-08-11T14:38:35.191Z\"}],\"partyIdentifications\":[{\"ptyIdentUID\":\"873251222526081101\",\"ptyIdentItemTypeCd\":\"QST\",\"ptyIdentItemNo\":\"9999999999 TQ 0001\",\"ptyIdentItemIssuingGeoAreaCd\":\"CA-QC\",\"ptyIdentItemIssuingGeoAreaTypeCd\":\"PRISO\",\"ptyIdentStatusCd\":\"ACTIVE\",\"ptyIdentCreationDt\":\"2020-08-11T14:38:35.191Z\",\"ptyIdentEndDt\":\"2020-08-11T14:38:35.191Z\",\"ptyIdentItemExpirDt\":\"2000-01-31\",\"ptyIdentRegUpdDt\":\"2000-01-31\",\"ptyIdentVerifDt\":\"2020-08-11T14:38:35.191Z\",\"ptyIdentUpdDt\":\"2020-08-11T14:38:35.191Z\"}],\"orgForgnOprtns\":[{\"orgForgnOprtnUID\":\"878051872526079401\",\"orgForgnOprtnCntryCd\":\"US\",\"orgForgnOprtnUpdDt\":\"2020-08-11T14:38:35.191Z\"}],\"orgIndstrClasses\":[{\"orgIndstrClassUID\":\"879934562526081101\",\"orgIndstrClassCd\":\"111110\",\"orgIndstrClassTypeCd\":\"NAICS02CAN\",\"orgIndstrClassRankCd\":\"SECONDARY\",\"orgIndstrClassActWeighting\":100,\"orgIndstrClassUpdDt\":\"2020-08-11T14:38:35.191Z\"}],\"orgStckMktXchs\":[{\"orgStckMktXchCd\":\"AATS\"}],\"labels\":[{\"code\":\"GP1859\",\"version\":1,\"effectiveStartDate\":\"2000-12-30\",\"effectiveEndDate\":\"2000-12-30\",\"manualInterventionUserId\":\"gama004\",\"uniqueIdentifier\":\"11223344556677889900\",\"lastUpdateDate\":\"2000-12-01T12:00:00.000Z\"}]},\"exceptions\":[{\"excpDomainCd\":\"PARTY\",\"excpTypeCd\":\"ORGBIZACT\",\"excpCauseCd\":\"PRYACTINV2\",\"excptErrMsg\":\"The Primary Activity weight percentage must be superior or equal to each Secondary Activity weight, And the sum of weights of all business activities have to be greater than 0% and less than or equal to 100%.\",\"excpEffctvDt\":\"2020-08-11T14:38:35.191Z\"}],\"debug\":[{\"request\":\"<element-name attribute1 attribute2> ....content </element-name>\",\"response\":\"<element-name attribute1 attribute2> ....content </element-name>\"}]}");

    mockMcpServer.enqueue(mockResponse);
    mcpService.getEndpoint().setOrganization("baseOrgEndpoint");
    Mono<GetOrganizationResponseType> organizationByBncId =
        mcpService.getBaseOrganizationMono("token", "bnc");

    StepVerifier.create(organizationByBncId)
                .expectNextMatches(
                    getOrganizationResponseType ->
                        getOrganizationResponseType
                            .getOrganization()
                            .getPtyUID()
                            .equalsIgnoreCase("878451872497325101"))
                .verifyComplete();
  }

  @Test
  public void testGetOrganizationByBncId_EmptyBody() {
    MockResponse mockResponse =
        new MockResponse().addHeader("Content-Type", "application/json; charset=utf-8").setBody("");
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);

    mcpService.getEndpoint().setOrganization("baseOrgEndpoint");
    Mono<GetOrganizationResponseType> organizationByBncId =
        mcpService.getBaseOrganizationMono("token", "bnc");

    StepVerifier.create(organizationByBncId).expectError(InvalidResponseException.class).verify();
  }

  @Test
  public void testGetOrganizationByBncId_401Unauthorized() {
    MockResponse mockResponse =
        new MockResponse()
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setResponseCode(401);

    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);

    mcpService.getEndpoint().setOrganization("baseOrgEndpoint");
    Mono<GetOrganizationResponseType> organizationByBncId =
        mcpService.getBaseOrganizationMono("testToken", "testBncId");

    StepVerifier.create(organizationByBncId).expectError(WebClientResponseException.class).verify();
  }

  @Test
  public void testGetOrganizationByBncId_400BusinessError() {
    String response =
        "{\"status\":400,\"title\":\"BUSINESS RULES VIOLATION\",\"type\":\"https://wiki.bnc.ca/api/probs/400/business-error\",\"detail\":\"The request violates one or many business rule(s)\",\"elements\":[{\"sourceCode\":\"3127\",\"reasonType\":\"BUSINESS-RULE-VIOLATION\",\"reasonCode\":\"9000143\",\"message\":\"Organization is not found\",\"severity\":\"ERROR\",\"timestamp\":\"2020-08-26T20:35:14.338Z\"}]}";
    MockResponse mockResponse =
        new MockResponse()
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setResponseCode(400)
            .setBody(response);

    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);

    StepVerifier.create(mcpService.getBaseOrganizationMono("bnc", "token"))
                .expectErrorMatches(
                    throwable ->
                        throwable instanceof McpBusinessRuleException
                            && throwable.getMessage().contains("Organization is not found"))
                .verify();
  }

/*  @Test
  public void testGetOrganizationByBncId_SuccessAfterRetry() {
    MockResponse mockResponseFail = new MockResponse().setResponseCode(500);
    MockResponse mockResponseSuccess =
        new MockResponse()
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody(
                "{\"organization\":{\"ptyUID\":\"878451872497325101\",\"ptyTypeCd\":\"O\",\"ptyCltSinceDt\":\"2000-01-31\",\"ptyDataQualityStatus\":\"UNVERIFIED\",\"ptyUndesirableStatus\":\"UNDES\",\"ptyUndesirableStatusDt\":\"2000-01-31\",\"ptyUpdDt\":\"2020-08-11T14:38:35.190Z\",\"prefContactLangCd\":\"EN\",\"orgConstitutionDt\":\"2000-01-31\",\"orgLglFormCd\":\"CORP\",\"orgLglFormTypeCd\":\"CORPORATE\",\"orgHomeJurisdGeoAreaCd\":\"CA\",\"orgHomeJurisdGeoAreaTypeCd\":\"PAISO\",\"orgOperationStartDt\":\"2000-01-31\",\"orgDtFiscalYearEndDay\":31,\"orgDtFiscalYearEndMth\":12,\"orgTotalAnnualSalesIncomeUID\":\"879651872497326301\",\"orgTotalAnnualSalesIncome\":1000000,\"orgTotalAnnualSalesIncomeUpdDt\":\"2020-08-11T14:38:35.190Z\",\"orgTotalNumberEmpUID\":\"879651872497326301\",\"orgTotalNumberEmp\":100,\"orgTotalNumberEmpUpdDt\":\"2020-08-11T14:38:35.190Z\",\"orgProfileUpdDt\":\"2020-08-11T14:38:35.190Z\",\"orgProfileVerifiedDt\":\"2020-08-11T14:38:35.190Z\",\"orgUpdDt\":\"2020-08-11T14:38:35.191Z\",\"organizationNames\":[{\"orgNmUID\":\"879651872497326301\",\"orgName\":\"The name of my organization\",\"orgNmTypeCd\":\"LGLNAME\",\"orgNmEffctvDt\":\"2020-08-11T14:38:35.191Z\",\"orgNmEndDt\":\"2020-08-11T14:38:35.191Z\",\"orgNmUpdDt\":\"2020-08-11T14:38:35.191Z\"}],\"partyMembers\":[{\"ptyMemberUID\":\"879651874257326301\",\"srcCd\":68,\"memberIdNo\":\"TEST0000000000\",\"ptyMemberUpdDt\":\"2020-08-11T14:38:35.191Z\"}],\"partyIdentifications\":[{\"ptyIdentUID\":\"873251222526081101\",\"ptyIdentItemTypeCd\":\"QST\",\"ptyIdentItemNo\":\"9999999999 TQ 0001\",\"ptyIdentItemIssuingGeoAreaCd\":\"CA-QC\",\"ptyIdentItemIssuingGeoAreaTypeCd\":\"PRISO\",\"ptyIdentStatusCd\":\"ACTIVE\",\"ptyIdentCreationDt\":\"2020-08-11T14:38:35.191Z\",\"ptyIdentEndDt\":\"2020-08-11T14:38:35.191Z\",\"ptyIdentItemExpirDt\":\"2000-01-31\",\"ptyIdentRegUpdDt\":\"2000-01-31\",\"ptyIdentVerifDt\":\"2020-08-11T14:38:35.191Z\",\"ptyIdentUpdDt\":\"2020-08-11T14:38:35.191Z\"}],\"orgForgnOprtns\":[{\"orgForgnOprtnUID\":\"878051872526079401\",\"orgForgnOprtnCntryCd\":\"US\",\"orgForgnOprtnUpdDt\":\"2020-08-11T14:38:35.191Z\"}],\"orgIndstrClasses\":[{\"orgIndstrClassUID\":\"879934562526081101\",\"orgIndstrClassCd\":\"111110\",\"orgIndstrClassTypeCd\":\"NAICS02CAN\",\"orgIndstrClassRankCd\":\"SECONDARY\",\"orgIndstrClassActWeighting\":100,\"orgIndstrClassUpdDt\":\"2020-08-11T14:38:35.191Z\"}],\"orgStckMktXchs\":[{\"orgStckMktXchCd\":\"AATS\"}],\"labels\":[{\"code\":\"GP1859\",\"version\":1,\"effectiveStartDate\":\"2000-12-30\",\"effectiveEndDate\":\"2000-12-30\",\"manualInterventionUserId\":\"gama004\",\"uniqueIdentifier\":\"11223344556677889900\",\"lastUpdateDate\":\"2000-12-01T12:00:00.000Z\"}]},\"exceptions\":[{\"excpDomainCd\":\"PARTY\",\"excpTypeCd\":\"ORGBIZACT\",\"excpCauseCd\":\"PRYACTINV2\",\"excptErrMsg\":\"The Primary Activity weight percentage must be superior or equal to each Secondary Activity weight, And the sum of weights of all business activities have to be greater than 0% and less than or equal to 100%.\",\"excpEffctvDt\":\"2020-08-11T14:38:35.191Z\"}],\"debug\":[{\"request\":\"<element-name attribute1 attribute2> ....content </element-name>\",\"response\":\"<element-name attribute1 attribute2> ....content </element-name>\"}]}");

    mockMcpServer.enqueue(mockResponseFail);
    mockMcpServer.enqueue(mockResponseFail);
    mockMcpServer.enqueue(mockResponseSuccess);
    mcpService.getEndpoint().setOrganization("test");
    Mono<GetOrganizationResponseType> organizationByBncId =
        mcpService.getBaseOrganizationMono("testToken", "testBncId");

    StepVerifier.create(organizationByBncId)
                .expectNextMatches(
                    getOrganizationResponseType ->
                        getOrganizationResponseType
                            .getOrganization()
                            .getPtyUID()
                            .equalsIgnoreCase("878451872497325101"))
                .verifyComplete();
  }*/

  @Test
  public void testGetIndividualByBncId_HappyPath() {
    MockResponse mockResponse =
        new MockResponse()
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody(
                "{\"individual\":{\"indvBirthDt\":\"2000-01-01\",\"indvDeathDt\":\"2017-01-01\",\"indvMotherMaidenNm\":\"Lana\",\"prefContactLangCd\":\"FR\",\"indvUpdDt\":\"2020-08-21T16:37:13.466Z\",\"ptyDataQualityStatus\":\"VERIFIED\",\"ptyUID\":\"301349819333378501\",\"ptyTypeCd\":\"I\",\"ptyUpdDt\":\"2020-08-21T16:37:13.466Z\",\"individualName\":[{\"individualNmEffctvDt\":\"2020-08-21T16:37:13.466Z\",\"individualNmEndDt\":\"2020-08-21T16:37:13.466Z\",\"individualNmTitleCd\":\"M\",\"givenName\":\"Irena\",\"middleName\":\"Douda\",\"surname\":\"Bartucca\",\"individualNmUID\":\"307222913920524111\",\"individualNmUpdDt\":\"2020-08-21T16:37:13.466Z\"}],\"partyMember\":[{\"memberIdNo\":\"YWFWD549571373\",\"srcCd\":68,\"ptyMemberUID\":\"307555559260382433\",\"ptyMemberUpdDt\":\"2020-08-21T16:37:13.466Z\"}],\"exception\":[{\"excpActionCd\":\"\",\"excpCauseCd\":\"EMPLOYMAND\",\"excpComponentId\":\"304951913924440101\",\"excpDomainCd\":\"PARTY\",\"excpEffctvDt\":\"2020-08-21T16:37:13.466Z\",\"excptErrMsg\":\"The Primary Activity weight percentage must be superior or equal to each Secondary Activity weight, And the sum of weights of all business activities have to be greater than 0% and less than or equal to 100%.\",\"excpTypeCd\":\"PERSOCCTYP\"}],\"partyIdentification\":[{\"ptyIdentItemNo\":\"09OR32DE118643E0A09065DAAB6BDD2AD2C94995D593DE0BBD2A5F67C21k26jy\",\"ptyIdentItemTypeCd\":\"BNCID\",\"ptyIdentStatusCd\":\"ACTIVE\"}]}}");
    mockMcpServer.enqueue(mockResponse);
    mcpService.getEndpoint().setIndividual("baseind");
    Mono<GetIndividualBaseResponse> individualBaseResponseMono =
        mcpService.getBaseIndividualMono("token", "bnc");

    StepVerifier.create(individualBaseResponseMono)
                .expectNextMatches(
                    getIndividualBaseResponse ->
                        getIndividualBaseResponse
                            .getIndividual()
                            .getPtyUID()
                            .equalsIgnoreCase("301349819333378501"))
                .verifyComplete();
  }

  @Test
  public void testGetIndividualByBncId_Error() {
    MockResponse mockResponse = new MockResponse().setResponseCode(500);

    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);

    mcpService.getEndpoint().setIndividual("baseind");
    Mono<GetIndividualBaseResponse> individualBaseResponseMono =
        mcpService.getBaseIndividualMono("testToken", "testBncId");

    StepVerifier.create(individualBaseResponseMono)
                .expectError(WebClientResponseException.class)
                .verify();
  }

  @Test
  public void testGetIndividualByBncId_400BusinessError() {
    String response =
        "{\"status\":400,\"title\":\"BUSINESS RULES VIOLATION\",\"type\":\"https://wiki.bnc.ca/api/probs/400/business-error\",\"detail\":\"The request violates one or many business rule(s)\",\"elements\":[{\"sourceCode\":\"3127\",\"reasonType\":\"BUSINESS-RULE-VIOLATION\",\"reasonCode\":\"9000143\",\"message\":\"Party not found\",\"severity\":\"ERROR\",\"timestamp\":\"2020-08-26T20:35:14.338Z\"}]}";
    MockResponse mockResponse =
        new MockResponse()
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setResponseCode(400)
            .setBody(response);

    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);

    StepVerifier.create(mcpService.getBaseOrganizationMono("bnc", "token"))
                .expectErrorMatches(
                    throwable ->
                        throwable instanceof McpBusinessRuleException
                            && throwable.getMessage().contains("Party not found"))
                .verify();
  }

/*  @Test
  public void testGetIndividualByBncId_SuccessAfterRetry() {
    MockResponse mockResponseFail = new MockResponse().setResponseCode(500);
    MockResponse mockResponseSuccess =
        new MockResponse()
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody(
                "{\"individual\":{\"indvBirthDt\":\"2000-01-01\",\"indvDeathDt\":\"2017-01-01\",\"indvMotherMaidenNm\":\"Lana\",\"prefContactLangCd\":\"FR\",\"indvUpdDt\":\"2020-08-21T16:37:13.466Z\",\"ptyDataQualityStatus\":\"VERIFIED\",\"ptyUID\":\"301349819333378501\",\"ptyTypeCd\":\"I\",\"ptyUpdDt\":\"2020-08-21T16:37:13.466Z\",\"individualName\":[{\"individualNmEffctvDt\":\"2020-08-21T16:37:13.466Z\",\"individualNmEndDt\":\"2020-08-21T16:37:13.466Z\",\"individualNmTitleCd\":\"M\",\"givenName\":\"Irena\",\"middleName\":\"Douda\",\"surname\":\"Bartucca\",\"individualNmUID\":\"307222913920524111\",\"individualNmUpdDt\":\"2020-08-21T16:37:13.466Z\"}],\"partyMember\":[{\"memberIdNo\":\"YWFWD549571373\",\"srcCd\":68,\"ptyMemberUID\":\"307555559260382433\",\"ptyMemberUpdDt\":\"2020-08-21T16:37:13.466Z\"}],\"exception\":[{\"excpActionCd\":\"\",\"excpCauseCd\":\"EMPLOYMAND\",\"excpComponentId\":\"304951913924440101\",\"excpDomainCd\":\"PARTY\",\"excpEffctvDt\":\"2020-08-21T16:37:13.466Z\",\"excptErrMsg\":\"The Primary Activity weight percentage must be superior or equal to each Secondary Activity weight, And the sum of weights of all business activities have to be greater than 0% and less than or equal to 100%.\",\"excpTypeCd\":\"PERSOCCTYP\"}],\"partyIdentification\":[{\"ptyIdentItemNo\":\"09OR32DE118643E0A09065DAAB6BDD2AD2C94995D593DE0BBD2A5F67C21k26jy\",\"ptyIdentItemTypeCd\":\"BNCID\",\"ptyIdentStatusCd\":\"ACTIVE\"}]}}");

    mockMcpServer.enqueue(mockResponseFail);
    mockMcpServer.enqueue(mockResponseFail);
    mockMcpServer.enqueue(mockResponseSuccess);
    mcpService.getEndpoint().setIndividual("test");
    Mono<GetIndividualBaseResponse> getIndividualBaseResponseMono =
        mcpService.getBaseIndividualMono("testToken", "testBncId");

    StepVerifier.create(getIndividualBaseResponseMono)
                .expectNextMatches(
                    getIndividualBaseResponse ->
                        getIndividualBaseResponse
                            .getIndividual()
                            .getPtyUID()
                            .equalsIgnoreCase("301349819333378501"))
                .verifyComplete();
  }*/

  @Test
  public void testGetIndividualByBncId_EmptyBody() {
    MockResponse mockResponse =
        new MockResponse().addHeader("Content-Type", "application/json; charset=utf-8").setBody("");
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);

    mcpService.getEndpoint().setIndividual("test");

    Mono<GetIndividualBaseResponse> baseIndividualMono =
        mcpService.getBaseIndividualMono("token", "bnc");

    StepVerifier.create(baseIndividualMono).expectError(InvalidResponseException.class).verify();
  }

  @Test
  public void testGetAddressByBncId_HappyPath() {
    String response =
        "{\"partyAddresses\":[{\"ptyUID\":\"103549819321654987\",\"ptyAddrUID\":\"9876543210987654\",\"ptyAddrProprietaryStatusTypeCd\":\"P\",\"ptyAddrUsageTypeCd\":\"PRINRES\",\"ptyAddrPersonalizedUsgNm\":\"Residence familiale\",\"effctvDt\":\"2013-03-03\",\"endDt\":\"2013-03-03\",\"ptyAddrUpdDt\":\"2013-03-03T15:49:15.815Z\",\"ptyAddrGrpUpdDt\":\"2013-03-03T15:49:15.815Z\",\"Address\":{\"addrPublishStatusCd\":\"STANDARD\",\"addrCivicNo\":\"310\",\"addrDlvInstallationTypeCd\":\"STN\",\"addrDlvModeAddInfo\":\"Leave at the door\",\"addrDlvModeID\":\"987654321A123456\",\"addrDlvModeTypeCd\":\"GD\",\"addrDlvrInstallationNameID\":\"987654321B123456\",\"addrPOBoxNo\":\"12345\",\"addrPOBoxTypeCd\":\"POBOX\",\"addrStrDirectionTypeCd\":\"E\",\"addrStrTypeCd\":\"BLVD\",\"addrUnitDesignatorTypeCd\":\"APT\",\"addrUnitNo\":\"205\",\"bldgName\":\"string\",\"cntryIso2\":\"CA\",\"localityComplete\":\"Saint-Lambert\",\"postalCdUnformatted\":\"J4R1K5\",\"provCntryStd\":\"CA-QC\",\"region\":\"Montérégie\",\"stName\":\"D'Arran\",\"addrLvlTypeCd\":\"FLOOR\",\"addrLvlNo\":\"2\",\"addrDlvInstallationDesignator\":\"STN\",\"addrDlvModeDesignator\":\"1111\",\"addrPOBoxDesignator\":\"1111\",\"addrPreStrDirectionDesignator\":\"west\",\"addrPostStrDirectionDesignator\":\"ouest\",\"addrPreStrTypeDesignator\":\"rue\",\"addrPostStrTypeDesignator\":\"street\",\"addrUnitDesignator\":\"APT\",\"addrCntrySubDivCdDesignator\":\"territoire\",\"addrLvlDesignator\":\"Floor\",\"addrUID\":\"123456789012345678\",\"addrUpdDt\":\"2013-03-03T15:49:15.815Z\",\"unstrctrPostlAddresses\":[{\"unstrctrPostlAddrLine\":\"310 Rue D'Arran Suite 201;Saint-Lambert, QC J4R 2T5\",\"unstrctrPostlAddrLineSeq\":\"1\"}],\"geographicsCoordinates\":{\"latitude\":\"45.494446\",\"longitude\":\"-73.571695\"}}}]}";

    MockResponse mockResponse =
        new MockResponse()
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody(response);
    mockMcpServer.enqueue(mockResponse);
    mcpService.getEndpoint().setPtyAddress("ptyAddr");
    Mono<GetPtyAddressesResponse> getPtyAddressesResponseMono =
        mcpService.getPtyAddressMono("token", "bnc");

    StepVerifier.create(getPtyAddressesResponseMono)
                .expectNext(mapHelper(GetPtyAddressesResponse.class, response))
                .verifyComplete();
  }

  @Test
  public void testGetAddressByBncId_Error() {
    MockResponse mockResponse = new MockResponse().setResponseCode(500);

    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);

    mcpService.getEndpoint().setPtyAddress("ptyAddr");
    Mono<GetPtyAddressesResponse> getPtyAddressesResponseMono =
        mcpService.getPtyAddressMono("token", "bnc");

    StepVerifier.create(getPtyAddressesResponseMono)
                .expectError(WebClientResponseException.class)
                .verify();
  }

  @Test
  public void testGetAddressByBncId_EmptyBody() {
    MockResponse mockResponse =
        new MockResponse().addHeader("Content-Type", "application/json; charset=utf-8").setBody("");
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);

    mcpService.getEndpoint().setPtyAddress("test");

    Mono<GetPtyAddressesResponse> ptyAddressMono = mcpService.getPtyAddressMono("token", "bnc");

    StepVerifier.create(ptyAddressMono).expectError(InvalidResponseException.class).verify();
  }

/*  @Test
  public void testGetAddressByBncId_SuccessAfterRetry() {
    String response =
        "{\"partyAddresses\":[{\"ptyUID\":\"103549819321654987\",\"ptyAddrUID\":\"9876543210987654\",\"ptyAddrProprietaryStatusTypeCd\":\"P\",\"ptyAddrUsageTypeCd\":\"PRINRES\",\"ptyAddrPersonalizedUsgNm\":\"Residence familiale\",\"effctvDt\":\"2013-03-03\",\"endDt\":\"2013-03-03\",\"ptyAddrUpdDt\":\"2013-03-03T15:49:15.815Z\",\"ptyAddrGrpUpdDt\":\"2013-03-03T15:49:15.815Z\",\"Address\":{\"addrPublishStatusCd\":\"STANDARD\",\"addrCivicNo\":\"310\",\"addrDlvInstallationTypeCd\":\"STN\",\"addrDlvModeAddInfo\":\"Leave at the door\",\"addrDlvModeID\":\"987654321A123456\",\"addrDlvModeTypeCd\":\"GD\",\"addrDlvrInstallationNameID\":\"987654321B123456\",\"addrPOBoxNo\":\"12345\",\"addrPOBoxTypeCd\":\"POBOX\",\"addrStrDirectionTypeCd\":\"E\",\"addrStrTypeCd\":\"BLVD\",\"addrUnitDesignatorTypeCd\":\"APT\",\"addrUnitNo\":\"205\",\"bldgName\":\"string\",\"cntryIso2\":\"CA\",\"localityComplete\":\"Saint-Lambert\",\"postalCdUnformatted\":\"J4R1K5\",\"provCntryStd\":\"CA-QC\",\"region\":\"Montérégie\",\"stName\":\"D'Arran\",\"addrLvlTypeCd\":\"FLOOR\",\"addrLvlNo\":\"2\",\"addrDlvInstallationDesignator\":\"STN\",\"addrDlvModeDesignator\":\"1111\",\"addrPOBoxDesignator\":\"1111\",\"addrPreStrDirectionDesignator\":\"west\",\"addrPostStrDirectionDesignator\":\"ouest\",\"addrPreStrTypeDesignator\":\"rue\",\"addrPostStrTypeDesignator\":\"street\",\"addrUnitDesignator\":\"APT\",\"addrCntrySubDivCdDesignator\":\"territoire\",\"addrLvlDesignator\":\"Floor\",\"addrUID\":\"123456789012345678\",\"addrUpdDt\":\"2013-03-03T15:49:15.815Z\",\"unstrctrPostlAddresses\":[{\"unstrctrPostlAddrLine\":\"310 Rue D'Arran Suite 201;Saint-Lambert, QC J4R 2T5\",\"unstrctrPostlAddrLineSeq\":\"1\"}],\"geographicsCoordinates\":{\"latitude\":\"45.494446\",\"longitude\":\"-73.571695\"}}}]}";

    MockResponse mockResponseFail = new MockResponse().setResponseCode(500);
    MockResponse mockResponseSuccess =
        new MockResponse()
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody(response);

    mockMcpServer.enqueue(mockResponseFail);
    mockMcpServer.enqueue(mockResponseFail);
    mockMcpServer.enqueue(mockResponseSuccess);
    mcpService.getEndpoint().setPtyAddress("ptyAddr");
    Mono<GetPtyAddressesResponse> getPtyAddressesResponseMono =
        mcpService.getPtyAddressMono("token", "bnc");

    StepVerifier.create(getPtyAddressesResponseMono)
                .expectNext(mapHelper(GetPtyAddressesResponse.class, response))
                .verifyComplete();
  }*/

  @Test
  public void testGetContactsByBncId_HappyPath() {
    String response =
        "{\"contacts\":{\"ptyUID\":\"725849819260532101\",\"ptyElectronicCtcInfo\":[{\"ptyContactMethdUsgTypeCd\":\"PERS\",\"ptyContactEffctvDt\":\"2020-08-21T17:04:02.362Z\",\"ptyContactEndDt\":\"2020-08-21T17:04:02.362Z\",\"ptyElectronicCtcInfoTypeCode\":\"EMAIL\",\"ptyElectronicCtcInfoAddrNm\":\"name.lastname@cie.com\",\"keys\":{\"ptyContactMethdUID\":\"724649819260534801\",\"ptyContactMethdUpdDt\":\"2020-08-21T17:04:02.362Z\",\"ptyContactMethdGroupUpdDt\":\"2020-08-21T17:04:02.362Z\",\"ptyElectronicCtcInfoUID\":\"722150023638242801\",\"ptyElectronicCtcInfoUpdDt\":\"2020-08-21T17:04:02.362Z\"}}],\"ptyTelecommunication\":[{\"ptyContactMethdUsgTypeCd\":\"PERS\",\"ptyContactEffctvDt\":\"2020-08-21T17:04:02.362Z\",\"ptyContactEndDt\":\"2020-08-21T17:04:02.362Z\",\"ptyTlcDvcTypeCd\":\"PHONE\",\"ptyTlcCntryPhoneCd\":\"CA\",\"ptyTlcAreaPhoneCd\":\"514\",\"ptyTlcCompletePhoneNo\":\"5141234567\",\"ptyTlcLocalNo\":\"1234567\",\"ptyTlcExtension\":\"101\",\"keys\":{\"ptyContactMethdUID\":\"724649819260534801\",\"ptyContactMethdUpdDt\":\"2020-08-21T17:04:02.362Z\",\"ptyContactMethdGroupUpdDt\":\"2020-08-21T17:04:02.362Z\",\"ptyTlcUID\":\"725949819260535001\",\"ptyTlcUpdDt\":\"2020-08-21T17:04:02.362Z\",\"ptyTlcPhoneUID\":\"724252163509060101\",\"ptyTlcPhoneUpdDt\":\"2020-08-21T17:04:02.362Z\"}}]}}";
    MockResponse mockResponse =
        new MockResponse()
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody(response);
    mockMcpServer.enqueue(mockResponse);
    mcpService.getEndpoint().setPtyContacts("ptyContacts");
    Mono<GetPtyContactsResponse> getPtyContactsResponseMono =
        mcpService.getPtyContactsMono("token", "bnc");

    StepVerifier.create(getPtyContactsResponseMono)
                .expectNext(mapHelper(GetPtyContactsResponse.class, response))
                .verifyComplete();
  }

  @Test
  public void testGetContactByBncId_EmptyBody() {
    MockResponse mockResponse =
        new MockResponse().addHeader("Content-Type", "application/json; charset=utf-8").setBody("");
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);

    mcpService.getEndpoint().setPtyContacts("test");

    Mono<GetPtyContactsResponse> ptyContactsMono = mcpService.getPtyContactsMono("token", "bnc");

    StepVerifier.create(ptyContactsMono).expectError(InvalidResponseException.class).verify();
  }

  @Test
  public void testGetContactsByBncId_Error() {
    MockResponse mockResponse = new MockResponse().setResponseCode(500);

    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);

    mcpService.getEndpoint().setPtyContacts("ptyContacts");
    Mono<GetPtyContactsResponse> getPtyContactsResponseMono =
        mcpService.getPtyContactsMono("token", "bnc");

    StepVerifier.create(getPtyContactsResponseMono)
                .expectError(WebClientResponseException.class)
                .verify();
  }

/*  @Test
  public void testGetContactsByBncId_SuccessAfterRetry() {
    String response =
        "{\"contacts\":{\"ptyUID\":\"725849819260532101\",\"ptyElectronicCtcInfo\":[{\"ptyContactMethdUsgTypeCd\":\"PERS\",\"ptyContactEffctvDt\":\"2020-08-21T17:04:02.362Z\",\"ptyContactEndDt\":\"2020-08-21T17:04:02.362Z\",\"ptyElectronicCtcInfoTypeCode\":\"EMAIL\",\"ptyElectronicCtcInfoAddrNm\":\"name.lastname@cie.com\",\"keys\":{\"ptyContactMethdUID\":\"724649819260534801\",\"ptyContactMethdUpdDt\":\"2020-08-21T17:04:02.362Z\",\"ptyContactMethdGroupUpdDt\":\"2020-08-21T17:04:02.362Z\",\"ptyElectronicCtcInfoUID\":\"722150023638242801\",\"ptyElectronicCtcInfoUpdDt\":\"2020-08-21T17:04:02.362Z\"}}],\"ptyTelecommunication\":[{\"ptyContactMethdUsgTypeCd\":\"PERS\",\"ptyContactEffctvDt\":\"2020-08-21T17:04:02.362Z\",\"ptyContactEndDt\":\"2020-08-21T17:04:02.362Z\",\"ptyTlcDvcTypeCd\":\"PHONE\",\"ptyTlcCntryPhoneCd\":\"CA\",\"ptyTlcAreaPhoneCd\":\"514\",\"ptyTlcCompletePhoneNo\":\"5141234567\",\"ptyTlcLocalNo\":\"1234567\",\"ptyTlcExtension\":\"101\",\"keys\":{\"ptyContactMethdUID\":\"724649819260534801\",\"ptyContactMethdUpdDt\":\"2020-08-21T17:04:02.362Z\",\"ptyContactMethdGroupUpdDt\":\"2020-08-21T17:04:02.362Z\",\"ptyTlcUID\":\"725949819260535001\",\"ptyTlcUpdDt\":\"2020-08-21T17:04:02.362Z\",\"ptyTlcPhoneUID\":\"724252163509060101\",\"ptyTlcPhoneUpdDt\":\"2020-08-21T17:04:02.362Z\"}}]}}";
    MockResponse mockResponseFail = new MockResponse().setResponseCode(500);
    MockResponse mockResponseSuccess =
        new MockResponse()
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody(response);

    mockMcpServer.enqueue(mockResponseFail);
    mockMcpServer.enqueue(mockResponseFail);
    mockMcpServer.enqueue(mockResponseSuccess);
    mcpService.getEndpoint().setPtyContacts("ptyContacts");
    Mono<GetPtyContactsResponse> getPtyContactsResponseMono =
        mcpService.getPtyContactsMono("token", "bnc");

    StepVerifier.create(getPtyContactsResponseMono)
                .expectNext(mapHelper(GetPtyContactsResponse.class, response))
                .verifyComplete();
  }*/

  @Test
  public void testGetPtyIdByBncId_HappyPath() {
    String response =
        "{\"partyIdentifications\":[{\"ptyUID\":\"123459819261074321\",\"ptyIdentItemTypeCd\":\"CAS\",\"ptyIdentCreationDt\":\"2013-03-03\",\"ptyIdentItemIssuingGeoAreaTypeCd\":\"PRISO\",\"ptyIdentEndDt\":\"2013-03-03\",\"ptyIdentItemExpirDt\":\"2013-03-03\",\"ptyIdentItemIssuingGeoAreaCd\":\"CA-QC\",\"ptyIdentItemNo\":\"ident1223456789-001\",\"ptyIdentStatusCd\":\"ACTIVE\",\"ptyIdentRegUpdDt\":\"2020-08-21T18:34:56.977Z\",\"ptyIdentUID\":\"123456789012345678\",\"ptyIdentUpdDt\":\"2020-08-21T18:34:56.977Z\",\"ptyIdentVerifDt\":\"2020-08-21T18:34:56.977Z\",\"ptyIdentIssuerType\":\"BELL\",\"ptyIdentIssuerName\":\"the name of the issuer\"}]}";
    MockResponse mockResponse =
        new MockResponse()
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody(response);
    mockMcpServer.enqueue(mockResponse);
    mcpService.getEndpoint().setPtyIdentification("ptyId");
    Mono<GetPtyIdentificationsResponse> getPtyIdentificationsResponseMono =
        mcpService.getPtyIdentificationMono("token", "bnc");

    StepVerifier.create(getPtyIdentificationsResponseMono)
                .expectNext(mapHelper(GetPtyIdentificationsResponse.class, response))
                .verifyComplete();
  }

  @Test
  public void testGetPtyIdByBncId_Error() {
    MockResponse mockResponse = new MockResponse().setResponseCode(500);

    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);

    mcpService.getEndpoint().setPtyIdentification("ptyId");
    Mono<GetPtyIdentificationsResponse> getPtyIdentificationsResponseMono =
        mcpService.getPtyIdentificationMono("token", "bnc");

    StepVerifier.create(getPtyIdentificationsResponseMono)
                .expectError(WebClientResponseException.class)
                .verify();
  }

  @Test
  public void testGetPtyIdByBncId_EmptyBody() {
    MockResponse mockResponse =
        new MockResponse().addHeader("Content-Type", "application/json; charset=utf-8").setBody("");
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);

    mcpService.getEndpoint().setIndividual("test");

    Mono<GetPtyIdentificationsResponse> ptyIdentificationMono =
        mcpService.getPtyIdentificationMono("token", "bnc");

    StepVerifier.create(ptyIdentificationMono).expectError(InvalidResponseException.class).verify();
  }

/*  @Test
  public void testGetPtyIdByBncId_SuccessAfterRetry() {
    String response =
        "{\"partyIdentifications\":[{\"ptyUID\":\"123459819261074321\",\"ptyIdentItemTypeCd\":\"CAS\",\"ptyIdentCreationDt\":\"2013-03-03\",\"ptyIdentItemIssuingGeoAreaTypeCd\":\"PRISO\",\"ptyIdentEndDt\":\"2013-03-03\",\"ptyIdentItemExpirDt\":\"2013-03-03\",\"ptyIdentItemIssuingGeoAreaCd\":\"CA-QC\",\"ptyIdentItemNo\":\"ident1223456789-001\",\"ptyIdentStatusCd\":\"ACTIVE\",\"ptyIdentRegUpdDt\":\"2020-08-21T18:34:56.977Z\",\"ptyIdentUID\":\"123456789012345678\",\"ptyIdentUpdDt\":\"2020-08-21T18:34:56.977Z\",\"ptyIdentVerifDt\":\"2020-08-21T18:34:56.977Z\",\"ptyIdentIssuerType\":\"BELL\",\"ptyIdentIssuerName\":\"the name of the issuer\"}]}";
    MockResponse mockResponseFail = new MockResponse().setResponseCode(500);
    MockResponse mockResponseSuccess =
        new MockResponse()
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody(response);

    mockMcpServer.enqueue(mockResponseFail);
    mockMcpServer.enqueue(mockResponseFail);
    mockMcpServer.enqueue(mockResponseSuccess);
    mcpService.getEndpoint().setPtyIdentification("ptyId");
    Mono<GetPtyIdentificationsResponse> getPtyIdentificationsResponseMono =
        mcpService.getPtyIdentificationMono("token", "bnc");

    StepVerifier.create(getPtyIdentificationsResponseMono)
                .expectNext(mapHelper(GetPtyIdentificationsResponse.class, response))
                .verifyComplete();
  }*/

  @Test
  public void testGetSocioDemoByBncId_HappyPath() {
    String response =
        "{\"socioDemographic\":{\"indvMaritalStatusTypeCd\":\"C\",\"genderCd\":\"2\",\"nbOfDependents\":\"1\",\"indvUpdDt\":\"2020-08-21T18:34:12.741Z\",\"ptyUID\":\"554449819264287788\",\"ptyUpdDt\":\"2020-08-21T18:34:12.741Z\"}}";
    MockResponse mockResponse =
        new MockResponse()
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody(response);
    mockMcpServer.enqueue(mockResponse);
    mcpService.getEndpoint().setSocioDemo("socioDemo");
    Mono<GetIndividualSocioDemographicsResponse> getIndividualSocioDemographicsResponseMono =
        mcpService.getSocioDemoMono("token", "bnc");

    StepVerifier.create(getIndividualSocioDemographicsResponseMono)
                .expectNext(mapHelper(GetIndividualSocioDemographicsResponse.class, response))
                .verifyComplete();
  }

  @Test
  public void testGetSocioDemoByBncId_Error() {
    MockResponse mockResponse = new MockResponse().setResponseCode(500);

    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);

    mcpService.getEndpoint().setSocioDemo("socioDemo");
    Mono<GetIndividualSocioDemographicsResponse> getIndividualSocioDemographicsResponseMono =
        mcpService.getSocioDemoMono("token", "bnc");

    StepVerifier.create(getIndividualSocioDemographicsResponseMono)
                .expectError(WebClientResponseException.class)
                .verify();
  }

  @Test
  public void testGetSocioDemoByBncId_EmptyBody() {
    MockResponse mockResponse =
        new MockResponse().addHeader("Content-Type", "application/json; charset=utf-8").setBody("");
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);

    mcpService.getEndpoint().setIndividual("test");

    Mono<GetIndividualSocioDemographicsResponse> socioDemoMono =
        mcpService.getSocioDemoMono("token", "bnc");

    StepVerifier.create(socioDemoMono).expectError(InvalidResponseException.class).verify();
  }

/*  @Test
  public void testGetSocioDemoByBncId_SuccessAfterRetry() {
    String response =
        "{\"socioDemographic\":{\"indvMaritalStatusTypeCd\":\"C\",\"genderCd\":\"2\",\"nbOfDependents\":\"1\",\"indvUpdDt\":\"2020-08-21T18:34:12.741Z\",\"ptyUID\":\"554449819264287788\",\"ptyUpdDt\":\"2020-08-21T18:34:12.741Z\"}}";
    MockResponse mockResponseFail = new MockResponse().setResponseCode(500);
    MockResponse mockResponseSuccess =
        new MockResponse()
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody(response);

    mockMcpServer.enqueue(mockResponseFail);
    mockMcpServer.enqueue(mockResponseFail);
    mockMcpServer.enqueue(mockResponseSuccess);
    mcpService.getEndpoint().setSocioDemo("socioDemo");
    Mono<GetIndividualSocioDemographicsResponse> getIndividualSocioDemographicsResponseMono =
        mcpService.getSocioDemoMono("token", "bnc");

    StepVerifier.create(getIndividualSocioDemographicsResponseMono)
                .expectNext(mapHelper(GetIndividualSocioDemographicsResponse.class, response))
                .verifyComplete();
  }*/

  @Test
  public void testGetRelationshipsByBncId_HappyPath() {
    String response =
        "{\"count\":\"5\",\"totalCount\":\"15\",\"relationships\":[{\"partyRelationType\":\"HOUSEHOLD\",\"initiatingPartyRole\":\"SPOUSE\",\"oppositePartyRole\":\"SPOUSE\",\"initiatingPartyType\":\"I\",\"oppositePartyType\":\"I\",\"initiatingBncId\":\"5fa23f64-9911-4545-b3fc-2c963f12cab7\",\"oppositeBncId\":\"2d69d27-a59a-45a0-9d41-246930a580ce\",\"relationshipProperties\":[{\"type\":\"OWNERSHIP\",\"dataType\":\"PERCENTAGE\",\"dataFormat\":\"999.99\",\"value\":\"10.00\"}],\"lastUpdateDate\":\"2018-03-03T15:49:15.815\"}]}";
    MockResponse mockResponse =
        new MockResponse()
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody(response);
    mockMcpServer.enqueue(mockResponse);
    mcpService.getEndpoint().setPtyRelationship("relation");
    Mono<GetRelationshipsResponse> getRelationshipsResponseMono =
        mcpService.getPtyRelationshipMono("token",  "AUTHRZDREP","bnc");

    StepVerifier.create(getRelationshipsResponseMono)
                .expectNext(mapHelper(GetRelationshipsResponse.class, response))
                .verifyComplete();
  }

  @Test
  public void testGetRelationshipsByBncId_Error() {
    MockResponse mockResponse = new MockResponse().setResponseCode(500);

    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);

    mcpService.getEndpoint().setPtyRelationship("relation");
    Mono<GetRelationshipsResponse> getRelationshipsResponseMono =
        mcpService.getPtyRelationshipMono("token", "AUTHRZDREP", "bnc");

    StepVerifier.create(getRelationshipsResponseMono)
                .expectError(WebClientResponseException.class)
                .verify();
  }

  @Test
  public void testGetRelationshipBncId_EmptyBody() {
    MockResponse mockResponse =
        new MockResponse().addHeader("Content-Type", "application/json; charset=utf-8").setBody("");
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);

    mcpService.getEndpoint().setIndividual("test");

    Mono<GetRelationshipsResponse> ptyRelationshipMono =
        mcpService.getPtyRelationshipMono("token", "AUTHRZDREP", "bnc");

    StepVerifier.create(ptyRelationshipMono).expectError(InvalidResponseException.class).verify();
  }

/*  @Test
  public void testGetRelationshipsByBncId_SuccessAfterRetry() {
    String response =
        "{\"count\":\"5\",\"totalCount\":\"15\",\"relationships\":[{\"partyRelationType\":\"HOUSEHOLD\",\"initiatingPartyRole\":\"SPOUSE\",\"oppositePartyRole\":\"SPOUSE\",\"initiatingPartyType\":\"I\",\"oppositePartyType\":\"I\",\"initiatingBncId\":\"5fa23f64-9911-4545-b3fc-2c963f12cab7\",\"oppositeBncId\":\"2d69d27-a59a-45a0-9d41-246930a580ce\",\"relationshipProperties\":[{\"type\":\"OWNERSHIP\",\"dataType\":\"PERCENTAGE\",\"dataFormat\":\"999.99\",\"value\":\"10.00\"}],\"lastUpdateDate\":\"2018-03-03T15:49:15.815\"}]}";
    MockResponse mockResponseFail = new MockResponse().setResponseCode(500);
    MockResponse mockResponseSuccess =
        new MockResponse()
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody(response);

    mockMcpServer.enqueue(mockResponseFail);
    mockMcpServer.enqueue(mockResponseFail);
    mockMcpServer.enqueue(mockResponseSuccess);

    mcpService.getEndpoint().setPtyRelationship("relation");
    Mono<GetRelationshipsResponse> getRelationshipsResponseMono =
        mcpService.getPtyRelationshipMono("token", "AUTHRZDREP", "bnc");

    StepVerifier.create(getRelationshipsResponseMono)
                .expectNext(mapHelper(GetRelationshipsResponse.class, response))
                .verifyComplete();
  }*/

  @Test
  public void testPostSystemKeys_HappyPath() {
    String response =
        "{\"returnDate\":\"string\",\"returnStatusCode\":\"0\",\"returnStatusMessage\":\"string\"}";
    String request =
        "{\"addPartySysKeys\":{\"requestID\":\"string\",\"addPtyMember\":{\"memberIdNo\":\"string\",\"srcCd\":\"string\"},\"ptyId\":{\"partyIdentification\":{\"ptyIdentItemTypeCd\":\"BNCID\",\"ptyIdentItemNo\":\"0W4EF651E8AF9CV0B5B425FD47214B1D93C2CCC83B81691C2CC8275FAE0F31Q6\"}}}}";
    MockResponse mockResponse =
        new MockResponse()
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody(response);
    mockMcpServer.enqueue(mockResponse);
    mcpService.getEndpoint().setSystemKeys("syskey");
    Mono<StandardResponse> standardResponseMono =
        mcpService.postSystemKeysByBncId(
            mapHelper(AddPartySysKeyRequestBncId.class, request), "token", "id");

    StepVerifier.create(standardResponseMono)
                .expectNext(mapHelper(StandardResponse.class, response))
                .verifyComplete();
  }

  @Test
  public void testPostSystemKeys_Error() {
    MockResponse mockResponse =
        new MockResponse()
            .setResponseCode(500)
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody(
                "{\"returnDate\":\"2020-08-26T14:33:38\",\"returnStatusCode\":\"9000086\",\"returnStatusMessage\":\"Profile Not Found\"}");
    String request =
        "{\"addPartySysKeys\":{\"requestID\":\"string\",\"addPtyMember\":{\"memberIdNo\":\"string\",\"srcCd\":\"string\"},\"ptyId\":{\"partyIdentification\":{\"ptyIdentItemTypeCd\":\"BNCID\",\"ptyIdentItemNo\":\"0W4EF651E8AF9CV0B5B425FD47214B1D93C2CCC83B81691C2CC8275FAE0F31Q6\"}}}}";

    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);

    mcpService.getEndpoint().setSystemKeys("syskey");
    Mono<StandardResponse> standardResponseMono =
        mcpService.postSystemKeysByBncId(
            mapHelper(AddPartySysKeyRequestBncId.class, request), "token", "bnc");

    StepVerifier.create(standardResponseMono).expectError(AddSystemKeyException.class).verify();
  }

  @Test
  public void testPostSystemKey_EmptyBody() {
    MockResponse mockResponse =
        new MockResponse().addHeader("Content-Type", "application/json; charset=utf-8").setBody("");
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);

    mcpService.getEndpoint().setSystemKeys(":wq");

    Mono<StandardResponse> bnc =
        mcpService.postSystemKeysByBncId(new AddPartySysKeyRequestBncId(), "bnc", "id");

    StepVerifier.create(bnc).expectError(AddSystemKeyException.class).verify();
  }

  @Test
  public void testPostSystemKeys_AcceptedError() {
    MockResponse mockResponse =
        new MockResponse()
            .setResponseCode(500)
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody(
                "{\"returnDate\":\"2020-08-26T14:33:38\",\"returnStatusCode\":\"9000087\",\"returnStatusMessage\":\"System key already added to profile\"}");
    String request =
        "{\"addPartySysKeys\":{\"requestID\":\"string\",\"addPtyMember\":{\"memberIdNo\":\"string\",\"srcCd\":\"string\"},\"ptyId\":{\"partyIdentification\":{\"ptyIdentItemTypeCd\":\"BNCID\",\"ptyIdentItemNo\":\"0W4EF651E8AF9CV0B5B425FD47214B1D93C2CCC83B81691C2CC8275FAE0F31Q6\"}}}}";

    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);

    mcpService.getEndpoint().setSystemKeys("syskey");
    Mono<StandardResponse> standardResponseMono =
        mcpService.postSystemKeysByBncId(
            mapHelper(AddPartySysKeyRequestBncId.class, request), "token", "bnc");

    StepVerifier.create(standardResponseMono)
                .expectNextMatches(
                    standardResponse -> standardResponse.getReturnStatusCode().equalsIgnoreCase("9000087"))
                .verifyComplete();
  }

  @Test
  public void testPostSystemKeys_Error401() {
    MockResponse mockResponse =
        new MockResponse()
            .setResponseCode(401)
            .addHeader("Content-Type", "application/json; charset=utf-8");

    String request =
        "{\"addPartySysKeys\":{\"requestID\":\"string\",\"addPtyMember\":{\"memberIdNo\":\"string\",\"srcCd\":\"string\"},\"ptyId\":{\"partyIdentification\":{\"ptyIdentItemTypeCd\":\"BNCID\",\"ptyIdentItemNo\":\"0W4EF651E8AF9CV0B5B425FD47214B1D93C2CCC83B81691C2CC8275FAE0F31Q6\"}}}}";

    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);
    mockMcpServer.enqueue(mockResponse);

    mcpService.getEndpoint().setSystemKeys("syskey");
    Mono<StandardResponse> standardResponseMono =
        mcpService.postSystemKeysByBncId(
            mapHelper(AddPartySysKeyRequestBncId.class, request), "token", "bnc" );

    StepVerifier.create(standardResponseMono)
                .expectError(WebClientResponseException.class)
                .verify();
  }

/*  @Test
  public void testPostSystemKeys_SuccessAfterRetry() {
    String response = "{\"returnDate\":\"2020-08-26T14:33:38\",\"returnStatusCode\":\"0\"}";
    MockResponse mockResponseFail =
        new MockResponse()
            .setResponseCode(500)
            .setBody(
                "{\"returnDate\":\"2020-08-26T14:33:38\",\"returnStatusCode\":\"9000086\",\"returnStatusMessage\":\"Profile Not Found\"}");

    MockResponse mockResponseSuccess =
        new MockResponse()
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody(response);

    String request =
        "{\"addPartySysKeys\":{\"requestID\":\"string\",\"addPtyMember\":{\"memberIdNo\":\"string\",\"srcCd\":\"string\"},\"ptyId\":{\"partyIdentification\":{\"ptyIdentItemTypeCd\":\"BNCID\",\"ptyIdentItemNo\":\"0W4EF651E8AF9CV0B5B425FD47214B1D93C2CCC83B81691C2CC8275FAE0F31Q6\"}}}}";

    mockMcpServer.enqueue(mockResponseFail);
    mockMcpServer.enqueue(mockResponseFail);
    mockMcpServer.enqueue(mockResponseSuccess);

    mcpService.getEndpoint().setSystemKeys("syskey");
    Mono<StandardResponse> standardResponseMono =
        mcpService.postSystemKeysByBncId(
            mapHelper(AddPartySysKeyRequestBncId.class, request), "token", "bnc");

    StepVerifier.create(standardResponseMono)
                .expectNext(mapHelper(StandardResponse.class, response))
                .verifyComplete();
  }*/

  @Test
  public void getIndividualSuccessfully() throws IOException, URISyntaxException {
    mockMcpServer.enqueue(new MockResponse()
            .setResponseCode(200)
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody(JsonFileUtil.readString("service/mcp/get-individual-base-resp.json")));

    Mono<GetIndividualBaseResponse> responseMono = mcpService.getIndividual("fakeSystemId","fakeSrcCd", "fakeToken");

    StepVerifier.create(responseMono)
            .expectNext(JsonFileUtil.readObject("service/mcp/get-individual-base-resp.json",GetIndividualBaseResponse.class))
            .verifyComplete();
  }

  @Test
  public void createIndividualSuccessfully() throws IOException {
    mockMcpServer.enqueue(new MockResponse()
            .setResponseCode(200)
            .addHeader("Content-Type", "application/json; charset=utf-8"));

    Mono<CreateIndividualResponse> responseMono = mcpService.createIndividual("fakeSrcCd", JsonFileUtil.readObject("service/mcp/create-individual.json", CreateIndividualRequest.class) , "fakeToken");

    StepVerifier.create(responseMono)
            .verifyComplete();
  }

  @Test
  public void linkIndividualToOrganizationSuccessfully() throws IOException {
    mockMcpServer.enqueue(new MockResponse()
            .setResponseCode(200)
            .addHeader("Content-Type", "application/json; charset=utf-8"));

    Mono<Void> responseMono = mcpService.linkIndividualToOrganization(JsonFileUtil.readObject("service/mcp/link-organization.json", PostRelationship.class), "fakeToken");

    StepVerifier.create(responseMono)
            .verifyComplete();
  }

  @Test
  public void unlinkIndividualToOrganizationSuccessfully() throws IOException {
    mockMcpServer.enqueue(new MockResponse()
            .setResponseCode(200)
            .addHeader("Content-Type", "application/json; charset=utf-8"));

    Mono<Void> responseMono = mcpService.unlinkIndividualToOrganization("fakeUid", JsonFileUtil.readObject("service/mcp/unlink-organization.json", RemovedRelationship.class), "fakeToken");

    StepVerifier.create(responseMono)
            .verifyComplete();
  }

  @Test
  public void updateIndividualBaseSuccessfully() throws IOException {
    mockMcpServer.enqueue(new MockResponse()
            .setResponseCode(200)
            .addHeader("Content-Type", "application/json; charset=utf-8"));

    Mono<UpdateIndividualBaseResponse> responseMono = mcpService.updateIndividualBase(JsonFileUtil.readObject("service/mcp/update-individual.json", UpdateIndividualBaseRequest.class), "fakeToken");

    StepVerifier.create(responseMono)
            .verifyComplete();
  }

  @Test
  public void updateIndividualContactSuccessfully() throws IOException {
    mockMcpServer.enqueue(new MockResponse()
            .setResponseCode(200)
            .addHeader("Content-Type", "application/json; charset=utf-8"));

    Mono<UpdatePtyContactsResponse> responseMono = mcpService.updateIndividualContact("fakeBncId", JsonFileUtil.readObject("service/mcp/update-individual-contact.json", UpdatePtyContactsWithBNCIDRequest.class), "fakeToken");

    StepVerifier.create(responseMono)
            .verifyComplete();
  }

  @Test
  public void updateIndividualAddressSuccessfully() throws IOException {
    mockMcpServer.enqueue(new MockResponse()
            .setResponseCode(200)
            .addHeader("Content-Type", "application/json; charset=utf-8"));

    Mono<UpdatePtyAddressesResponse> responseMono = mcpService.updateIndividualAddress("fakeBncId", JsonFileUtil.readObject("service/mcp/update-individual-address.json", UpdatePtyAddressesRequest.class), "fakeToken");

    StepVerifier.create(responseMono)
            .verifyComplete();
  }

  @Test
  public void updateIndividualSocioSuccessfully() throws IOException {
    mockMcpServer.enqueue(new MockResponse()
            .setResponseCode(200)
            .addHeader("Content-Type", "application/json; charset=utf-8"));

    Mono<UpdateIndividualSocioDemographicsResponse> responseMono = mcpService.updateIndividualSocio("fakeBncId", JsonFileUtil.readObject("service/mcp/update-individual-socio.json", UpdateIndividualSocioDemographicsWithBNCIDRequest.class), "fakeToken");

    StepVerifier.create(responseMono)
            .verifyComplete();
  }

  @Test
  public void deleteSystemKeysByBncIdSuccessfully() throws IOException {
    mockMcpServer.enqueue(new MockResponse()
            .setResponseCode(200)
            .addHeader("Content-Type", "application/json; charset=utf-8"));

    Mono<StandardResponse> responseMono = mcpService.deleteSystemKeysByBncId("fakeBncId", JsonFileUtil.readObject("service/mcp/delete-system-key.json", RemovePartySysKeyRequestBncId.class), "fakeToken");

    StepVerifier.create(responseMono)
            .verifyComplete();
  }

  @Test
  public void getIndividualFailed() throws IOException {
    mockMcpServer.enqueue(new MockResponse()
            .setResponseCode(500)
            .addHeader("Content-Type", "application/json; charset=utf-8"));

    Mono<GetIndividualBaseResponse> responseMono = mcpService.getIndividual("fakeSystemId","fakeSrcCd", "fakeToken");

    StepVerifier.create(responseMono)
            .expectErrorMatches(throwable -> throwable instanceof McpWriteException && throwable.getMessage().equals(McpWriteException.FAILED_TO_LOOKUP_INDIVIDUAL_IN_MCP))
            .verify();
  }

  @Test
  public void getIndividualFailedEmptyBody() throws IOException {
    mockMcpServer.enqueue(new MockResponse()
            .setResponseCode(200)
            .addHeader("Content-Type", "application/json; charset=utf-8"));

    Mono<GetIndividualBaseResponse> responseMono = mcpService.getIndividual("fakeSystemId","fakeSrcCd", "fakeToken");

    StepVerifier.create(responseMono)
            .expectErrorMatches(throwable -> throwable instanceof McpWriteException && throwable.getMessage().equals(McpWriteException.FAILED_TO_LOOKUP_INDIVIDUAL_IN_MCP))
            .verify();
  }

  @Test
  public void createIndividualFailed() throws IOException {
    mockMcpServer.enqueue(new MockResponse()
            .setResponseCode(500)
            .addHeader("Content-Type", "application/json; charset=utf-8"));

    Mono<CreateIndividualResponse> responseMono = mcpService.createIndividual("fakeSrcCd", JsonFileUtil.readObject("service/mcp/create-individual.json", CreateIndividualRequest.class) , "fakeToken");

    StepVerifier.create(responseMono)
            .expectErrorMatches(throwable -> throwable instanceof McpWriteException && throwable.getMessage().equals(McpWriteException.FAILED_TO_CREATE_INDIVIDUAL_IN_MCP))
            .verify();
  }

  @Test
  public void linkIndividualToOrganizationFailed() throws IOException {
    mockMcpServer.enqueue(new MockResponse()
            .setResponseCode(500)
            .addHeader("Content-Type", "application/json; charset=utf-8"));

    Mono<Void> responseMono = mcpService.linkIndividualToOrganization(JsonFileUtil.readObject("service/mcp/link-organization.json", PostRelationship.class), "fakeToken");

    StepVerifier.create(responseMono)
            .expectErrorMatches(throwable -> throwable instanceof McpWriteException && throwable.getMessage().equals(McpWriteException.FAILED_TO_LINK_INDIVIDUAL_TO_ORGANIZATION_IN_MCP))
            .verify();
  }

  @Test
  public void unlinkIndividualToOrganizationFailed() throws IOException {
    mockMcpServer.enqueue(new MockResponse()
            .setResponseCode(500)
            .addHeader("Content-Type", "application/json; charset=utf-8"));

    Mono<Void> responseMono = mcpService.unlinkIndividualToOrganization("fakeUid", JsonFileUtil.readObject("service/mcp/unlink-organization.json", RemovedRelationship.class), "fakeToken");

    StepVerifier.create(responseMono)
            .expectErrorMatches(throwable -> throwable instanceof McpWriteException && throwable.getMessage().equals(McpWriteException.FAILED_TO_UNLINK_INDIVIDUAL_TO_ORGANIZATION_IN_MCP))
            .verify();
  }

  @Test
  public void updateIndividualBaseFailed() throws IOException {
    mockMcpServer.enqueue(new MockResponse()
            .setResponseCode(500)
            .addHeader("Content-Type", "application/json; charset=utf-8"));

    Mono<UpdateIndividualBaseResponse> responseMono = mcpService.updateIndividualBase(JsonFileUtil.readObject("service/mcp/update-individual.json", UpdateIndividualBaseRequest.class), "fakeToken");

    StepVerifier.create(responseMono)
            .expectErrorMatches(throwable -> throwable instanceof McpWriteException && throwable.getMessage().equals(McpWriteException.FAILED_TO_UPDATE_INDIVIDUAL_BASE_IN_MCP))
            .verify();
  }

  @Test
  public void updateIndividualContactFailed() throws IOException {
    mockMcpServer.enqueue(new MockResponse()
            .setResponseCode(500)
            .addHeader("Content-Type", "application/json; charset=utf-8"));

    Mono<UpdatePtyContactsResponse> responseMono = mcpService.updateIndividualContact("fakeBncId", JsonFileUtil.readObject("service/mcp/update-individual-contact.json", UpdatePtyContactsWithBNCIDRequest.class), "fakeToken");

    StepVerifier.create(responseMono)
            .expectErrorMatches(throwable -> throwable instanceof McpWriteException && throwable.getMessage().equals(McpWriteException.FAILED_TO_UPDATE_INDIVIDUAL_CONTACT_IN_MCP))
            .verify();
  }

  @Test
  public void updateIndividualAddressFailed() throws IOException {
    mockMcpServer.enqueue(new MockResponse()
            .setResponseCode(500)
            .addHeader("Content-Type", "application/json; charset=utf-8"));

    Mono<UpdatePtyAddressesResponse> responseMono = mcpService.updateIndividualAddress("fakeBncId", JsonFileUtil.readObject("service/mcp/update-individual-address.json", UpdatePtyAddressesRequest.class), "fakeToken");

    StepVerifier.create(responseMono)
            .expectErrorMatches(throwable -> throwable instanceof McpWriteException && throwable.getMessage().equals(McpWriteException.FAILED_TO_UPDATE_INDIVIDUAL_ADDRESS_IN_MCP))
            .verify();
  }

  @Test
  public void updateIndividualSocioFailed() throws IOException {
    mockMcpServer.enqueue(new MockResponse()
            .setResponseCode(500)
            .addHeader("Content-Type", "application/json; charset=utf-8"));

    Mono<UpdateIndividualSocioDemographicsResponse> responseMono = mcpService.updateIndividualSocio("fakeBncId", JsonFileUtil.readObject("service/mcp/update-individual-socio.json", UpdateIndividualSocioDemographicsWithBNCIDRequest.class), "fakeToken");

    StepVerifier.create(responseMono)
            .expectErrorMatches(throwable -> throwable instanceof McpWriteException && throwable.getMessage().equals(McpWriteException.FAILED_TO_UPDATE_INDIVIDUAL_SOCIO_DEMOGRAPHICS_IN_MCP))
            .verify();
  }

  @Test
  public void deleteSystemKeysByBncIdFailed() throws IOException {
    mockMcpServer.enqueue(new MockResponse()
            .setResponseCode(500)
            .addHeader("Content-Type", "application/json; charset=utf-8"));

    Mono<StandardResponse> responseMono = mcpService.deleteSystemKeysByBncId("fakeBncId", JsonFileUtil.readObject("service/mcp/delete-system-key.json", RemovePartySysKeyRequestBncId.class), "fakeToken");

    StepVerifier.create(responseMono)
            .expectErrorMatches(throwable -> throwable instanceof McpWriteException && throwable.getMessage().equals(McpWriteException.FAILED_TO_DELETE_SYSTEM_KEY_IN_MCP))
            .verify();
  }
}

