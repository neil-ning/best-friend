package ca.bnc.bne.mcp.event.orchestrator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;


@SpringBootTest
@ActiveProfiles({"integration"})
class McpEventOrchestratorApplicationTests {

	@Test
	void contextLoads() {
	}
}
