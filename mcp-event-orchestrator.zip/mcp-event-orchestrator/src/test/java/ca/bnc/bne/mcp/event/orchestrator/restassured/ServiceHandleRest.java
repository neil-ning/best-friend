package ca.bnc.bne.mcp.event.orchestrator.restassured;

import ca.bnc.bne.mcp.event.orchestrator.dto.okta.OktaResponse;
import ca.bnc.bne.mcp.event.orchestrator.service.okta.OktaService;
import ca.bnc.bne.mcp.event.orchestrator.util.JsonFileUtil;
import io.restassured.RestAssured;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.test.context.ActiveProfiles;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.concurrent.TimeUnit;

import static ca.bnc.bne.mcp.event.orchestrator.util.Constants.*;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.lessThan;
import static org.mockito.Mockito.when;

@ActiveProfiles("mock-webserver")
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class ServiceHandleRest {

    private MockResponseStrategyFactory factory;
    private MockResponseStrategyContext context;

    private static final String HEADER_AUTH_KEY = "Authorization";
    private static final String HEADER_AUTH_KEY_VAL = "Bearer oktaToken";

    @LocalServerPort
    private int port;

    //@MockBean
    private OktaService oktaService;

    private MockWebServer mockMcpServer;

    @Value("${mock.webserver.port:9999}")
    private int mockServerPort;

    @BeforeEach
    public void setup() throws IOException {
        RestAssured.baseURI = "http://localhost";
        RestAssured.port = this.port;

        //when(oktaService.cacheToken()).thenReturn(Mono.just(new OktaResponse().accessToken("fake")));

        factory = new MockResponseStrategyFactory();
        factory.addStrategy(new IamAccessTokenOkResponseStrategy());

        context = new MockResponseStrategyContext();

        MockDispatcher dispatcher = new MockDispatcher(factory, context);

        mockMcpServer = new MockWebServer();
        mockMcpServer.setDispatcher(dispatcher);
        mockMcpServer.start(mockServerPort);
    }

    @AfterEach
    void tearDown() throws IOException {
        System.out.println("Tearing down test");
        mockMcpServer.shutdown();
    }

    @Test
    public void whenCall_organization_company_thenReturnOK() {

        factory.addStrategy(new McpStandardOkResponseStrategy());

        given().log().all()
                .queryParam("bncId", "bncId")
                .queryParam("sysId", "sysId")
                .queryParam("srcCd", "srcCd")
                .header(HEADER_AUTH_KEY, HEADER_AUTH_KEY_VAL)
                .header("requestId", "requestId")
                .when().log().all()
                .patch(REST_API_PATH_SERVICE_ORGANIZATION)
                .then().log().all()
                .assertThat()
                .time(lessThan(10L), TimeUnit.SECONDS)
                .statusCode(200)
                .and().body("Status", equalTo(0));

    }

    @Test
    public void whenCall_organization_company_thenReturnBadAccessTokenResponse() {

        factory.replaceStrategy(new IamAccessTokenBadResponseStrategy());

        given().queryParam("bncId", "bncId")
                .queryParam("sysId", "sysId")
                .queryParam("srcCd", "srcCd")
                .header(HEADER_AUTH_KEY, HEADER_AUTH_KEY_VAL)
                .header("requestId", "requestId")
                .when().log().all().patch(REST_API_PATH_SERVICE_ORGANIZATION)
                .then().log().all().assertThat().statusCode(500);

    }

    @Test
    public void whenCall_organization_company_thenReturnBadResponse() {

        factory.addStrategy(new McpSystemKeysBadResponseStrategy());

        given().queryParam("bncId", "bncId")
                .queryParam("sysId", "sysId")
                .queryParam("srcCd", "srcCd")
                .header(HEADER_AUTH_KEY, HEADER_AUTH_KEY_VAL)
                .header("requestId", "requestId")
                .when().log().all().patch(REST_API_PATH_SERVICE_ORGANIZATION)
                .then().log().all().assertThat().statusCode(500);

    }

    @Test
    public void whenCall_individualAdmin_thenReturnOK() {

        factory.replaceStrategy(new McpStandardOkResponseStrategy());

        given().queryParam("bncId", "bncId")
                .queryParam("sysId", "sysId")
                .queryParam("srcCd", "srcCd")
                .header(HEADER_AUTH_KEY, HEADER_AUTH_KEY_VAL)
                .header("requestId", "requestId")
                .when().log().all().patch(REST_API_PATH_SERVICE_ADMIN)
                .then().log().all().assertThat().statusCode(200)
                .and().body("Status", equalTo(0));

    }

    @Test
    public void whenCall_individualAdmin_thenReturnBadIamAccessTokenResponse() {

        factory.replaceStrategy(new IamAccessTokenBadResponseStrategy());

        given().log().all()
                .queryParam("bncId", "bncId")
                .queryParam("sysId", "sysId")
                .queryParam("srcCd", "srcCd")
                .header(HEADER_AUTH_KEY, HEADER_AUTH_KEY_VAL)
                .header("requestId", "requestId")
                .when().log().all()
                .patch(REST_API_PATH_SERVICE_ADMIN)
                .then().log().all()
                .assertThat()
                .statusCode(500);

    }

    @Test
    public void whenCall_individualAdmin_thenReturnBadResponse() {

        factory.replaceStrategy(new McpSystemKeysBadResponseStrategy());

        given().log().all()
                .queryParam("bncId", "bncId")
                .queryParam("sysId", "sysId")
                .queryParam("srcCd", "srcCd")
                .header(HEADER_AUTH_KEY, HEADER_AUTH_KEY_VAL)
                .header("requestId", "requestId")
                .when().log().all()
                .patch(REST_API_PATH_SERVICE_ADMIN)
                .then().log().all()
                .assertThat()
                .statusCode(500);

    }

    @Test
    public void whenCall_createIndividual_thenReturnOk() throws IOException, URISyntaxException {

        factory.addStrategy(new McpCreateIndividualOkResponseStrategy());
        factory.addStrategy(new McpStandardOkResponseStrategy());
        factory.addStrategy(new McpLinkPartyRelationshipOkRespStrategy());

        given().queryParam("orgBncId", "orgBncId")
                .header(HEADER_AUTH_KEY, HEADER_AUTH_KEY_VAL)
                .header("requestId", "requestId")
                .header("Content-Type", "application/json")
                .request()
                .body(JsonFileUtil.readString("service/mcp/create-individual.json"))
                .when().log().all().post(REST_API_PATH_SERVICE_USER)
                .then().log().all().assertThat().statusCode(201);

    }

    @Test
    public void whenCall_createIndividual_thenReturnBad() throws IOException, URISyntaxException {

        factory.addStrategy(new McpCreateIndividualOkResponseStrategy());
        factory.addStrategy(new McpSystemKeysBadResponseStrategy());
        factory.addStrategy(new McpLinkPartyRelationshipOkRespStrategy());

        given().queryParam("orgBncId", "orgBncId")
                .header(HEADER_AUTH_KEY, HEADER_AUTH_KEY_VAL)
                .header("requestId", "requestId")
                .header("Content-Type", "application/json")
                .body(JsonFileUtil.readString("service/mcp/create-individual.json"))
                .when().log().all().post(REST_API_PATH_SERVICE_USER)
                .then().assertThat().log().status().statusCode(500).log().body();

    }

    @Test
    public void whenCall_updateIndividual_thenReturnOk() throws IOException, URISyntaxException {

        //factory.addStrategy(new McpUpdateIndividualBaseOkResponseStrategy());
        factory.addStrategy(new McpUpdateIndividualBaseByBncIdOkResponseStrategy());
        factory.addStrategy(new McpGetIndividualBaseOkResponse());
        factory.addStrategy(new McpUpdateIndvPtyAddressOkResponseStrategy());
        factory.addStrategy(new McpIndvPtyContactsOkResponseStrategy());
        factory.addStrategy(new McpGetSocioOkResponseStrategy());
        factory.addStrategy(new McpUpdateIndvSocioOkResponseStrategy());

        given().queryParam("userBncId", "bncId")
                .header(HEADER_AUTH_KEY, HEADER_AUTH_KEY_VAL)
                .header("requestId", "requestId")
                .header("Content-Type", "application/json")
                .body(JsonFileUtil.readString("service/mcp/update-individual-new.json"))
                .when().log().all().put(REST_API_PATH_SERVICE_USER)
                .then().assertThat().log().status().statusCode(200).log().body();

    }

    @Test
    public void whenCall_updateIndividual_thenReturnBad() throws IOException, URISyntaxException {

        factory.addStrategy(new McpGetIndividualBaseOkResponse());
        factory.addStrategy(new McpUpdateIndividualBaseBadResponseStrategy());
        factory.addStrategy(new McpUpdateIndvPtyAddressOkResponseStrategy());
        factory.addStrategy(new McpIndvPtyContactsOkResponseStrategy());
        factory.addStrategy(new McpUpdateIndvSocioOkResponseStrategy());

        given().queryParam("userBncId", "bncId")
                .header(HEADER_AUTH_KEY, HEADER_AUTH_KEY_VAL)
                .header("requestId", "requestId")
                .header("Content-Type", "application/json")
                .body(JsonFileUtil.readString("service/mcp/update-individual-new.json"))
                .when().log().all().put(REST_API_PATH_SERVICE_USER)
                .then().assertThat().log().status().statusCode(500).log().body();

    }

    @Test
    public void whenCall_deleteIndividual_thenReturnOk() throws IOException, URISyntaxException {

        factory.addStrategy(new McpGetIndividualBaseOkResponse());
        factory.addStrategy(new McpGetPtyrelationshipsOkResponseStrategy());

        factory.addStrategy(new McpDelPtyrelationshipOkReponseStrategy());
        factory.addStrategy(new McpStandardOkResponseStrategy());

        given().queryParam("userBncId", "bncId")
                .queryParam("userSysId", "individualSysId")
                .queryParam("srcCd", "srcCd")
                .queryParam("relationshipId", "relationshipId")
                .header(HEADER_AUTH_KEY, HEADER_AUTH_KEY_VAL)
                .header("requestId", "requestId")
                .header("Content-Type", "application/json")
                .when().log().all().delete(REST_API_PATH_SERVICE_USER)
                .then().assertThat().log().status().statusCode(204).log().body();

    }

    @Test
    public void whenCall_deleteIndividual_thenReturnBad() throws IOException, URISyntaxException {

        factory.addStrategy(new McpGetIndividualBaseOkResponse());
        factory.addStrategy(new McpGetPtyrelationshipsOkResponseStrategy());
        factory.addStrategy(new McpDelPtyrelationshipOkReponseStrategy());

        factory.addStrategy(new McpStandardBadResponseStrategy());

        given().queryParam("userBncId", "bncId")
                .queryParam("userSysId", "individualSysId")
                .queryParam("srcCd", "srcCd")
                .queryParam("relationshipId", "relationshipId")
                .header(HEADER_AUTH_KEY, HEADER_AUTH_KEY_VAL)
                .header("requestId", "requestId")
                .header("Content-Type", "application/json")
                .when().log().all().delete(REST_API_PATH_SERVICE_USER)
                .then().assertThat().log().status().statusCode(500).log().body();

    }
}
