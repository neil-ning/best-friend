package ca.bnc.bne.mcp.event.orchestrator.service.bne;

import ca.bnc.bne.mcp.event.orchestrator.exception.model.GccBusinessRuleException;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.IndividualRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.OrganizationInput;
import java.io.IOException;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.test.StepVerifier;

class BneServiceTest {

  private MockWebServer mockWebServer;
  private BneService bneService;

  @BeforeEach
  void setUp() throws IOException {
    mockWebServer = new MockWebServer();
    mockWebServer.start();
  }

  @AfterEach
  void tearDown() throws IOException {
    mockWebServer.shutdown();
  }

  @BeforeEach
  void initialize() {
    String baseUrl = String.format("http://localhost:%s", mockWebServer.getPort());
    bneService = new BneService(WebClient.builder());
    bneService.setEndpoint(new BneService.Endpoint());
  }

  @Test
  public void createOrganizationTest_Error() {

    String response =
        "{\"Status\":400,\"Message\":\"string\",\"GccNbr\":\"string\",\"RequestId\":\"string\"}";
    MockResponse mockResponse =
        new MockResponse()
            .setResponseCode(400)
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody("");

    String baseUrl = String.format("http://localhost:%s", mockWebServer.getPort());
    bneService.getEndpoint().setOrganization(baseUrl + "/organization");
    mockWebServer.enqueue(mockResponse);
    mockWebServer.enqueue(mockResponse);
    mockWebServer.enqueue(mockResponse);
    mockWebServer.enqueue(mockResponse);

    StepVerifier.create(bneService.createOrganization(new OrganizationInput(), EventRequest.TargetSystemEnum.GCC.toString()))
        .expectError(GccBusinessRuleException.class)
        .verify();
  }

  @Test
  public void updateOrganizationTest_Error() {
    String response =
        "{\"Status\":400,\"Message\":\"string\",\"GccNbr\":\"string\",\"RequestId\":\"string\"}";
    MockResponse mockResponse =
        new MockResponse()
            .setResponseCode(400)
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody("");

    String baseUrl = String.format("http://localhost:%s", mockWebServer.getPort());
    bneService.getEndpoint().setOrganization(baseUrl + "/organization");
    mockWebServer.enqueue(mockResponse);
    mockWebServer.enqueue(mockResponse);
    mockWebServer.enqueue(mockResponse);
    mockWebServer.enqueue(mockResponse);

    StepVerifier.create(bneService.updateOrganization(new OrganizationInput(), EventRequest.TargetSystemEnum.GCC.toString()))
        .expectError(GccBusinessRuleException.class)
        .verify();
  }

  @Test
  public void deleteOrganizationTest_Error() {
    String response =
        "{\"Status\":400,\"Message\":\"string\",\"GccNbr\":\"string\",\"RequestId\":\"string\"}";
    MockResponse mockResponse =
        new MockResponse()
            .setResponseCode(400)
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody("");

    String baseUrl = String.format("http://localhost:%s", mockWebServer.getPort());
    bneService.getEndpoint().setOrganization(baseUrl + "/organization");
    mockWebServer.enqueue(mockResponse);
    mockWebServer.enqueue(mockResponse);
    mockWebServer.enqueue(mockResponse);
    mockWebServer.enqueue(mockResponse);

    StepVerifier.create(bneService.deleteOrganization(new OrganizationInput(), EventRequest.TargetSystemEnum.GCC.toString()))
        .expectError(GccBusinessRuleException.class)
        .verify();
  }

  @Test
  public void createOrganizationTest_HappyPath() {
    String response =
        "{\"Status\":200,\"Message\":\"string\",\"GccNbr\":\"string\",\"RequestId\":\"string\"}";
    MockResponse mockResponse =
        new MockResponse()
            .setResponseCode(200)
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody(response);

    String baseUrl = String.format("http://localhost:%s", mockWebServer.getPort());
    bneService.getEndpoint().setOrganization(baseUrl + "/organization");
    mockWebServer.enqueue(mockResponse);

    StepVerifier.create(bneService.createOrganization(new OrganizationInput(), EventRequest.TargetSystemEnum.GCC.toString()))
        .expectNextMatches(organizationResponse -> organizationResponse.getStatus() == 200)
        .verifyComplete();
  }

  @Test
  public void updateOrganizationTest_HappyPath() {
    String response =
        "{\"Status\":200,\"Message\":\"string\",\"GccNbr\":\"string\",\"RequestId\":\"string\"}";
    MockResponse mockResponse =
        new MockResponse()
            .setResponseCode(200)
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody(response);

    String baseUrl = String.format("http://localhost:%s", mockWebServer.getPort());
    bneService.getEndpoint().setOrganization(baseUrl + "/organization");
    mockWebServer.enqueue(mockResponse);

    StepVerifier.create(bneService.updateOrganization(new OrganizationInput(), EventRequest.TargetSystemEnum.GCC.toString()))
        .expectNextMatches(organizationResponse -> organizationResponse.getStatus() == 200)
        .verifyComplete();
  }

  @Test
  public void deleteOrganizationTest_HappyPath() {
    String response =
        "{\"Status\":200,\"Message\":\"string\",\"GccNbr\":\"string\",\"RequestId\":\"string\"}";
    MockResponse mockResponse =
        new MockResponse()
            .setResponseCode(200)
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody(response);

    String baseUrl = String.format("http://localhost:%s", mockWebServer.getPort());
    bneService.getEndpoint().setOrganization(baseUrl + "/organization");
    mockWebServer.enqueue(mockResponse);

    StepVerifier.create(bneService.deleteOrganization(new OrganizationInput(), EventRequest.TargetSystemEnum.GCC.toString()))
        .expectNextMatches(organizationResponse -> organizationResponse.getStatus() == 200)
        .verifyComplete();
  }

  @Test
  public void createIndividualTest_Error() {
    MockResponse mockResponse =
        new MockResponse()
            .setResponseCode(400)
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody("");

    String baseUrl = String.format("http://localhost:%s", mockWebServer.getPort());
    bneService.getEndpoint().setIndividual(baseUrl + "/individual");
    mockWebServer.enqueue(mockResponse);
    mockWebServer.enqueue(mockResponse);
    mockWebServer.enqueue(mockResponse);
    mockWebServer.enqueue(mockResponse);

    StepVerifier.create(bneService.createIndividual(new IndividualRequest(), "GCC"))
        .expectError(GccBusinessRuleException.class)
        .verify();
  }

  @Test
  public void updateIndividualTest_Error() {
    MockResponse mockResponse =
        new MockResponse()
            .setResponseCode(400)
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody("");

    String baseUrl = String.format("http://localhost:%s", mockWebServer.getPort());
    bneService.getEndpoint().setIndividual(baseUrl + "/individual");
    mockWebServer.enqueue(mockResponse);
    mockWebServer.enqueue(mockResponse);
    mockWebServer.enqueue(mockResponse);
    mockWebServer.enqueue(mockResponse);

    StepVerifier.create(bneService.updateIndividual(new IndividualRequest(), "GCC"))
        .expectError(GccBusinessRuleException.class)
        .verify();
  }

  @Test
  public void deleteIndividualTest_Error() {
    MockResponse mockResponse =
        new MockResponse()
            .setResponseCode(400)
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody("");

    String baseUrl = String.format("http://localhost:%s", mockWebServer.getPort());
    bneService.getEndpoint().setIndividual(baseUrl + "/individual");
    mockWebServer.enqueue(mockResponse);
    mockWebServer.enqueue(mockResponse);
    mockWebServer.enqueue(mockResponse);
    mockWebServer.enqueue(mockResponse);

    StepVerifier.create(bneService.deleteIndividual(new IndividualRequest(), "GCC"))
        .expectError(GccBusinessRuleException.class)
        .verify();
  }

  @Test
  public void createIndividualTest_HappyPath() {
    String response = "{\"code\":200,\"message\":\"string\"}";
    MockResponse mockResponse =
        new MockResponse()
            .setResponseCode(200)
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody(response);

    String baseUrl = String.format("http://localhost:%s", mockWebServer.getPort());
    bneService.getEndpoint().setIndividual(baseUrl + "/individual");
    mockWebServer.enqueue(mockResponse);

    StepVerifier.create(bneService.createIndividual(new IndividualRequest(), "GCC"))
        .expectNextMatches(individualResponse -> individualResponse.getCode() == 200)
        .verifyComplete();
  }

  @Test
  public void updateIndividualTest_HappyPath() {
    String response = "{\"code\":200,\"message\":\"string\"}";

    MockResponse mockResponse =
        new MockResponse()
            .setResponseCode(200)
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody(response);

    String baseUrl = String.format("http://localhost:%s", mockWebServer.getPort());
    bneService.getEndpoint().setIndividual(baseUrl + "/individual");
    mockWebServer.enqueue(mockResponse);

    StepVerifier.create(bneService.updateIndividual(new IndividualRequest(), "GCC"))
        .expectNextMatches(individualResponse -> individualResponse.getCode() == 200)
        .verifyComplete();
  }

  @Test
  public void deleteIndividualTest_HappyPath() {
    String response = "{\"code\":200,\"message\":\"string\"}";
    MockResponse mockResponse =
        new MockResponse()
            .setResponseCode(200)
            .addHeader("Content-Type", "application/json; charset=utf-8")
            .setBody(response);

    String baseUrl = String.format("http://localhost:%s", mockWebServer.getPort());
    bneService.getEndpoint().setIndividual(baseUrl + "/individual");
    mockWebServer.enqueue(mockResponse);

    StepVerifier.create(bneService.deleteIndividual(new IndividualRequest(), "GCC"))
        .expectNextMatches(individualResponse -> individualResponse.getCode() == 200)
        .verifyComplete();
  }
}
