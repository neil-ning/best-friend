package ca.bnc.bne.mcp.event.orchestrator.handler.individual;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import ca.bnc.bne.mcp.event.orchestrator.exception.model.InvalidResponseException;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.General;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.IndividualRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.IndividualResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.Other;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.Profile;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.Profile.SexEnum;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventAction;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventAction.BusinessObjectEnum;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventAction.TechnicalActionEnum;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventInformation;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventInformation.PartyActionEnum;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventInformation.PartyTypeEnum;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.PartyKey;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.StandardResponse;
import ca.bnc.bne.mcp.event.orchestrator.handler.EventTargetSystem;
import ca.bnc.bne.mcp.event.orchestrator.mapper.EventMapper;
import ca.bnc.bne.mcp.event.orchestrator.mapper.individual.IndividualMapper;
import ca.bnc.bne.mcp.event.orchestrator.mapper.individual.IndividualMapperImpl;
import ca.bnc.bne.mcp.event.orchestrator.service.bne.BneService;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

public class IndividualHandlerTest {

  @InjectMocks private IndividualEventHandler individualHandler;

  @Mock private EventMapper eventMapper;

  @Mock private BneService bneService;

  @Mock private IndividualMapper mapper;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.initMocks(this);
    individualHandler.setIndividualMapper((IndividualMapper) new IndividualMapperImpl());
  }

  private EventRequest buildRequest(
          BusinessObjectEnum bo,
          PartyKey partyKey,
          TechnicalActionEnum ta,
          PartyActionEnum pa,
          String messageId,
          EventRequest.TargetSystemEnum targetSystem) {

    return new EventRequest()
        .messageId(messageId)
        .eventInformation(
            new EventInformation()
                .partyKey(partyKey)
                .eventAction(new EventAction().technicalAction(ta).businessObject(bo))
                .partyAction(pa)
                .partyType(PartyTypeEnum.I))
            .targetSystem(targetSystem);
  }

  @Test
  public void testAddGccIdToSysKeys_ErrorResponse() {
    when(eventMapper.addNewGccIdToMcpSystemKeys(anyString(), any(), any(), any()))
        .thenReturn(
            Mono.error(() -> new WebClientResponseException(400, "bad req", null, null, null)));
    Mono<StandardResponse> mono =
        individualHandler.addGccIdToSystemKeys(
            "message", "bnc", new IndividualResponse().message("gcc"), EventTargetSystem.GCC.label);
    StepVerifier.create(mono).expectError(WebClientResponseException.class).verify();
  }

  @Test
  public void testAddGccIdToSystemKeys_EmptyResponse() {
    when(eventMapper.addNewGccIdToMcpSystemKeys(any(), any(), any(), any()))
        .thenReturn(Mono.just(new StandardResponse().returnStatusCode("0")));
    Mono<StandardResponse> responseMono =
        individualHandler.addGccIdToSystemKeys("mesage", "bnc", new IndividualResponse(), EventTargetSystem.GCC.label);
    StepVerifier.create(responseMono)
        .expectNextMatches(
            standardResponse -> standardResponse.getReturnStatusCode().equalsIgnoreCase("200"))
        .verifyComplete();
  }

  @Test
  public void testAddGccIdToSystemKeys_HappyPath() {
    when(eventMapper.addNewGccIdToMcpSystemKeys(any(), any(), any(), any()))
        .thenReturn(Mono.just(new StandardResponse().returnStatusCode("0")));
    Mono<StandardResponse> responseMono =
        individualHandler.addGccIdToSystemKeys(
            "mesage", "bnc", new IndividualResponse().message("gcc"), EventTargetSystem.GCC.label);
    StepVerifier.create(responseMono)
        .expectNextMatches(
            standardResponse -> standardResponse.getReturnStatusCode().equalsIgnoreCase("0"))
        .verifyComplete();
  }

  @Test
  public void testBuildIndividualRequestWithMergeInfo() {
    List<String> mergerId = List.of("merge1", "merge2");

    StepVerifier.create(
            individualHandler.buildIndividualRequestWithMergeInfo(
                mergerId, new IndividualRequest()))
        .expectNextMatches(r -> r.getGeneral().getNewIndBncId().equalsIgnoreCase("merge1"))
        .expectNextMatches(r -> r.getGeneral().getNewIndBncId().equalsIgnoreCase("merge2"))
        .verifyComplete();
  }

  @Test
  public void testBuildIndividualRequestWithMergeInfo_NoMerge() {
    StepVerifier.create(
            individualHandler.buildIndividualRequestWithMergeInfo(
                new ArrayList<>(), new IndividualRequest()))
        .expectNext(new IndividualRequest().general(new General()))
        .verifyComplete();
  }

  @Test
  public void testBuildIndividualRequestWithGccInfo() {
    List<String> gccId = List.of("gcc1", "gcc2");

    StepVerifier.create(
            individualHandler.buildIndividualRequestWithMemberIds(
                new IndividualRequest(), gccId))
        .expectNextMatches(r -> r.getGeneral().getIndGccNbr().equalsIgnoreCase("gcc1"))
        .expectNextMatches(r -> r.getGeneral().getIndGccNbr().equalsIgnoreCase("gcc2"))
        .verifyComplete();
  }

  @Test
  public void testBuildIndividualRequestWithGccInfo_NoGcc() {
    StepVerifier.create(
            individualHandler.buildIndividualRequestWithMemberIds(
                new IndividualRequest(), new ArrayList<>()))
        .expectNext(new IndividualRequest().general(new General()))
        .verifyComplete();
  }

  @Test
  public void testBuildIndividualWithOrganizationInfo_HappyPath() {
    IndividualRequest org1 =
        new IndividualRequest().general(new General().orgBncId("orgbnc").orgGccNbr("orggcc"));
    IndividualRequest org2 =
        new IndividualRequest().general(new General().orgBncId("orgbnc2").orgGccNbr("orggcc2"));

    when(eventMapper.relatedOrganizationIdsFromIndividualFlux(any(), anyString()))
        .thenReturn(Flux.just(org1, org2));
    Flux<IndividualRequest> requestFlux =
        individualHandler.buildIndividualRequestWithOrganizationInfo(
            true, new IndividualRequest().requestId("requestId"), "GCC");

    StepVerifier.create(requestFlux)
        .expectNext(org1.requestId("requestId"), org2.requestId("requestId"))
        .verifyComplete();
  }

  @Test
  public void testBuildIndividualOrgInfo_NoOrgInfo() {
    when(eventMapper.relatedOrganizationIdsFromIndividualFlux(any(), anyString())).thenReturn(Flux.empty());

    StepVerifier.create(
            individualHandler.buildIndividualRequestWithOrganizationInfo(
                true, new IndividualRequest().requestId("req"), "GCC"))
        .expectComplete()
        .verify();
  }

  @Test
  public void testBuildIndOrgInfo_Error() {
    when(eventMapper.relatedOrganizationIdsFromIndividualFlux(any(), anyString()))
        .thenReturn(Flux.error(InvalidResponseException::new));

    Flux<IndividualRequest> flux =
        individualHandler.buildIndividualRequestWithOrganizationInfo(true, new IndividualRequest(), "GCC");
    StepVerifier.create(flux).verifyError();
  }

  @Test
  public void testBuildIndividualRequestMono_HappyPath() {
    IndividualRequest r1 =
        new IndividualRequest()
            .profile(new Profile().birthday("bday").firstname("fn").lastname("ln"));
    IndividualRequest r2 =
        new IndividualRequest().profile(new Profile().cell("cell").email("email"));
    Mono<IndividualRequest> mono =
        individualHandler.buildIndividualRequestMono(List.of(Mono.just(r1), Mono.just(r2)));

    StepVerifier.create(mono)
        .expectNext(r1.profile(r1.getProfile().cell("cell").email("email")))
        .verifyComplete();
  }

  @Test
  public void testBuildRequest_NoMonos() {
    Mono<IndividualRequest> individualRequestMono =
        individualHandler.buildIndividualRequestMono(
            List.of(Mono.empty(), Mono.just(new IndividualRequest().requestId("req"))));

    StepVerifier.create(individualRequestMono).expectError(InvalidResponseException.class).verify();
  }

  @Test
  public void testBuildRequest_MonoError() {
    Mono<IndividualRequest> mono =
        individualHandler.buildIndividualRequestMono(
            List.of(
                Mono.just(new IndividualRequest()),
                Mono.error(() -> new InvalidResponseException("exception"))));
    StepVerifier.create(mono).expectError(InvalidResponseException.class).verify();
  }

  @Test
  public void testDeleteIndRelationship_HappyPath() {
    IndividualRequest r1 =
        new IndividualRequest().general(new General().orgGccNbr("orgGcc").orgBncId("orgBnc"));
    PartyKey partyKey =
        new PartyKey()
            .mergeInformation(List.of("merge1"))
            .memberIds(List.of("gcc1"))
            .partyRole(PartyKey.PartyRoleEnum.MERGEE)
            .bncId("bnc");

    when(eventMapper.relatedOrganizationIdsFromIndividualFlux(any(), anyString())).thenReturn(Flux.just(r1));
    when(bneService.deleteIndividual(any(), anyString()))
        .thenReturn(Mono.just(new IndividualResponse().message("newGcc")));

    when(eventMapper.addNewGccIdToMcpSystemKeys(anyString(), any(), any(), any()))
        .thenReturn(Mono.just(new StandardResponse().returnStatusCode("0")));
    when(eventMapper.baseIndividualMono(any(),anyString())).thenReturn(Mono.just(r1));
    when(eventMapper.individualSocioDemoMono(any(), anyString())).thenReturn(Mono.just(r1));
    when(eventMapper.individualPtyIdentificationMono(any(), anyString())).thenReturn(Mono.just(r1));
    when(eventMapper.individualContactMono(any(), anyString())).thenReturn(Mono.just(r1));

    Mono<Void> mono =
        individualHandler.invoke(
            buildRequest(
                BusinessObjectEnum.ROLERLNTP,
                partyKey,
                TechnicalActionEnum.DELETE,
                PartyActionEnum.MERGE,
                "message", EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(mono).expectComplete().verify();
  }

  @Test
  public void testDeleteIndividualSystemKeys_HappyPath() {
    PartyKey partyKey =
        new PartyKey()
            .mergeInformation(List.of("merge1"))
            .memberIds(List.of("gcc1"))
            .partyRole(PartyKey.PartyRoleEnum.MERGEE)
            .bncId("bnc");

    when(bneService.deleteIndividual(any(), anyString()))
        .thenReturn(Mono.just(new IndividualResponse().message("newGcc")));
    when(eventMapper.relatedOrganizationIdsFromIndividualFlux(any(), anyString())).thenReturn(Flux.empty());

    when(eventMapper.addNewGccIdToMcpSystemKeys(anyString(), any(), any(), any()))
        .thenReturn(Mono.just(new StandardResponse().returnStatusCode("0")));

    Mono<Void> mono =
        individualHandler.invoke(
            buildRequest(
                BusinessObjectEnum.SYSTEMKEY,
                partyKey,
                TechnicalActionEnum.DELETE,
                PartyActionEnum.MERGE,
                "message", EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(mono).expectComplete().verify();
  }

  @Test
  public void testDeleteIndividualSocioDemo_HappyPath() {
    IndividualRequest r1 = new IndividualRequest().profile(new Profile().sex(SexEnum._1));
    PartyKey partyKey =
        new PartyKey()
            .mergeInformation(List.of("merge1"))
            .memberIds(List.of("gcc1"))
            .partyRole(PartyKey.PartyRoleEnum.MERGEE)
            .bncId("bnc");
    when(eventMapper.individualSocioDemoMono(any(),anyString())).thenReturn(Mono.just(r1));
    when(bneService.deleteIndividual(any(), anyString())).thenReturn(Mono.just(new IndividualResponse()));
    when(eventMapper.relatedOrganizationIdsFromIndividualFlux(any(), anyString())).thenReturn(Flux.empty());

    Mono<Void> mono =
        individualHandler.invoke(
            buildRequest(
                BusinessObjectEnum.SOCIODEMO,
                partyKey,
                TechnicalActionEnum.DELETE,
                PartyActionEnum.MERGE,
                "message", EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(mono).expectComplete().verify();
  }

  @Test
  public void testDeleteId_HappyPath() {
    IndividualRequest r1 =
        new IndividualRequest()
            .other(new Other().identificationType1("id1").identificationValue1("v1"));
    PartyKey partyKey =
        new PartyKey()
            .mergeInformation(List.of("merge1"))
            .memberIds(List.of("gcc1"))
            .partyRole(PartyKey.PartyRoleEnum.MERGEE)
            .bncId("bnc");
    when(eventMapper.individualPtyIdentificationMono(any(), anyString())).thenReturn(Mono.just(r1));
    when(bneService.deleteIndividual(any(), anyString())).thenReturn(Mono.just(new IndividualResponse()));
    when(eventMapper.relatedOrganizationIdsFromIndividualFlux(any(), anyString())).thenReturn(Flux.empty());

    Mono<Void> mono =
        individualHandler.invoke(
            buildRequest(
                BusinessObjectEnum.PTYEXTID,
                partyKey,
                TechnicalActionEnum.DELETE,
                PartyActionEnum.MERGE,
                "message", EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(mono).expectComplete().verify();
  }

  @Test
  public void testDeleteContact_HappyPath() {
    IndividualRequest r1 = new IndividualRequest().profile(new Profile().cell("cell"));
    PartyKey partyKey =
        new PartyKey()
            .mergeInformation(List.of("merge1"))
            .memberIds(List.of("gcc1"))
            .partyRole(PartyKey.PartyRoleEnum.MERGEE)
            .bncId("bnc");
    when(eventMapper.individualContactMono(any(), anyString())).thenReturn(Mono.just(r1));
    when(eventMapper.relatedOrganizationIdsFromIndividualFlux(any(),anyString())).thenReturn(Flux.empty());
    when(bneService.deleteIndividual(any(), anyString())).thenReturn(Mono.just(new IndividualResponse()));

    Mono<Void> mono =
        individualHandler.invoke(
            buildRequest(
                BusinessObjectEnum.PTYCTCMETH,
                partyKey,
                TechnicalActionEnum.DELETE,
                PartyActionEnum.MERGE,
                "message", EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(mono).expectComplete().verify();
  }

  @Test
  public void testDeleteBaseInd_HappyPath() {
    IndividualRequest r1 = new IndividualRequest();
    PartyKey partyKey =
        new PartyKey()
            .mergeInformation(List.of("merge1"))
            .memberIds(List.of("gcc1"))
            .partyRole(PartyKey.PartyRoleEnum.MERGEE)
            .bncId("bnc");
    when(eventMapper.baseIndividualMono(any(),anyString())).thenReturn(Mono.just(r1));
    when(eventMapper.individualSocioDemoMono(any(),anyString())).thenReturn(Mono.just(r1));
    when(eventMapper.individualPtyIdentificationMono(any(),anyString())).thenReturn(Mono.just(r1));
    when(eventMapper.individualContactMono(any(),anyString())).thenReturn(Mono.just(r1));

    when(bneService.deleteIndividual(any(), anyString())).thenReturn(Mono.just(new IndividualResponse()));
    when(eventMapper.relatedOrganizationIdsFromIndividualFlux(any(),anyString())).thenReturn(Flux.empty());

    Mono<Void> mono =
        individualHandler.invoke(
            buildRequest(
                BusinessObjectEnum.ROLERLNTP,
                partyKey,
                TechnicalActionEnum.DELETE,
                PartyActionEnum.MERGE,
                "message", EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(mono).expectComplete().verify();
  }

  @Test
  public void testUpdateIndividualRelationship_HappyPath() {
    IndividualRequest r1 = new IndividualRequest().profile(new Profile().lastname("ln"));

    PartyKey partyKey =
        new PartyKey()
            .memberIds(List.of("gcc1"))
            .partyRole(PartyKey.PartyRoleEnum.EDITEE)
            .bncId("bnc");
    when(eventMapper.baseIndividualMono(any(), anyString())).thenReturn(Mono.just(r1));
    when(eventMapper.individualSocioDemoMono(any(),anyString())).thenReturn(Mono.just(r1));
    when(eventMapper.individualPtyIdentificationMono(any(),anyString())).thenReturn(Mono.just(r1));
    when(eventMapper.individualContactMono(any(),anyString())).thenReturn(Mono.just(r1));

    when(bneService.updateIndividual(any(), anyString())).thenReturn(Mono.just(new IndividualResponse()));
    when(eventMapper.relatedOrganizationIdsFromIndividualFlux(any(),anyString())).thenReturn(Flux.empty());

    Mono<Void> mono =
        individualHandler.invoke(
            buildRequest(
                BusinessObjectEnum.ROLERLNTP,
                partyKey,
                TechnicalActionEnum.UPDATE,
                PartyActionEnum.EDIT,
                "message", EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(mono).expectComplete().verify();
  }

  @Test
  public void testUpdateSysKey_HappyPath() {
    PartyKey partyKey =
        new PartyKey()
            .memberIds(List.of("gcc1"))
            .partyRole(PartyKey.PartyRoleEnum.EDITEE)
            .bncId("bnc");
    when(bneService.updateIndividual(any(), anyString())).thenReturn(Mono.just(new IndividualResponse()));
    when(eventMapper.relatedOrganizationIdsFromIndividualFlux(any(), anyString())).thenReturn(Flux.empty());

    Mono<Void> mono =
        individualHandler.invoke(
            buildRequest(
                BusinessObjectEnum.SYSTEMKEY,
                partyKey,
                TechnicalActionEnum.UPDATE,
                PartyActionEnum.EDIT,
                "message", EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(mono).expectComplete().verify();
  }

  @Test
  public void testUpdateId_HappyPath() {
    IndividualRequest r1 =
        new IndividualRequest()
            .other(new Other().identificationType1("id1").identificationValue1("v1"));

    PartyKey partyKey =
        new PartyKey()
            .memberIds(List.of("gcc1"))
            .partyRole(PartyKey.PartyRoleEnum.EDITEE)
            .bncId("bnc");
    when(eventMapper.individualPtyIdentificationMono(any(), anyString())).thenReturn(Mono.just(r1));
    when(eventMapper.relatedOrganizationIdsFromIndividualFlux(any(), anyString())).thenReturn(Flux.empty());

    when(bneService.updateIndividual(any(), anyString())).thenReturn(Mono.just(new IndividualResponse()));
    when(eventMapper.relatedOrganizationIdsFromIndividualFlux(any(),anyString())).thenReturn(Flux.empty());

    Mono<Void> mono =
        individualHandler.invoke(
            buildRequest(
                BusinessObjectEnum.PTYEXTID,
                partyKey,
                TechnicalActionEnum.UPDATE,
                PartyActionEnum.EDIT,
                "message", EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(mono).expectComplete().verify();
  }

  @Test
  public void testUpdateContact_HappyPath() {
    IndividualRequest r1 = new IndividualRequest().profile(new Profile().cell("cell"));

    PartyKey partyKey =
        new PartyKey()
            .memberIds(List.of("gcc1"))
            .partyRole(PartyKey.PartyRoleEnum.EDITEE)
            .bncId("bnc");
    when(eventMapper.individualContactMono(any(), anyString())).thenReturn(Mono.just(r1));
    when(eventMapper.relatedOrganizationIdsFromIndividualFlux(any(), anyString())).thenReturn(Flux.empty());
    when(bneService.updateIndividual(any(), anyString())).thenReturn(Mono.just(new IndividualResponse()));
    when(eventMapper.relatedOrganizationIdsFromIndividualFlux(any(),anyString())).thenReturn(Flux.empty());

    Mono<Void> mono =
        individualHandler.invoke(
            buildRequest(
                BusinessObjectEnum.PTYCTCMETH,
                partyKey,
                TechnicalActionEnum.UPDATE,
                PartyActionEnum.EDIT,
                "message", EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(mono).expectComplete().verify();
  }

  @Test
  public void testUpdateSocioDemo_HappyPath() {
    IndividualRequest r1 = new IndividualRequest().profile(new Profile().sex(SexEnum._1));

    PartyKey partyKey =
        new PartyKey()
            .memberIds(List.of("gcc1"))
            .partyRole(PartyKey.PartyRoleEnum.EDITEE)
            .bncId("bnc");
    when(eventMapper.individualSocioDemoMono(any(),anyString())).thenReturn(Mono.just(r1));
    when(bneService.updateIndividual(any(), anyString())).thenReturn(Mono.just(new IndividualResponse()));
    when(eventMapper.relatedOrganizationIdsFromIndividualFlux(any(),anyString())).thenReturn(Flux.empty());

    Mono<Void> mono =
        individualHandler.invoke(
            buildRequest(
                BusinessObjectEnum.SOCIODEMO,
                partyKey,
                TechnicalActionEnum.UPDATE,
                PartyActionEnum.EDIT,
                "message", EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(mono).expectComplete().verify();
  }

  @Test
  public void testUpdateBaseInd_HappyPath() {
    IndividualRequest r1 = new IndividualRequest().profile(new Profile().lastname("ln"));

    PartyKey partyKey =
        new PartyKey()
            .memberIds(List.of("gcc1"))
            .partyRole(PartyKey.PartyRoleEnum.EDITEE)
            .bncId("bnc");
    when(eventMapper.baseIndividualMono(any(),anyString())).thenReturn(Mono.just(r1));
    when(eventMapper.individualSocioDemoMono(any(), anyString())).thenReturn(Mono.just(r1));
    when(eventMapper.individualPtyIdentificationMono(any(), anyString())).thenReturn(Mono.just(r1));
    when(eventMapper.individualContactMono(any(), anyString())).thenReturn(Mono.just(r1));

    when(bneService.updateIndividual(any(), anyString())).thenReturn(Mono.just(new IndividualResponse()));
    when(eventMapper.relatedOrganizationIdsFromIndividualFlux(any(), anyString())).thenReturn(Flux.empty());

    Mono<Void> mono =
        individualHandler.invoke(
            buildRequest(
                BusinessObjectEnum.BASEINDIV,
                partyKey,
                TechnicalActionEnum.UPDATE,
                PartyActionEnum.EDIT,
                "message", EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(mono).expectComplete().verify();
  }

  @Test
  public void testCreateSystemKey_HappyPath() {
    PartyKey partyKey =
        new PartyKey()
            .memberIds(List.of("gcc1", "gcc2"))
            .mergeInformation(List.of("merge1"))
            .partyRole(PartyKey.PartyRoleEnum.UNMERGEE)
            .bncId("bnc");
    when(bneService.createIndividual(any(), anyString()))
        .thenReturn(Mono.just(new IndividualResponse().message("newGcc")));
    when(eventMapper.addNewGccIdToMcpSystemKeys(any(), any(), any(), any()))
        .thenReturn(Mono.just(new StandardResponse().returnStatusCode("0")));
    when(eventMapper.relatedOrganizationIdsFromIndividualFlux(any(), anyString())).thenReturn(Flux.empty());

    Mono<Void> mono =
        individualHandler.invoke(
            buildRequest(
                BusinessObjectEnum.SYSTEMKEY,
                partyKey,
                TechnicalActionEnum.CREATE,
                PartyActionEnum.EDIT,
                "message", EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(mono).expectComplete().verify();
  }

  @Test
  public void testCreateSocioDemo_HappyPath() {
    PartyKey partyKey =
        new PartyKey()
            .memberIds(List.of("gcc1", "gcc2"))
            .mergeInformation(List.of("merge1"))
            .partyRole(PartyKey.PartyRoleEnum.UNMERGEE)
            .bncId("bnc");
    when(eventMapper.individualSocioDemoMono(any(), anyString())).thenReturn(Mono.just(new IndividualRequest()));
    when(bneService.createIndividual(any(), anyString()))
        .thenReturn(Mono.just(new IndividualResponse().message("newGcc")));
    when(eventMapper.addNewGccIdToMcpSystemKeys(any(), any(), any(), any()))
        .thenReturn(Mono.just(new StandardResponse().returnStatusCode("0")));

    when(eventMapper.relatedOrganizationIdsFromIndividualFlux(any(), anyString())).thenReturn(Flux.empty());

    Mono<Void> mono =
        individualHandler.invoke(
            buildRequest(
                BusinessObjectEnum.SOCIODEMO,
                partyKey,
                TechnicalActionEnum.CREATE,
                PartyActionEnum.EDIT,
                "message", EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(mono).expectComplete().verify();
  }

  @Test
  public void testCreateId_HappyPath() {
    PartyKey partyKey =
        new PartyKey()
            .memberIds(List.of("gcc1", "gcc2"))
            .mergeInformation(List.of("merge1"))
            .partyRole(PartyKey.PartyRoleEnum.UNMERGEE)
            .bncId("bnc");
    when(eventMapper.individualPtyIdentificationMono(any(), anyString()))
        .thenReturn(Mono.just(new IndividualRequest()));
    when(bneService.createIndividual(any(), anyString()))
        .thenReturn(Mono.just(new IndividualResponse().message("newGcc")));
    when(eventMapper.addNewGccIdToMcpSystemKeys(any(), any(), any(), any()))
        .thenReturn(Mono.just(new StandardResponse().returnStatusCode("0")));

    when(eventMapper.relatedOrganizationIdsFromIndividualFlux(any(), anyString())).thenReturn(Flux.empty());

    Mono<Void> mono =
        individualHandler.invoke(
            buildRequest(
                BusinessObjectEnum.PTYEXTID,
                partyKey,
                TechnicalActionEnum.CREATE,
                PartyActionEnum.UNMERGE,
                "message", EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(mono).expectComplete().verify();
  }

  @Test
  public void testCreateContact_HappyPath() {
    PartyKey partyKey =
        new PartyKey()
            .memberIds(List.of("gcc1", "gcc2"))
            .mergeInformation(List.of("merge1"))
            .partyRole(PartyKey.PartyRoleEnum.UNMERGEE)
            .bncId("bnc");
    when(eventMapper.individualContactMono(any(), anyString())).thenReturn(Mono.just(new IndividualRequest()));
    when(bneService.createIndividual(any(), anyString()))
        .thenReturn(Mono.just(new IndividualResponse().message("newGcc")));
    when(eventMapper.addNewGccIdToMcpSystemKeys(any(), any(), any(), any()))
        .thenReturn(Mono.just(new StandardResponse().returnStatusCode("0")));
    when(eventMapper.relatedOrganizationIdsFromIndividualFlux(any(), anyString())).thenReturn(Flux.empty());

    Mono<Void> mono =
        individualHandler.invoke(
            buildRequest(
                BusinessObjectEnum.PTYCTCMETH,
                partyKey,
                TechnicalActionEnum.CREATE,
                PartyActionEnum.UNMERGE,
                "message", EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(mono).expectComplete().verify();
  }

  @Test
  public void testCreateBaseInd_HappyPath() {
    PartyKey partyKey =
        new PartyKey()
            .mergeInformation(List.of("merge1"))
            .partyRole(PartyKey.PartyRoleEnum.UNMERGEE)
            .bncId("bnc");
    when(eventMapper.individualContactMono(any(), anyString())).thenReturn(Mono.just(new IndividualRequest()));
    when(eventMapper.individualSocioDemoMono(any(), anyString())).thenReturn(Mono.just(new IndividualRequest()));
    when(eventMapper.individualPtyIdentificationMono(any(), anyString()))
        .thenReturn(Mono.just(new IndividualRequest()));
    when(eventMapper.baseIndividualMono(any(), anyString())).thenReturn(Mono.just(new IndividualRequest()));
    when(eventMapper.relatedOrganizationIdsFromIndividualFlux(any(), anyString()))
        .thenReturn(
            Flux.just(
                new IndividualRequest()
                    .general(new General().orgBncId("orgBnc").orgGccNbr("orgGcc"))));
    when(bneService.createIndividual(any(), anyString()))
        .thenReturn(Mono.just(new IndividualResponse().message("newGcc")));
    when(eventMapper.addNewGccIdToMcpSystemKeys(any(), any(), any(), any()))
        .thenReturn(Mono.just(new StandardResponse().returnStatusCode("0")));

    Mono<Void> mono =
        individualHandler.invoke(
            buildRequest(
                BusinessObjectEnum.BASEINDIV,
                partyKey,
                TechnicalActionEnum.CREATE,
                PartyActionEnum.UNMERGE,
                "message", EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(mono).expectComplete().verify();
  }

  @Test
  public void testCreateRelationship_HappyPath() {
    PartyKey partyKey =
        new PartyKey()
            .mergeInformation(List.of("merge1"))
            .partyRole(PartyKey.PartyRoleEnum.UNMERGEE)
            .bncId("bnc");
    when(eventMapper.relatedOrganizationIdsFromIndividualFlux(any(), anyString()))
        .thenReturn(
            Flux.just(
                new IndividualRequest()
                    .general(new General().orgBncId("orgBnc").orgGccNbr("orgGcc"))));

    when(eventMapper.individualContactMono(any(), anyString())).thenReturn(Mono.just(new IndividualRequest()));
    when(eventMapper.individualSocioDemoMono(any(), anyString())).thenReturn(Mono.just(new IndividualRequest()));
    when(eventMapper.individualPtyIdentificationMono(any(), anyString()))
        .thenReturn(Mono.just(new IndividualRequest()));
    when(eventMapper.baseIndividualMono(any(), anyString())).thenReturn(Mono.just(new IndividualRequest()));

    when(bneService.createIndividual(any(), anyString()))
        .thenReturn(Mono.just(new IndividualResponse().message("newGcc")));
    when(eventMapper.addNewGccIdToMcpSystemKeys(any(), any(), any(), any()))
        .thenReturn(Mono.just(new StandardResponse().returnStatusCode("0")));

    Mono<Void> mono =
        individualHandler.invoke(
            buildRequest(
                BusinessObjectEnum.ROLERLNTP,
                partyKey,
                TechnicalActionEnum.CREATE,
                PartyActionEnum.UNMERGE,
                "message", EventRequest.TargetSystemEnum.GCC));

    StepVerifier.create(mono).expectComplete().verify();
  }
}
