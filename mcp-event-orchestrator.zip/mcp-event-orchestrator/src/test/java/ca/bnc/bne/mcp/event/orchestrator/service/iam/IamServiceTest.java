package ca.bnc.bne.mcp.event.orchestrator.service.iam;

import ca.bnc.bne.mcp.event.orchestrator.dto.iam.IamxResponse;
import ca.bnc.bne.mcp.event.orchestrator.exception.model.IamWriteException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Hooks;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;

/**
 * Integration testing of IamService
 * 
 * Mock the data source of iterables with MockWebServer
 * Consuming the observables returned with StepVerifier
 * 
 */
public class IamServiceTest {
  private IamService iamService;

  private MockWebServer mockIamServer;
  private ObjectMapper objectMapper = new ObjectMapper();

  @BeforeEach
  void setUp() throws IOException {
    mockIamServer = new MockWebServer();
    mockIamServer.start();

    String baseUrl = String.format("http://localhost:%s", mockIamServer.getPort());
    iamService = new IamService(WebClient.builder(), baseUrl);
    ReflectionTestUtils.setField(iamService, "uriCreateProfile", "iamx/api/v1/profiles/enterprises?enroll=true");
    ReflectionTestUtils.setField(iamService, "uriDeleteProfile", "iamx/api/v1/profiles/enterprises/{username}");
    ReflectionTestUtils.setField(iamService, "uriUpdateEmail", "iamx/api/v1/profiles/{username}/mfa/phone");
    ReflectionTestUtils.setField(iamService, "uriUpdatePhone", "iamx/api/v1/profiles/{username}/email");
    ReflectionTestUtils.setField(iamService, "uriUpdateVoice", "iamx/api/v1/profiles/{username}/mfa/voice");

    Hooks.onOperatorDebug();
  }

  @AfterEach
  void tearDown() throws IOException {
    mockIamServer.shutdown();
  }

  @Test
  public void testCreateProfileSuccessfully() throws JsonProcessingException {
    mockIamServer.enqueue(new MockResponse()
                                .setResponseCode(200)
                                .addHeader("Content-Type", "application/json; charset=utf-8")
                                .setBody(objectMapper.writeValueAsString(new IamxResponse()
                                                                              .setCode("ok")
                                                                              .setMessage("ok"))));

    Mono<IamxResponse> response = iamService.createProfile("user", "passwd", "MCP","fakeBncId","fakeToken");

    StepVerifier.create(response)
                  .expectNextMatches(body -> body.getCode().equalsIgnoreCase("OK") && body.getMessage().equalsIgnoreCase("OK"))
                  .verifyComplete();
  }

  @Test
  public void testDeleteProfileSuccessfully() throws JsonProcessingException {
    mockIamServer.enqueue(new MockResponse()
                                .setResponseCode(200)
                                .addHeader("Content-Type", "application/json; charset=utf-8")
                                .setBody(objectMapper.writeValueAsString(new IamxResponse()
                                                                              .setCode("ok")
                                                                              .setMessage("ok"))));

    Mono<IamxResponse> response = iamService.deleteProfile("user");

    StepVerifier.create(response)
                  .expectNextMatches(body -> body.getCode().equalsIgnoreCase("OK") && body.getMessage().equalsIgnoreCase("OK"))
                  .verifyComplete();
  }

  @Test
  public void testCreateProfileFailed() throws JsonProcessingException {
    mockIamServer.enqueue(new MockResponse()
                                .setResponseCode(500)
                                .addHeader("Content-Type", "application/json; charset=utf-8")
                                .setBody(objectMapper.writeValueAsString(new IamxResponse()
                                                                              .setCode("error")
                                                                              .setMessage("error"))));

    Mono<IamxResponse> response = iamService.createProfile("user", "passwd", "MCP", "fakeBncId","fakeToken");

    StepVerifier.create(response)
            .expectErrorMatches(throwable -> throwable instanceof IamWriteException && throwable.getMessage().equals(IamWriteException.FAILED_TO_CREATE_PROFILE_IN_IAM))
            .verify();
  }

  @Test
  public void testDeleteProfileFailed() throws JsonProcessingException {
    mockIamServer.enqueue(new MockResponse()
                                .setResponseCode(500)
                                .addHeader("Content-Type", "application/json; charset=utf-8")
                                .setBody(objectMapper.writeValueAsString(new IamxResponse().setCode("error").setMessage("error"))));

    Mono<IamxResponse> response = iamService.deleteProfile("user");

    StepVerifier.create(response)
                  .expectErrorMatches(throwable -> throwable instanceof IamWriteException && throwable.getMessage().equals(IamWriteException.FAILED_TO_DELETE_PROFILE_IN_IAM))
                  .verify();
  }
}
