package ca.bnc.bne.mcp.event.orchestrator.restassured;

import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventAction;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventInformation;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.PartyKey;
import ca.bnc.bne.mcp.event.orchestrator.util.JsonFileUtil;

import java.io.IOException;
import java.util.Arrays;

import static io.restassured.RestAssured.given;

/**
 * Business scenarios specified in Rest Assured for the /mcp/event/handle path
 */
public class McpEventHandleRestAssuredTests {

    public static final String API_PATH_TO_TEST = "/mcp/event/handle";

    public void testEditIndividual() {
        given().log().all().
                header("messageId", "1").
                contentType("application/json").
                body(new EventRequest().eventInformation(new EventInformation()
                        .partyType(EventInformation.PartyTypeEnum.I)
                        .partyAction(EventInformation.PartyActionEnum.EDIT)
                        .partyKey(new PartyKey()
                                .bncId("1")
                                .memberIds(Arrays.asList("1", "2"))
                                .partyRole(PartyKey.PartyRoleEnum.EDITEE)
                                .mergeInformation(Arrays.asList("mergeInfo")))
                        .eventAction(new EventAction()
                                .technicalAction(EventAction.TechnicalActionEnum.CREATE)
                                .businessObject(EventAction.BusinessObjectEnum.SOCIODEMO)))
                        .targetSystem(EventRequest.TargetSystemEnum.GCC)).
                when().
                request("POST", API_PATH_TO_TEST).
                then().
                log().all().statusCode(200);
    }

    public void testEditIndividualFromFile() throws IOException {
        given().log().all().
                header("messageId", "1").contentType("application/json")
                .body(JsonFileUtil.readObject("controller/event-request-edit-individual.json", EventRequest.class)).
                when().
                request("POST", API_PATH_TO_TEST).
                then().
                log().all().statusCode(200);
    }


}
