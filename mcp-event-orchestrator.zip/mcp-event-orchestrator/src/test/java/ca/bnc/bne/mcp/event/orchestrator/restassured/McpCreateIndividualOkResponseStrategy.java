package ca.bnc.bne.mcp.event.orchestrator.restassured;

import ca.bnc.bne.mcp.event.orchestrator.util.JsonFileUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import okhttp3.mockwebserver.MockResponse;

import java.io.IOException;
import java.net.URISyntaxException;

public class McpCreateIndividualOkResponseStrategy implements IMockReponseStrategy {
    @Override
    public MockResponse supply() throws IOException, URISyntaxException {

        MockResponse response = new MockResponse().setResponseCode(201);
        response.addHeader("Content-Type", "application/json; charset=utf-8")
                .setBody(JsonFileUtil.readString("service/mcp/create-individual-response.json"));


        return response;
    }

    @Override
    public String endpoint() {
        return "/mcp/v2/individual-api/individuals";
    }
}
