package ca.bnc.bne.mcp.event.orchestrator.restassured;

import com.fasterxml.jackson.core.JsonProcessingException;
import okhttp3.mockwebserver.MockResponse;
import org.json.JSONException;

import java.io.IOException;
import java.net.URISyntaxException;

public class MockResponseStrategyContext {

    private IMockReponseStrategy strategy;

    public void setStrategy(IMockReponseStrategy strategy){
        this.strategy = strategy;
    }

    public MockResponse provideMockResponse() throws IOException, URISyntaxException, JSONException {
        return strategy.supply();
    }
}
