package ca.bnc.bne.mcp.event.orchestrator.restassured;

import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.StandardResponse;
import ca.bnc.bne.mcp.event.orchestrator.util.JsonFileUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import okhttp3.mockwebserver.MockResponse;

import java.time.LocalDateTime;

public class McpStandardBadResponseStrategy implements IMockReponseStrategy {
    @Override
    public MockResponse supply() throws JsonProcessingException {

        return new MockResponse().setResponseCode(400)
                .addHeader("Content-Type", "application/json; charset=utf-8")
                .setBody(JsonFileUtil.writeString(new StandardResponse()
                        .returnStatusCode("9000077").returnStatusMessage("The following is not found: Party")
                        .returnDate(LocalDateTime.now().toString())));
    }

    @Override
    public String endpoint() {
        return "/parties/v2/bncId/partySysKey";
    }
}
