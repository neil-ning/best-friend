package ca.bnc.bne.mcp.event.orchestrator.handler.individual;

import ca.bnc.bne.mcp.event.orchestrator.dto.server.UpdateIndividualRequest;
import ca.bnc.bne.mcp.event.orchestrator.exception.model.McpWriteException;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.BaseIndividualREQ;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.BaseIndividualRSP;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.CreateIndividualREQ;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.CreateIndividualRSP;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.CreateIndividualRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.CreateIndividualResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.GetIndividualBaseResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.PartyIdentification;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.PartyMember;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.PartyMemberPlusKey;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.UpdateIndividualBaseRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.UpdateIndividualBaseResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyAddress.UpdatePtyAddressesRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyAddress.UpdatePtyAddressesResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyContact.UpdatePtyContactsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyContact.UpdatePtyContactsResponseType;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyContact.UpdatePtyContactsWithBNCIDRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyRelationship.PostRelationship;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyRelationship.RemovedRelationship;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.socioDemo.GetIndividualSocioDemographicsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.socioDemo.SocioDemographicKeyRessource;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.socioDemo.SocioDemographicKeyRessourceWithBNCID;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.socioDemo.UpdateIndividualSocioDemographicsWithBNCIDRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.AddPartySysKeyRequestBncId;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.RemovePartySysKeyRequestBncId;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.StandardResponse;
import ca.bnc.bne.mcp.event.orchestrator.service.iam.IamService;
import ca.bnc.bne.mcp.event.orchestrator.service.mcp.McpService;
import ca.bnc.bne.mcp.event.orchestrator.service.okta.OktaService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class IndividualServiceHandlerTest {

    private static final Logger logger = LoggerFactory.getLogger(IndividualServiceHandlerTest.class);

    @InjectMocks
    private IndividualServiceHandler serviceHandler;

    @Mock
    private IamService iamService;

    @Mock
    private McpService mcpService;

    @Mock
    private OktaService oktaService;

    @BeforeEach
    void setUp() {
        //MockitoAnnotations.initMocks(this);

        serviceHandler = new IndividualServiceHandler(mcpService, iamService, oktaService);
        //when(oktaService.cacheToken(anyString()))
        //.thenReturn(Mono.just(new OktaResponse().accessToken("accessToken")));
    }

    @Test
    public void whenCall_createIndividual_thenReturnSuccessResponse() {

        CreateIndividualResponse createIndividualResponse = getCreateIndividualResponse();

        when(mcpService.createIndividual(anyString(), any(CreateIndividualRequest.class), anyString()))
                .thenReturn(Mono.just(createIndividualResponse));

        when(mcpService.postSystemKeysByBncId(any(AddPartySysKeyRequestBncId.class), anyString(), anyString()))
                .thenReturn(Mono.just(new StandardResponse().returnStatusCode("0")));

        when(mcpService.linkIndividualToOrganizationExchange(any(PostRelationship.class), anyString()))
                .thenReturn(Mono.just("relationshipId"));

        CreateIndividualRequest req = new CreateIndividualRequest()
                .individual(new CreateIndividualREQ().genderCd("superman")
                        .partyMember(List.of(new PartyMember().memberIdNo("memberId").srcCd("srccd"))));

        StepVerifier.create(serviceHandler
                .createIndividual(req, "orgBndId", "accessToken", "requestId"))
                .expectNextMatches(resp -> resp.getRelationshipId().equals("relationshipId")
                        && resp.getPartyIdentification().getPtyIdentItemNo().equals("bncId"))
                .verifyComplete();

    }

    private CreateIndividualResponse getCreateIndividualResponse() {
        return new CreateIndividualResponse()
                .individual(new CreateIndividualRSP()
                        .addPartyIdentificationItem(new PartyIdentification().ptyIdentItemNo("bncId"))
                        .partyMember(List.of(new PartyMemberPlusKey().memberIdNo("memberId").srcCd("srccd"))));
    }

    @Test
    public void whenCall_createIndividual_thenReturnFailureResponse() {

        CreateIndividualResponse createIndividualResponse = getCreateIndividualResponse();

        when(mcpService.createIndividual(anyString(), any(CreateIndividualRequest.class), anyString()))
                .thenReturn(Mono.just(createIndividualResponse));

        when(mcpService.postSystemKeysByBncId(any(AddPartySysKeyRequestBncId.class), anyString(), anyString()))
                .thenReturn(Mono.just(new StandardResponse().returnStatusCode("0")));

        when(mcpService.linkIndividualToOrganizationExchange(any(PostRelationship.class), anyString()))
                .thenReturn(Mono.just("relationshipId"));

        CreateIndividualRequest req = new CreateIndividualRequest()
                .individual(new CreateIndividualREQ().genderCd("superman")
                        .partyMember(List.of(new PartyMember().memberIdNo("memberId").srcCd("srccd"))));

        StepVerifier.create(serviceHandler
                .createIndividual(req, "orgBndId", "accessToken", "requestId"))
                .expectNextMatches(resp -> !resp.getRelationshipId().equals("relationshipId")
                        || !resp.getPartyIdentification().getPtyIdentItemNo().equals("bncIdwrong"))
                .verifyComplete();

    }

    @Test
    public void whenCall_createIndividual_thenCreateIndividualThrowException() {

        when(mcpService.createIndividual(anyString(), any(CreateIndividualRequest.class), anyString()))
                .thenReturn(Mono.error(new McpWriteException(McpWriteException.FAILED_TO_CREATE_INDIVIDUAL_IN_MCP)));

        CreateIndividualRequest req = new CreateIndividualRequest()
                .individual(new CreateIndividualREQ().genderCd("superman")
                        .partyMember(List.of(new PartyMember().memberIdNo("memberId").srcCd("srccd"))));

        StepVerifier.create(serviceHandler
                .createIndividual(req, "orgBndId", "accessToken", "requestId"))
                .expectError(McpWriteException.class)
                .verify();

    }

    @Test
    public void whenCall_createIndividual_thenAddSystemKeyThrowException() {

        CreateIndividualResponse createIndividualResponse = getCreateIndividualResponse();
        when(mcpService.createIndividual(anyString(), any(CreateIndividualRequest.class), anyString()))
                .thenReturn(Mono.just(createIndividualResponse));

        when(mcpService.postSystemKeysByBncId(any(AddPartySysKeyRequestBncId.class), anyString(), anyString()))
                .thenReturn(Mono.error(new McpWriteException(McpWriteException.FAILED_TO_LINK_INDIVIDUAL_TO_ORGANIZATION_IN_MCP)));

        CreateIndividualRequest req = new CreateIndividualRequest()
                .individual(new CreateIndividualREQ().genderCd("superman")
                        .partyMember(List.of(new PartyMember().memberIdNo("memberId").srcCd("srccd"))));

        StepVerifier.create(serviceHandler
                .createIndividual(req, "orgBndId", "accessToken", "requestId"))
                .expectError(McpWriteException.class)
                .verify();

    }

    @Test
    public void whenCall_createIndividual_thenLinkIndividualThrowException() {

        CreateIndividualResponse createIndividualResponse = getCreateIndividualResponse();

        when(mcpService.createIndividual(anyString(), any(CreateIndividualRequest.class), anyString()))
                .thenReturn(Mono.just(createIndividualResponse));

        when(mcpService.postSystemKeysByBncId(any(AddPartySysKeyRequestBncId.class), anyString(), anyString()))
                .thenReturn(Mono.just(new StandardResponse().returnStatusCode("0")));

        when(mcpService.linkIndividualToOrganizationExchange(any(PostRelationship.class), anyString()))
                .thenReturn(Mono.error(new McpWriteException(McpWriteException.FAILED_TO_LINK_INDIVIDUAL_TO_ORGANIZATION_IN_MCP)));

        CreateIndividualRequest req = new CreateIndividualRequest()
                .individual(new CreateIndividualREQ().genderCd("superman")
                        .partyMember(List.of(new PartyMember().memberIdNo("memberId").srcCd("srccd"))));
        StepVerifier.create(serviceHandler
                .createIndividual(req, "orgBndId", "accessToken", "requestId"))
                .expectError(McpWriteException.class)
                .verify();

    }

    private UpdateIndividualRequest buildUpdateIndividualRequest() {
        UpdateIndividualRequest request = new UpdateIndividualRequest();

        request.setBaseIndividualUpdate(true);
        request.setBaseIndividual(new UpdateIndividualBaseRequest()
                .individual(new BaseIndividualREQ()));

        request.setPtyAddressesUpdate(true);
        request.setPtyAddresses(new UpdatePtyAddressesRequest());

        request.setPtyContactsUpdate(true);
        request.setPtyContacts(new UpdatePtyContactsWithBNCIDRequest());

        request.setIndividualSocioUpdate(true);
        request.setIndividualSocio(new UpdateIndividualSocioDemographicsWithBNCIDRequest()
                .socioDemographic(new SocioDemographicKeyRessourceWithBNCID()));

        return request;
    }

    @Test
    public void whenCall_addNewSysIdToMcpSystemKeys_thenReturnSuccessResponse() {

        StandardResponse resp = new StandardResponse().returnStatusCode("200");

        when(mcpService.postSystemKeysByBncId(any(AddPartySysKeyRequestBncId.class), anyString(), anyString()))
                .thenReturn(Mono.just(resp));

        StepVerifier.create(serviceHandler.addNewSysIdToMcpSystemKeys("bncId", "sysId", "srcCd", "accessToken", "requestId"))
                .expectNextMatches(standardResponse -> standardResponse.getReturnStatusCode().equals("200"))
                .verifyComplete();
    }

    @Test
    public void whenCall_addNewSysIdToMcpSystemKeys_thenReturnFailureResponse() {

        StandardResponse resp = new StandardResponse().returnStatusCode("400");

        when(mcpService.postSystemKeysByBncId(any(AddPartySysKeyRequestBncId.class), anyString(), anyString()))
                .thenReturn(Mono.just(resp));

        StepVerifier.create(serviceHandler.addNewSysIdToMcpSystemKeys("bncId", "sysId", "srcCd", "accessToken", "requestId"))
                .expectNextMatches(standardResponse -> standardResponse.getReturnStatusCode().equals("400"))
                .verifyComplete();
    }

    @Test
    public void whenCall_addNewSysIdToMcpSystemKeys_thenThrowsError() {

        when(mcpService.postSystemKeysByBncId(any(AddPartySysKeyRequestBncId.class), anyString(), anyString()))
                .thenReturn(Mono.error(new McpWriteException("addNewSysIdToMcpSystemKeys occurs error")));

        StepVerifier.create(serviceHandler
                .addNewSysIdToMcpSystemKeys("bncId", "sysId", "srcCd", "accessToken", "requestId"))
                .expectError(McpWriteException.class)
                .verify();
    }

    @Test
    public void testUpdateIndividual_HappyPath() {

        GetIndividualBaseResponse responseType = new GetIndividualBaseResponse().individual(new BaseIndividualRSP()
                .partyIdentification(Arrays.asList(new PartyIdentification().ptyIdentItemNo("bncId").ptyIdentStatusCd("ACTIVE"))));

        //doReturn(Mono.empty()).when(mcpService).updateIndividualBase( Mockito.any(UpdateIndividualBaseRequest.class), anyString());
        doReturn(Mono.empty()).when(mcpService).updateIndividualBaseByBncId(anyString(), Mockito.any(UpdateIndividualBaseRequest.class), anyString());
        doReturn(Mono.empty()).when(mcpService).updateIndividualSocio(anyString(), any(UpdateIndividualSocioDemographicsWithBNCIDRequest.class), anyString());
        doReturn(Mono.empty()).when(mcpService).updateIndividualContact(anyString(), any(UpdatePtyContactsWithBNCIDRequest.class), anyString());
        doReturn(Mono.empty()).when(mcpService).updateIndividualAddress(anyString(), any(UpdatePtyAddressesRequest.class), anyString());

        when(mcpService.getSocioDemoMono(anyString(), anyString())).thenReturn(Mono.just(new GetIndividualSocioDemographicsResponse()
                .socioDemographic(new SocioDemographicKeyRessource())));
        //when(mcpService.getIndividual(anyString(), anyString(), anyString())).thenReturn(Mono.just(responseType));

        StepVerifier.create(serviceHandler.updateIndividual("userBncId", buildUpdateIndividualRequest(), "accessToken", "reqeustId"))
                .expectComplete().verify();
    }

    @Test
    public void whenCall_updateIndividual_base_throwException() {

        when(mcpService.updateIndividualBaseByBncId(anyString(), any(UpdateIndividualBaseRequest.class), anyString()))
                .thenReturn(Mono.error(new RuntimeException("test error")));


        when(mcpService.updateIndividualAddress(anyString(), any(UpdatePtyAddressesRequest.class), anyString()))
                .thenReturn(Mono.just(new UpdatePtyAddressesResponse()));

        when(mcpService.updateIndividualContact(anyString(), any(UpdatePtyContactsWithBNCIDRequest.class), anyString()))
                .thenReturn(Mono.just(new UpdatePtyContactsResponse().contacts(new UpdatePtyContactsResponseType())));

        when(mcpService.getSocioDemoMono(anyString(), anyString()))
                .thenReturn(Mono.just(new GetIndividualSocioDemographicsResponse()
                        .socioDemographic(new SocioDemographicKeyRessource())));


        StepVerifier.create(serviceHandler
                .updateIndividual("userBncId",
                        buildUpdateIndividualRequest(),
                        "accessToken",
                        "reqeustId"))
                .verifyError(McpWriteException.class);
    }

    @Test
    public void whenCall_updateIndividual_address_throwException() {

        when(mcpService.updateIndividualBaseByBncId(anyString(), any(UpdateIndividualBaseRequest.class), anyString()))
                .thenReturn(Mono.just(new UpdateIndividualBaseResponse()));

        when(mcpService.updateIndividualAddress(anyString(), any(UpdatePtyAddressesRequest.class), anyString()))
                .thenReturn(Mono.error(new RuntimeException("test error")));

        when(mcpService.updateIndividualContact(anyString(), any(UpdatePtyContactsWithBNCIDRequest.class), anyString()))
                .thenReturn(Mono.just(new UpdatePtyContactsResponse().contacts(new UpdatePtyContactsResponseType())));

        when(mcpService.getSocioDemoMono(anyString(), anyString()))
                .thenReturn(Mono.just(new GetIndividualSocioDemographicsResponse()
                        .socioDemographic(new SocioDemographicKeyRessource())));

        StepVerifier.create(serviceHandler.updateIndividual("userBncId", buildUpdateIndividualRequest(), "accessToken", "reqeustId"))
                .expectError(McpWriteException.class)
                .verify();
    }

    @Test
    public void whenCall_updateIndividual_contact_throwException() {

        when(mcpService.updateIndividualBaseByBncId(anyString(), any(UpdateIndividualBaseRequest.class), anyString()))
                .thenReturn(Mono.just(new UpdateIndividualBaseResponse()));

        when(mcpService.updateIndividualAddress(anyString(), any(UpdatePtyAddressesRequest.class), anyString()))
                .thenReturn(Mono.just(new UpdatePtyAddressesResponse()));

        when(mcpService.updateIndividualContact(anyString(), any(UpdatePtyContactsWithBNCIDRequest.class), anyString()))
                .thenReturn(Mono.error(new RuntimeException("test error")));

        when(mcpService.getSocioDemoMono(anyString(), anyString()))
                .thenReturn(Mono.just(new GetIndividualSocioDemographicsResponse()
                        .socioDemographic(new SocioDemographicKeyRessource())));

        StepVerifier.create(serviceHandler.updateIndividual("userBncId", buildUpdateIndividualRequest(), "accessToken", "reqeustId"))
                .expectError(McpWriteException.class)
                .verify();
    }

    @Test
    public void whenCall_updateIndividual_socio_throwException() {

        when(mcpService.updateIndividualBaseByBncId(anyString(), any(UpdateIndividualBaseRequest.class), anyString()))
                .thenReturn(Mono.just(new UpdateIndividualBaseResponse().individual(new BaseIndividualRSP())));

        when(mcpService.updateIndividualAddress(anyString(), any(UpdatePtyAddressesRequest.class), anyString()))
                .thenReturn(Mono.just(new UpdatePtyAddressesResponse()));

        when(mcpService.updateIndividualContact(anyString(), any(UpdatePtyContactsWithBNCIDRequest.class), anyString()))
                .thenReturn(Mono.just(new UpdatePtyContactsResponse().contacts(new UpdatePtyContactsResponseType())));

        when(mcpService.getSocioDemoMono(anyString(), anyString()))
                .thenReturn(Mono.just(new GetIndividualSocioDemographicsResponse()
                        .socioDemographic(new SocioDemographicKeyRessource())));

        /*doThrow(new McpWriteException("error test")).when(mcpService)
                .updateIndividualSocio(anyString(),
                        any(UpdateIndividualSocioDemographicsWithBNCIDRequest.class),
                        anyString());*/

        when(mcpService.updateIndividualSocio(anyString(), any(UpdateIndividualSocioDemographicsWithBNCIDRequest.class), anyString()))
                .thenReturn(Mono.error(new McpWriteException("error test")));

        /*when(mcpService.updateIndividualSocio(anyString(), any(UpdateIndividualSocioDemographicsWithBNCIDRequest.class), anyString()))
                .thenThrow(new McpWriteException("error test"));*/

        StepVerifier.create(serviceHandler.updateIndividual("userBncId", buildUpdateIndividualRequest(), "accessToken", "reqeustId"))
                .expectError(McpWriteException.class)
                .verify();
    }

    @Test
    public void whenCall_deleteIndividual_thenReturnSuccessResponse() {

        GetIndividualBaseResponse responseType = new GetIndividualBaseResponse().individual(new BaseIndividualRSP()
                .partyIdentification(Arrays.asList(new PartyIdentification().ptyIdentItemNo("indvBncId").ptyIdentStatusCd("ACTIVE"))));

        /*when(mcpService.getIndividual(anyString(), anyString(), anyString()))
                .thenReturn(Mono.just(responseType));

        when(mcpService.getPtyRelationshipMono(anyString(), anyString(), anyString()))
                .thenReturn(Mono.just(new GetRelationshipsResponse()
                        .addRelationshipsItem(new Relationship().initiatingBncId("orgBncId").oppositeBncId("indvBncId"))));*/

        when(mcpService.deleteSystemKeysByBncId(anyString(), any(RemovePartySysKeyRequestBncId.class), anyString()))
                .thenReturn(Mono.just(new StandardResponse()));

        when(mcpService.unlinkIndividualToOrganization(anyString(), any(RemovedRelationship.class), anyString()))
                .thenReturn(Mono.empty());

        StepVerifier.create(serviceHandler.deleteIndividual("orgBncId", "individualSysId", "srcCd", "relationshipId", "accessToken", "requestId"))
                .verifyComplete();
    }


    @Test
    public void whenCall_deleteIndividual_thenUnlinkThrowException() {

        GetIndividualBaseResponse responseType = new GetIndividualBaseResponse().individual(new BaseIndividualRSP()
                .partyIdentification(Arrays.asList(new PartyIdentification().ptyIdentItemNo("indvBncId").ptyIdentStatusCd("ACTIVE"))));

        /*when(mcpService.getPtyRelationshipMono(anyString(), anyString(), anyString()))
                .thenReturn(Mono.just(new GetRelationshipsResponse()
                        .addRelationshipsItem(new Relationship().initiatingBncId("orgBncId").oppositeBncId("indvBncId"))));

        when(mcpService.getIndividual(anyString(), anyString(), anyString()))
                .thenReturn(Mono.just(responseType));*/

        when(mcpService.deleteSystemKeysByBncId(anyString(), any(RemovePartySysKeyRequestBncId.class), anyString()))
                .thenReturn(Mono.just(new StandardResponse()));

        when(mcpService.unlinkIndividualToOrganization(anyString(), any(RemovedRelationship.class), anyString()))
                .thenThrow(new McpWriteException(McpWriteException
                        .FAILED_TO_UNLINK_INDIVIDUAL_TO_ORGANIZATION_IN_MCP));

        StepVerifier.create(serviceHandler.deleteIndividual("orgBncId", "individualSysId", "srcCd", "relationshipId", "accessToken", "requestId"))
                .expectError(McpWriteException.class)
                .verify();
    }

    @Test
    public void whenCall_deleteIndividual_DeleteSystemKeys_thenThrowsException() {

        when(mcpService.deleteSystemKeysByBncId(anyString(), any(RemovePartySysKeyRequestBncId.class), anyString()))
                .thenReturn(Mono.error(new McpWriteException(McpWriteException
                        .FAILED_TO_UNLINK_INDIVIDUAL_TO_ORGANIZATION_IN_MCP)));

        StepVerifier.create(serviceHandler.deleteIndividual("orgBncId", "individualSysId", "srcCd", "relationshipId", "accessToken", "requestId"))
                .expectError(McpWriteException.class)
                .verify();
    }

}
