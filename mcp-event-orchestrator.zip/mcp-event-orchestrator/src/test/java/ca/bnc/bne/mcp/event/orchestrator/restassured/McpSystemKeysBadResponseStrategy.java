package ca.bnc.bne.mcp.event.orchestrator.restassured;

import com.fasterxml.jackson.core.JsonProcessingException;
import okhttp3.mockwebserver.MockResponse;

public class McpSystemKeysBadResponseStrategy implements IMockReponseStrategy {
    @Override
    public MockResponse supply() throws JsonProcessingException {

        MockResponse response = new MockResponse().setResponseCode(400)
                /*.addHeader("Content-Type", "application/json; charset=utf-8")
                .setBody(JsonFileUtil.writeString(new StandardResponse()
                        .returnStatusCode("0").returnStatusMessage("bad request")))*/;

        return response;
    }

    @Override
    public String endpoint() {
        return "/parties/v2/bncId/partySysKey";
    }
}
