package ca.bnc.bne.mcp.event.orchestrator.mapper;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import ca.bnc.bne.mcp.event.orchestrator.exception.model.InvalidResponseException;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.Other;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.Profile;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.Address;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.BasicInfo;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.Contact;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.OrganizationInput;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.GetIndividualBaseResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.IndividualName;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.organization.GetOrganizationResponseType;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyAddress.GetPtyAddressesResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyContact.GetPtyContactsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyIdentification.GetPtyIdentificationsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyRelationship.GetRelationshipsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.socioDemo.GetIndividualSocioDemographicsResponse;
import ca.bnc.bne.mcp.event.orchestrator.mapper.organization.OrganizationMapperImpl;
import ca.bnc.bne.mcp.event.orchestrator.util.Constants;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import reactor.core.publisher.Mono;

public class McpResponseToBneRequestMapperTest {

  private McpResponseToBneRequestMapper mcpResponseToDtoMapper;
  private ObjectMapper objectMapper;

  @BeforeEach
  void setUp() {
    mcpResponseToDtoMapper = new McpResponseToBneRequestMapper(new OrganizationMapperImpl());
    objectMapper =
        new ObjectMapper()
            .setSerializationInclusion(JsonInclude.Include.NON_EMPTY)
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, true)
            .configure(JsonParser.Feature.ALLOW_COMMENTS, true)
            .configure(MapperFeature.USE_STD_BEAN_NAMING, true)
            .configure(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true)
            .configure(SerializationFeature.WRAP_ROOT_VALUE, false)
            .configure(DeserializationFeature.UNWRAP_ROOT_VALUE, false)
            .configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, false)
            .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
            .findAndRegisterModules();
  }

  @Test
  public void testMapBaseOrganization_happyPath() {
    String response =
        "{\"organization\":{\"ptyUID\":\"878451872497325101\",\"ptyTypeCd\":\"O\",\"ptyCltSinceDt\":\"2000-01-31\",\"ptyDataQualityStatus\":\"UNVERIFIED\",\"ptyUndesirableStatus\":\"UNDES\",\"ptyUndesirableStatusDt\":\"2000-01-31\",\"ptyUpdDt\":\"2020-08-20T13:36:49.493Z\",\"prefContactLangCd\":\"EN\",\"orgConstitutionDt\":\"2000-01-31\",\"orgLglFormCd\":\"CORP\",\"orgLglFormTypeCd\":\"CORPORATE\",\"orgHomeJurisdGeoAreaCd\":\"CA\",\"orgHomeJurisdGeoAreaTypeCd\":\"PAISO\",\"orgOperationStartDt\":\"2000-01-31\",\"orgDtFiscalYearEndDay\":31,\"orgDtFiscalYearEndMth\":12,\"orgTotalAnnualSalesIncomeUID\":\"879651872497326301\",\"orgTotalAnnualSalesIncome\":1000000,\"orgTotalAnnualSalesIncomeUpdDt\":\"2020-08-20T13:36:49.493Z\",\"orgTotalNumberEmpUID\":\"879651872497326301\",\"orgTotalNumberEmp\":100,\"orgTotalNumberEmpUpdDt\":\"2020-08-20T13:36:49.493Z\",\"orgProfileUpdDt\":\"2020-08-20T13:36:49.493Z\",\"orgProfileVerifiedDt\":\"2020-08-20T13:36:49.493Z\",\"orgUpdDt\":\"2020-08-20T13:36:49.493Z\",\"organizationNames\":[{\"orgNmUID\":\"879651872497326301\",\"orgName\":\"The name of my organization\",\"orgNmTypeCd\":\"LGLNAME\",\"orgNmEffctvDt\":\"2020-08-20T13:36:49.493Z\",\"orgNmEndDt\":\"2099-08-20T13:36:49.493Z\",\"orgNmUpdDt\":\"2020-08-20T13:36:49.493Z\"}],\"partyMembers\":[{\"ptyMemberUID\":\"879651874257326301\",\"srcCd\":68,\"memberIdNo\":\"TEST0000000000\",\"ptyMemberUpdDt\":\"2020-08-20T13:36:49.493Z\"}],\"partyIdentifications\":[{\"ptyIdentUID\":\"873251222526081101\",\"ptyIdentItemTypeCd\":\"QST\",\"ptyIdentItemNo\":\"9999999999 TQ 0001\",\"ptyIdentItemIssuingGeoAreaCd\":\"CA-QC\",\"ptyIdentItemIssuingGeoAreaTypeCd\":\"PRISO\",\"ptyIdentStatusCd\":\"ACTIVE\",\"ptyIdentCreationDt\":\"2020-08-20T13:36:49.493Z\",\"ptyIdentEndDt\":\"2020-08-20T13:36:49.493Z\",\"ptyIdentItemExpirDt\":\"2000-01-31\",\"ptyIdentRegUpdDt\":\"2000-01-31\",\"ptyIdentVerifDt\":\"2020-08-20T13:36:49.493Z\",\"ptyIdentUpdDt\":\"2020-08-20T13:36:49.493Z\"}],\"orgForgnOprtns\":[{\"orgForgnOprtnUID\":\"878051872526079401\",\"orgForgnOprtnCntryCd\":\"US\",\"orgForgnOprtnUpdDt\":\"2020-08-20T13:36:49.493Z\"}],\"orgIndstrClasses\":[{\"orgIndstrClassUID\":\"879934562526081101\",\"orgIndstrClassCd\":\"111110\",\"orgIndstrClassTypeCd\":\"NAICS02CAN\",\"orgIndstrClassRankCd\":\"SECONDARY\",\"orgIndstrClassActWeighting\":100,\"orgIndstrClassUpdDt\":\"2020-08-20T13:36:49.493Z\"}],\"orgStckMktXchs\":[{\"orgStckMktXchCd\":\"AATS\"}],\"labels\":[{\"code\":\"GP1859\",\"version\":1,\"effectiveStartDate\":\"2000-12-30\",\"effectiveEndDate\":\"2000-12-30\",\"manualInterventionUserId\":\"gama004\",\"uniqueIdentifier\":\"11223344556677889900\",\"lastUpdateDate\":\"2000-12-01T12:00:00.000Z\"}]},\"exceptions\":[{\"excpDomainCd\":\"PARTY\",\"excpTypeCd\":\"ORGBIZACT\",\"excpCauseCd\":\"PRYACTINV2\",\"excptErrMsg\":\"The Primary Activity weight percentage must be superior or equal to each Secondary Activity weight, And the sum of weights of all business activities have to be greater than 0% and less than or equal to 100%.\",\"excpEffctvDt\":\"2020-08-20T13:36:49.493Z\"}],\"debug\":[{\"request\":\"<element-name attribute1 attribute2> ....content </element-name>\",\"response\":\"<element-name attribute1 attribute2> ....content </element-name>\"}]}";
    GetOrganizationResponseType getOrganizationResponseType =
        mapHelper(GetOrganizationResponseType.class, response);
    OrganizationInput input =
        mcpResponseToDtoMapper.mapBaseOrganization(getOrganizationResponseType);
    assertThat(input)
        .extracting(
            organizationInput -> organizationInput.getBasicInfo().getLangue(),
            organizationInput -> organizationInput.getBasicInfo().getNomCIE())
        .containsExactly(BasicInfo.LangueEnum.EN, "The name of my organization");
  }

  @Test
  public void testMapBaseOrganization_WrongResponse() {
    String response =
        "{\"organization\":{\"ptyUID\":\"878451872497325101\",\"ptyTypeCd\":\"O\",\"ptyCltSinceDt\":\"2000-01-31\",\"ptyDataQualityStatus\":\"UNVERIFIED\",\"ptyUndesirableStatus\":\"UNDES\",\"ptyUndesirableStatusDt\":\"2000-01-31\",\"ptyUpdDt\":\"2020-08-20T13:36:49.493Z\",\"prefContactLangCd\":\"EN\",\"orgConstitutionDt\":\"2000-01-31\",\"orgLglFormCd\":\"CORP\",\"orgLglFormTypeCd\":\"CORPORATE\",\"orgHomeJurisdGeoAreaCd\":\"CA\",\"orgHomeJurisdGeoAreaTypeCd\":\"PAISO\",\"orgOperationStartDt\":\"2000-01-31\",\"orgDtFiscalYearEndDay\":31,\"orgDtFiscalYearEndMth\":12,\"orgTotalAnnualSalesIncomeUID\":\"879651872497326301\",\"orgTotalAnnualSalesIncome\":1000000,\"orgTotalAnnualSalesIncomeUpdDt\":\"2020-08-20T13:36:49.493Z\",\"orgTotalNumberEmpUID\":\"879651872497326301\",\"orgTotalNumberEmp\":100,\"orgTotalNumberEmpUpdDt\":\"2020-08-20T13:36:49.493Z\",\"orgProfileUpdDt\":\"2020-08-20T13:36:49.493Z\",\"orgProfileVerifiedDt\":\"2020-08-20T13:36:49.493Z\",\"orgUpdDt\":\"2020-08-20T13:36:49.493Z\",\"organizationNames\":[{\"orgNmUID\":\"879651872497326301\",\"orgName\":\"The name of my organization\",\"orgNmTypeCd\":\"LGLNAME\",\"orgNmEffctvDt\":\"2020-08-20T13:36:49.493Z\",\"orgNmEndDt\":\"2001-08-20T13:36:49.493Z\",\"orgNmUpdDt\":\"2020-08-20T13:36:49.493Z\"}],\"partyMembers\":[{\"ptyMemberUID\":\"879651874257326301\",\"srcCd\":68,\"memberIdNo\":\"TEST0000000000\",\"ptyMemberUpdDt\":\"2020-08-20T13:36:49.493Z\"}],\"partyIdentifications\":[{\"ptyIdentUID\":\"873251222526081101\",\"ptyIdentItemTypeCd\":\"QST\",\"ptyIdentItemNo\":\"9999999999 TQ 0001\",\"ptyIdentItemIssuingGeoAreaCd\":\"CA-QC\",\"ptyIdentItemIssuingGeoAreaTypeCd\":\"PRISO\",\"ptyIdentStatusCd\":\"ACTIVE\",\"ptyIdentCreationDt\":\"2020-08-20T13:36:49.493Z\",\"ptyIdentEndDt\":\"2020-08-20T13:36:49.493Z\",\"ptyIdentItemExpirDt\":\"2000-01-31\",\"ptyIdentRegUpdDt\":\"2000-01-31\",\"ptyIdentVerifDt\":\"2020-08-20T13:36:49.493Z\",\"ptyIdentUpdDt\":\"2020-08-20T13:36:49.493Z\"}],\"orgForgnOprtns\":[{\"orgForgnOprtnUID\":\"878051872526079401\",\"orgForgnOprtnCntryCd\":\"US\",\"orgForgnOprtnUpdDt\":\"2020-08-20T13:36:49.493Z\"}],\"orgIndstrClasses\":[{\"orgIndstrClassUID\":\"879934562526081101\",\"orgIndstrClassCd\":\"111110\",\"orgIndstrClassTypeCd\":\"NAICS02CAN\",\"orgIndstrClassRankCd\":\"SECONDARY\",\"orgIndstrClassActWeighting\":100,\"orgIndstrClassUpdDt\":\"2020-08-20T13:36:49.493Z\"}],\"orgStckMktXchs\":[{\"orgStckMktXchCd\":\"AATS\"}],\"labels\":[{\"code\":\"GP1859\",\"version\":1,\"effectiveStartDate\":\"2000-12-30\",\"effectiveEndDate\":\"2000-12-30\",\"manualInterventionUserId\":\"gama004\",\"uniqueIdentifier\":\"11223344556677889900\",\"lastUpdateDate\":\"2000-12-01T12:00:00.000Z\"}]},\"exceptions\":[{\"excpDomainCd\":\"PARTY\",\"excpTypeCd\":\"ORGBIZACT\",\"excpCauseCd\":\"PRYACTINV2\",\"excptErrMsg\":\"The Primary Activity weight percentage must be superior or equal to each Secondary Activity weight, And the sum of weights of all business activities have to be greater than 0% and less than or equal to 100%.\",\"excpEffctvDt\":\"2020-08-20T13:36:49.493Z\"}],\"debug\":[{\"request\":\"<element-name attribute1 attribute2> ....content </element-name>\",\"response\":\"<element-name attribute1 attribute2> ....content </element-name>\"}]}";
    GetOrganizationResponseType getOrganizationResponseType =
        mapHelper(GetOrganizationResponseType.class, response);
    assertThatThrownBy(
            () -> mcpResponseToDtoMapper.mapBaseOrganization(getOrganizationResponseType))
        .isInstanceOf(InvalidResponseException.class)
        .hasMessageContaining("No legal organization name");
  }

  @Test
  public void testMapBaseOrganization_emptyBody() {
    String response = "{}";
    GetOrganizationResponseType getOrganizationResponseType =
        mapHelper(GetOrganizationResponseType.class, response);
    assertThatThrownBy(
            () -> mcpResponseToDtoMapper.mapBaseOrganization(getOrganizationResponseType))
        .isInstanceOf(InvalidResponseException.class)
        .hasMessageContaining("No organization returned");
  }

  @Test
  public void testMapBaseOrganization_nullResponse() {
    assertThatThrownBy(() -> mcpResponseToDtoMapper.mapBaseOrganization(null))
        .isInstanceOf(InvalidResponseException.class)
        .hasMessageContaining("No organization returned");
  }

  @Test
  public void testMapAddress_happyPath() {
    String response =
        "{\"partyAddresses\":[{\"ptyUID\":\"103549819321654987\",\"ptyAddrUID\":\"9876543210987654\",\"ptyAddrProprietaryStatusTypeCd\":\"P\",\"ptyAddrUsageTypeCd\":\"HEADOFF\",\"ptyAddrPersonalizedUsgNm\":\"Residence familiale\",\"effctvDt\":\"2013-03-03\",\"endDt\":\"2021-03-03\",\"ptyAddrUpdDt\":\"2013-03-03T15:49:15.815Z\",\"ptyAddrGrpUpdDt\":\"2013-03-03T15:49:15.815Z\",\"Address\":{\"addrPublishStatusCd\":\"STANDARD\",\"addrCivicNo\":\"310\",\"addrDlvInstallationTypeCd\":\"STN\",\"addrDlvModeAddInfo\":\"Leave at the door\",\"addrDlvModeID\":\"987654321A123456\",\"addrDlvModeTypeCd\":\"GD\",\"addrDlvrInstallationNameID\":\"987654321B123456\",\"addrPOBoxNo\":\"12345\",\"addrPOBoxTypeCd\":\"POBOX\",\"addrStrDirectionTypeCd\":\"E\",\"addrStrTypeCd\":\"BLVD\",\"addrUnitDesignatorTypeCd\":\"APT\",\"addrUnitNo\":\"205\",\"bldgName\":\"string\",\"cntryIso2\":\"CA\",\"localityComplete\":\"Saint-Lambert\",\"postalCdUnformatted\":\"J4R1K5\",\"provCntryStd\":\"CA-QC\",\"localityComplete\":\"Montérégie\",\"stName\":\"D'Arran\",\"addrLvlTypeCd\":\"FLOOR\",\"addrLvlNo\":\"2\",\"addrDlvInstallationDesignator\":\"STN\",\"addrDlvModeDesignator\":\"1111\",\"addrPOBoxDesignator\":\"1111\",\"addrPreStrDirectionDesignator\":\"west\",\"addrPostStrDirectionDesignator\":\"ouest\",\"addrPreStrTypeDesignator\":\"rue\",\"addrPostStrTypeDesignator\":\"street\",\"addrUnitDesignator\":\"APT\",\"addrCntrySubDivCdDesignator\":\"territoire\",\"addrLvlDesignator\":\"Floor\",\"addrUID\":\"123456789012345678\",\"addrUpdDt\":\"2013-03-03T15:49:15.815Z\",\"unstrctrPostlAddresses\":[{\"unstrctrPostlAddrLine\":\"310 Rue D'Arran Suite 201;Saint-Lambert, QC J4R 2T5\",\"unstrctrPostlAddrLineSeq\":\"1\"}],\"geographicsCoordinates\":{\"latitude\":\"45.494446\",\"longitude\":\"-73.571695\"}}}]}";
    GetPtyAddressesResponse getPtyAddressesResponse =
        mapHelper(GetPtyAddressesResponse.class, response);
    OrganizationInput input =
        mcpResponseToDtoMapper.mapOrganizationAddress(getPtyAddressesResponse);
    assertThat(input.getAddress())
        .extracting(
            Address::getCePays,
            Address::getCodePostalZip,
            Address::getRue,
            Address::getNoCivique,
            Address::getVille)
        .containsExactly("CA", "J4R1K5", "D'Arran", "310", "Montérégie");
  }

  @Test
  public void testMapAddress_WrongResponse() {
    String response =
        "{\"partyAddresses\":[{\"ptyUID\":\"103549819321654987\",\"ptyAddrUID\":\"9876543210987654\",\"ptyAddrProprietaryStatusTypeCd\":\"P\",\"ptyAddrUsageTypeCd\":\"PRINRES\",\"ptyAddrPersonalizedUsgNm\":\"Residence familiale\",\"effctvDt\":\"2013-03-03\",\"endDt\":\"2021-03-03\",\"ptyAddrUpdDt\":\"2013-03-03T15:49:15.815Z\",\"ptyAddrGrpUpdDt\":\"2013-03-03T15:49:15.815Z\",\"Address\":{\"addrPublishStatusCd\":\"STANDARD\",\"addrCivicNo\":\"310\",\"addrDlvInstallationTypeCd\":\"STN\",\"addrDlvModeAddInfo\":\"Leave at the door\",\"addrDlvModeID\":\"987654321A123456\",\"addrDlvModeTypeCd\":\"GD\",\"addrDlvrInstallationNameID\":\"987654321B123456\",\"addrPOBoxNo\":\"12345\",\"addrPOBoxTypeCd\":\"POBOX\",\"addrStrDirectionTypeCd\":\"E\",\"addrStrTypeCd\":\"BLVD\",\"addrUnitDesignatorTypeCd\":\"APT\",\"addrUnitNo\":\"205\",\"bldgName\":\"string\",\"cntryIso2\":\"CA\",\"localityComplete\":\"Saint-Lambert\",\"postalCdUnformatted\":\"J4R1K5\",\"provCntryStd\":\"CA-QC\",\"region\":\"Montérégie\",\"stName\":\"D'Arran\",\"addrLvlTypeCd\":\"FLOOR\",\"addrLvlNo\":\"2\",\"addrDlvInstallationDesignator\":\"STN\",\"addrDlvModeDesignator\":\"1111\",\"addrPOBoxDesignator\":\"1111\",\"addrPreStrDirectionDesignator\":\"west\",\"addrPostStrDirectionDesignator\":\"ouest\",\"addrPreStrTypeDesignator\":\"rue\",\"addrPostStrTypeDesignator\":\"street\",\"addrUnitDesignator\":\"APT\",\"addrCntrySubDivCdDesignator\":\"territoire\",\"addrLvlDesignator\":\"Floor\",\"addrUID\":\"123456789012345678\",\"addrUpdDt\":\"2013-03-03T15:49:15.815Z\",\"unstrctrPostlAddresses\":[{\"unstrctrPostlAddrLine\":\"310 Rue D'Arran Suite 201;Saint-Lambert, QC J4R 2T5\",\"unstrctrPostlAddrLineSeq\":\"1\"}],\"geographicsCoordinates\":{\"latitude\":\"45.494446\",\"longitude\":\"-73.571695\"}}}]}";
    GetPtyAddressesResponse getPtyAddressesResponse =
        mapHelper(GetPtyAddressesResponse.class, response);
    assertThatThrownBy(() -> mcpResponseToDtoMapper.mapOrganizationAddress(getPtyAddressesResponse))
        .isInstanceOf(InvalidResponseException.class)
        .hasMessageContaining("not found");
  }

  @Test
  public void testMapAddress_Null() {
    assertThatThrownBy(() -> mcpResponseToDtoMapper.mapOrganizationAddress(null))
        .isInstanceOf(InvalidResponseException.class)
        .hasMessageContaining("No address returned");
  }

  @Test
  public void testMapContactInfo_HappyPath() {
    String response =
        "{\"contacts\":{\"ptyUID\":\"563460098040349201\",\"ptyElectronicCtcInfo\":[{\"ptyContactMethdUsgTypeCd\":\"PERS\","
            + "\"ptyContactEffctvDt\":\"2020-09-09T20:39:12.274Z\",\"ptyElectronicCtcInfoTypeCode\":\"EMAIL\",\"ptyElectronicCtcInfoAddrNm\":\"albus.dumbledore@hogwarts.com\",\"keys\":{\"ptyContactMethdUID\":\"565760098040541801\",\"ptyContactMethdUpdDt\":\"2020-09-24T20:46:45.417Z\",\"ptyContactMethdGroupUpdDt\":\"2020-09-24T20:46:45.428Z\",\"ptyElectronicCtcInfoUID\":\"561660098040542601\",\"ptyElectronicCtcInfoUpdDt\":\"2020-09-24T20:46:45.425Z\"}}],\"ptyTelecommunication\":[{\"ptyContactMethdUsgTypeCd\":\"PERS\",\"ptyContactEffctvDt\":\"2020-09-09T20:39:12.274Z\",\"ptyTlcDvcTypeCd\":\"PHONE\",\"ptyTlcCntryPhoneCd\":\"CA\",\"ptyTlcAreaPhoneCd\":\"514\",\"ptyTlcCompletePhoneNo\":\"5142960586\",\"ptyTlcLocalNo\":\"2960586\",\"ptyTlcExtension\":\"5445\",\"keys\":{\"ptyContactMethdUID\":\"562960098040543601\",\"ptyContactMethdUpdDt\":\"2020-09-24T20:46:45.435Z\",\"ptyContactMethdGroupUpdDt\":\"2020-09-24T20:46:45.457Z\",\"ptyTlcUID\":\"566260098040545501\",\"ptyTlcUpdDt\":\"2020-09-24T20:46:45.454Z\",\"ptyTlcPhoneUID\":\"563060098040544201\",\"ptyTlcPhoneUpdDt\":\"2020-09-24T20:46:45.441Z\"}}]}}";
    GetPtyContactsResponse getPtyContactsResponse =
        mapHelper(GetPtyContactsResponse.class, response);

    assertThat(
            mcpResponseToDtoMapper.mapOrganizationContactInfo(getPtyContactsResponse).getContact())
        .extracting(Contact::getPhone)
        .isEqualTo("5142960586");
  }

  @Test
  public void testMapOrgBncToFcc_HappyPath() {
    String response =
        "{\"organization\":{\"ptyUID\":\"878451872497325101\",\"ptyTypeCd\":\"O\",\"ptyCltSinceDt\":\"2000-01-31\",\"ptyDataQualityStatus\":\"UNVERIFIED\",\"ptyUndesirableStatus\":\"UNDES\",\"ptyUndesirableStatusDt\":\"2000-01-31\",\"ptyUpdDt\":\"2020-08-20T13:36:49.493Z\",\"prefContactLangCd\":\"EN\",\"orgConstitutionDt\":\"2000-01-31\",\"orgLglFormCd\":\"CORP\",\"orgLglFormTypeCd\":\"CORPORATE\",\"orgHomeJurisdGeoAreaCd\":\"CA\",\"orgHomeJurisdGeoAreaTypeCd\":\"PAISO\",\"orgOperationStartDt\":\"2000-01-31\",\"orgDtFiscalYearEndDay\":31,\"orgDtFiscalYearEndMth\":12,\"orgTotalAnnualSalesIncomeUID\":\"879651872497326301\",\"orgTotalAnnualSalesIncome\":1000000,\"orgTotalAnnualSalesIncomeUpdDt\":\"2020-08-20T13:36:49.493Z\",\"orgTotalNumberEmpUID\":\"879651872497326301\",\"orgTotalNumberEmp\":100,\"orgTotalNumberEmpUpdDt\":\"2020-08-20T13:36:49.493Z\",\"orgProfileUpdDt\":\"2020-08-20T13:36:49.493Z\",\"orgProfileVerifiedDt\":\"2020-08-20T13:36:49.493Z\",\"orgUpdDt\":\"2020-08-20T13:36:49.493Z\",\"organizationNames\":[{\"orgNmUID\":\"879651872497326301\",\"orgName\":\"The name of my organization\",\"orgNmTypeCd\":\"LGLNAME\",\"orgNmEffctvDt\":\"2020-08-20T13:36:49.493Z\",\"orgNmEndDt\":\"2099-08-20T13:36:49.493Z\",\"orgNmUpdDt\":\"2020-08-20T13:36:49.493Z\"}],\"partyMembers\":[{\"ptyMemberUID\":\"879651874257326301\",\"srcCd\":68,\"memberIdNo\":\"TEST0000000000\",\"ptyMemberUpdDt\":\"2020-08-20T13:36:49.493Z\"}],\"partyIdentifications\":[{\"ptyIdentUID\":\"873251222526081101\",\"ptyIdentItemTypeCd\":\"QST\",\"ptyIdentItemNo\":\"9999999999 TQ 0001\",\"ptyIdentItemIssuingGeoAreaCd\":\"CA-QC\",\"ptyIdentItemIssuingGeoAreaTypeCd\":\"PRISO\",\"ptyIdentStatusCd\":\"ACTIVE\",\"ptyIdentCreationDt\":\"2020-08-20T13:36:49.493Z\",\"ptyIdentEndDt\":\"2020-08-20T13:36:49.493Z\",\"ptyIdentItemExpirDt\":\"2000-01-31\",\"ptyIdentRegUpdDt\":\"2000-01-31\",\"ptyIdentVerifDt\":\"2020-08-20T13:36:49.493Z\",\"ptyIdentUpdDt\":\"2020-08-20T13:36:49.493Z\"}],\"orgForgnOprtns\":[{\"orgForgnOprtnUID\":\"878051872526079401\",\"orgForgnOprtnCntryCd\":\"US\",\"orgForgnOprtnUpdDt\":\"2020-08-20T13:36:49.493Z\"}],\"orgIndstrClasses\":[{\"orgIndstrClassUID\":\"879934562526081101\",\"orgIndstrClassCd\":\"111110\",\"orgIndstrClassTypeCd\":\"NAICS02CAN\",\"orgIndstrClassRankCd\":\"SECONDARY\",\"orgIndstrClassActWeighting\":100,\"orgIndstrClassUpdDt\":\"2020-08-20T13:36:49.493Z\"}],\"orgStckMktXchs\":[{\"orgStckMktXchCd\":\"AATS\"}],\"labels\":[{\"code\":\"GP1859\",\"version\":1,\"effectiveStartDate\":\"2000-12-30\",\"effectiveEndDate\":\"2000-12-30\",\"manualInterventionUserId\":\"gama004\",\"uniqueIdentifier\":\"11223344556677889900\",\"lastUpdateDate\":\"2000-12-01T12:00:00.000Z\"}]},\"exceptions\":[{\"excpDomainCd\":\"PARTY\",\"excpTypeCd\":\"ORGBIZACT\",\"excpCauseCd\":\"PRYACTINV2\",\"excptErrMsg\":\"The Primary Activity weight percentage must be superior or equal to each Secondary Activity weight, And the sum of weights of all business activities have to be greater than 0% and less than or equal to 100%.\",\"excpEffctvDt\":\"2020-08-20T13:36:49.493Z\"}],\"debug\":[{\"request\":\"<element-name attribute1 attribute2> ....content </element-name>\",\"response\":\"<element-name attribute1 attribute2> ....content </element-name>\"}]}";
    GetOrganizationResponseType getOrganizationResponseType =
        mapHelper(GetOrganizationResponseType.class, response);

    List<String> fccIds =
        mcpResponseToDtoMapper.mapOrganizationBncIdToOtherSystemBySrcId(
            getOrganizationResponseType, Constants.FCC_SRC);
    assertThat(fccIds).containsExactly("TEST0000000000");
  }

  @Test
  public void testMapOrgBncToSrc_WrongInput() {
    String response =
        "{\"organization\":{\"ptyUID\":\"878451872497325101\",\"ptyTypeCd\":\"O\",\"ptyCltSinceDt\":\"2000-01-31\",\"ptyDataQualityStatus\":\"UNVERIFIED\",\"ptyUndesirableStatus\":\"UNDES\",\"ptyUndesirableStatusDt\":\"2000-01-31\",\"ptyUpdDt\":\"2020-08-20T13:36:49.493Z\",\"prefContactLangCd\":\"EN\",\"orgConstitutionDt\":\"2000-01-31\",\"orgLglFormCd\":\"CORP\",\"orgLglFormTypeCd\":\"CORPORATE\",\"orgHomeJurisdGeoAreaCd\":\"CA\",\"orgHomeJurisdGeoAreaTypeCd\":\"PAISO\",\"orgOperationStartDt\":\"2000-01-31\",\"orgDtFiscalYearEndDay\":31,\"orgDtFiscalYearEndMth\":12,\"orgTotalAnnualSalesIncomeUID\":\"879651872497326301\",\"orgTotalAnnualSalesIncome\":1000000,\"orgTotalAnnualSalesIncomeUpdDt\":\"2020-08-20T13:36:49.493Z\",\"orgTotalNumberEmpUID\":\"879651872497326301\",\"orgTotalNumberEmp\":100,\"orgTotalNumberEmpUpdDt\":\"2020-08-20T13:36:49.493Z\",\"orgProfileUpdDt\":\"2020-08-20T13:36:49.493Z\",\"orgProfileVerifiedDt\":\"2020-08-20T13:36:49.493Z\",\"orgUpdDt\":\"2020-08-20T13:36:49.493Z\",\"organizationNames\":[{\"orgNmUID\":\"879651872497326301\",\"orgName\":\"The name of my organization\",\"orgNmTypeCd\":\"LGLNAME\",\"orgNmEffctvDt\":\"2020-08-20T13:36:49.493Z\",\"orgNmEndDt\":\"2099-08-20T13:36:49.493Z\",\"orgNmUpdDt\":\"2020-08-20T13:36:49.493Z\"}],\"partyMembers\":[{\"ptyMemberUID\":\"879651874257326301\",\"srcCd\":68,\"memberIdNo\":\"TEST0000000000\",\"ptyMemberUpdDt\":\"2020-08-20T13:36:49.493Z\"}],\"partyIdentifications\":[{\"ptyIdentUID\":\"873251222526081101\",\"ptyIdentItemTypeCd\":\"QST\",\"ptyIdentItemNo\":\"9999999999 TQ 0001\",\"ptyIdentItemIssuingGeoAreaCd\":\"CA-QC\",\"ptyIdentItemIssuingGeoAreaTypeCd\":\"PRISO\",\"ptyIdentStatusCd\":\"ACTIVE\",\"ptyIdentCreationDt\":\"2020-08-20T13:36:49.493Z\",\"ptyIdentEndDt\":\"2020-08-20T13:36:49.493Z\",\"ptyIdentItemExpirDt\":\"2000-01-31\",\"ptyIdentRegUpdDt\":\"2000-01-31\",\"ptyIdentVerifDt\":\"2020-08-20T13:36:49.493Z\",\"ptyIdentUpdDt\":\"2020-08-20T13:36:49.493Z\"}],\"orgForgnOprtns\":[{\"orgForgnOprtnUID\":\"878051872526079401\",\"orgForgnOprtnCntryCd\":\"US\",\"orgForgnOprtnUpdDt\":\"2020-08-20T13:36:49.493Z\"}],\"orgIndstrClasses\":[{\"orgIndstrClassUID\":\"879934562526081101\",\"orgIndstrClassCd\":\"111110\",\"orgIndstrClassTypeCd\":\"NAICS02CAN\",\"orgIndstrClassRankCd\":\"SECONDARY\",\"orgIndstrClassActWeighting\":100,\"orgIndstrClassUpdDt\":\"2020-08-20T13:36:49.493Z\"}],\"orgStckMktXchs\":[{\"orgStckMktXchCd\":\"AATS\"}],\"labels\":[{\"code\":\"GP1859\",\"version\":1,\"effectiveStartDate\":\"2000-12-30\",\"effectiveEndDate\":\"2000-12-30\",\"manualInterventionUserId\":\"gama004\",\"uniqueIdentifier\":\"11223344556677889900\",\"lastUpdateDate\":\"2000-12-01T12:00:00.000Z\"}]},\"exceptions\":[{\"excpDomainCd\":\"PARTY\",\"excpTypeCd\":\"ORGBIZACT\",\"excpCauseCd\":\"PRYACTINV2\",\"excptErrMsg\":\"The Primary Activity weight percentage must be superior or equal to each Secondary Activity weight, And the sum of weights of all business activities have to be greater than 0% and less than or equal to 100%.\",\"excpEffctvDt\":\"2020-08-20T13:36:49.493Z\"}],\"debug\":[{\"request\":\"<element-name attribute1 attribute2> ....content </element-name>\",\"response\":\"<element-name attribute1 attribute2> ....content </element-name>\"}]}";
    GetOrganizationResponseType getOrganizationResponseType =
        mapHelper(GetOrganizationResponseType.class, response);

    List<String> fccIds =
        mcpResponseToDtoMapper.mapOrganizationBncIdToOtherSystemBySrcId(
            getOrganizationResponseType, Constants.GCC_SRC);
    assertThat(fccIds).isNotNull().isEmpty();
  }

  @Test
  public void testMapBaseIndividual_HappyPath() {
    String response =
        "{\"individual\":{\"indvBirthDt\":\"2000-01-01\",\"indvDeathDt\":\"2017-01-01\",\"indvMotherMaidenNm\":\"Lana\",\"prefContactLangCd\":\"FR\",\"indvUpdDt\":\"2020-08-20T16:12:56.349Z\",\"ptyDataQualityStatus\":\"VERIFIED\",\"ptyUID\":\"301349819333378501\",\"ptyTypeCd\":\"I\",\"ptyUpdDt\":\"2020-08-20T16:12:56.349Z\",\"individualName\":[{\"individualNmEffctvDt\":\"2020-08-20T16:12:56.349Z\",\"individualNmEndDt\":\"2099-08-20T16:12:56.349Z\",\"individualNmTitleCd\":\"M\",\"givenName\":\"Irena\",\"middleName\":\"Douda\",\"surname\":\"Bartucca\",\"individualNmUID\":\"307222913920524111\",\"individualNmUpdDt\":\"2020-08-20T16:12:56.349Z\"}],\"partyMember\":[{\"memberIdNo\":\"YWFWD549571373\",\"srcCd\":68,\"ptyMemberUID\":\"307555559260382433\",\"ptyMemberUpdDt\":\"2020-08-20T16:12:56.349Z\"}],\"exception\":[{\"excpActionCd\":\"\",\"excpCauseCd\":\"EMPLOYMAND\",\"excpComponentId\":\"304951913924440101\",\"excpDomainCd\":\"PARTY\",\"excpEffctvDt\":\"2020-08-20T16:12:56.349Z\",\"excptErrMsg\":\"The Primary Activity weight percentage must be superior or equal to each Secondary Activity weight, And the sum of weights of all business activities have to be greater than 0% and less than or equal to 100%.\",\"excpTypeCd\":\"PERSOCCTYP\"}],\"partyIdentification\":[{\"ptyIdentItemNo\":\"09OR32DE118643E0A09065DAAB6BDD2AD2C94995D593DE0BBD2A5F67C21k26jy\",\"ptyIdentItemTypeCd\":\"BNCID\",\"ptyIdentStatusCd\":\"ACTIVE\"}]}}";

    GetIndividualBaseResponse getIndividualBaseResponse =
        mapHelper(GetIndividualBaseResponse.class, response);
    assertThat(mcpResponseToDtoMapper.mapBaseIndividual(getIndividualBaseResponse).getProfile())
        .extracting(
            Profile::getBirthday, Profile::getFirstname, Profile::getLastname, Profile::getLanguage)
        .containsExactly("20000101", "Irena", "Bartucca", Profile.LanguageEnum.FR);
  }

  @Test
  public void testMapBaseIndividual_WrongInput() {
    String response =
        "{\"individual\":{\"indvBirthDt\":\"2000-01-01\",\"indvDeathDt\":\"2017-01-01\",\"indvMotherMaidenNm\":\"Lana\",\"prefContactLangCd\":\"FR\",\"indvUpdDt\":\"2020-08-20T16:12:56.349Z\",\"ptyDataQualityStatus\":\"VERIFIED\",\"ptyUID\":\"301349819333378501\",\"ptyTypeCd\":\"I\",\"ptyUpdDt\":\"2020-08-20T16:12:56.349Z\",\"individualName\":[{\"individualNmEffctvDt\":\"2020-08-20T16:12:56.349Z\",\"individualNmEndDt\":\"2001-08-20T16:12:56.349Z\",\"individualNmTitleCd\":\"M\",\"givenName\":\"Irena\",\"middleName\":\"Douda\",\"surname\":\"Bartucca\",\"individualNmUID\":\"307222913920524111\",\"individualNmUpdDt\":\"2020-08-20T16:12:56.349Z\"}],\"partyMember\":[{\"memberIdNo\":\"YWFWD549571373\",\"srcCd\":68,\"ptyMemberUID\":\"307555559260382433\",\"ptyMemberUpdDt\":\"2020-08-20T16:12:56.349Z\"}],\"exception\":[{\"excpActionCd\":\"\",\"excpCauseCd\":\"EMPLOYMAND\",\"excpComponentId\":\"304951913924440101\",\"excpDomainCd\":\"PARTY\",\"excpEffctvDt\":\"2020-08-20T16:12:56.349Z\",\"excptErrMsg\":\"The Primary Activity weight percentage must be superior or equal to each Secondary Activity weight, And the sum of weights of all business activities have to be greater than 0% and less than or equal to 100%.\",\"excpTypeCd\":\"PERSOCCTYP\"}],\"partyIdentification\":[{\"ptyIdentItemNo\":\"09OR32DE118643E0A09065DAAB6BDD2AD2C94995D593DE0BBD2A5F67C21k26jy\",\"ptyIdentItemTypeCd\":\"BNCID\",\"ptyIdentStatusCd\":\"ACTIVE\"}]}}";

    GetIndividualBaseResponse getIndividualBaseResponse =
        mapHelper(GetIndividualBaseResponse.class, response);
    assertThatThrownBy(() -> mcpResponseToDtoMapper.mapBaseIndividual(getIndividualBaseResponse))
        .isInstanceOf(InvalidResponseException.class);
  }

  @Test
  public void testMapBaseIndividual_Null() {
    assertThatThrownBy(() -> mcpResponseToDtoMapper.mapBaseIndividual(null))
        .isInstanceOf(InvalidResponseException.class);
  }

  @Test
  public void testMapIndividualSocioDemo_HappyPath() {
    String response =
        "{\"socioDemographic\":{\"indvMaritalStatusTypeCd\":\"C\",\"genderCd\":\"2\",\"nbOfDependents\":\"1\",\"indvUpdDt\":\"2020-08-20T16:33:26.859Z\",\"ptyUID\":\"554449819264287788\",\"ptyUpdDt\":\"2020-08-20T16:33:26.859Z\"}}";
    GetIndividualSocioDemographicsResponse socioDemographicsResponse =
        mapHelper(GetIndividualSocioDemographicsResponse.class, response);
    assertThat(
            mcpResponseToDtoMapper
                .mapIndividualSocioDemographic(socioDemographicsResponse)
                .getProfile())
        .extracting(Profile::getSex)
        .isEqualTo(Profile.SexEnum._2);
  }

  @Test
  public void testMapSocioDemo_Null() {
    assertThatThrownBy(() -> mcpResponseToDtoMapper.mapIndividualSocioDemographic(null))
        .isInstanceOf(InvalidResponseException.class);
  }

  @Test
  public void testMapPtyId_HappyPath_OneID() {
    String response =
        "{\"partyIdentifications\":[{\"ptyUID\":\"123459819261074321\",\"ptyIdentItemTypeCd\":\"CAS\",\"ptyIdentCreationDt\":\"2013-03-03\",\"ptyIdentItemIssuingGeoAreaTypeCd\":\"PRISO\",\"ptyIdentEndDt\":\"2099-03-03\",\"ptyIdentItemExpirDt\":\"2099-03-03\",\"ptyIdentItemIssuingGeoAreaCd\":\"CA-QC\",\"ptyIdentItemNo\":\"ident1223456789-001\",\"ptyIdentStatusCd\":\"ACTIVE\",\"ptyIdentRegUpdDt\":\"2020-08-20T17:08:32.250Z\",\"ptyIdentUID\":\"123456789012345678\",\"ptyIdentUpdDt\":\"2075-08-20T17:08:32.250Z\",\"ptyIdentVerifDt\":\"2020-08-20T17:08:32.250Z\",\"ptyIdentIssuerType\":\"BELL\",\"ptyIdentIssuerName\":\"the name of the issuer\"}]}";
    GetPtyIdentificationsResponse getPtyIdentificationsResponse =
        mapHelper(GetPtyIdentificationsResponse.class, response);
    assertThat(
            mcpResponseToDtoMapper
                .mapIndividualPtyIdentification(getPtyIdentificationsResponse)
                .getOther())
        .extracting(
            Other::getIdentificationType1,
            Other::getIdentificationValue1,
            Other::getIdentificationType2,
            Other::getIdentificationValue2)
        .containsExactly("CAS", "ident1223456789-001", null, null);
  }

  @Test
  public void testMapPtyId_HappyPath_MultipleID() {
    String response =
        "{\"partyIdentifications\":[{\"ptyUID\":\"123459819261074321\",\"ptyIdentItemTypeCd\":\"CAS\",\"ptyIdentCreationDt\":\"2013-03-03\",\"ptyIdentItemIssuingGeoAreaTypeCd\":\"PRISO\",\"ptyIdentEndDt\":\"2099-03-03\",\"ptyIdentItemExpirDt\":\"2099-03-03\",\"ptyIdentItemIssuingGeoAreaCd\":\"CA-QC\",\"ptyIdentItemNo\":\"ident1223456789-001\",\"ptyIdentStatusCd\":\"ACTIVE\",\"ptyIdentRegUpdDt\":\"2020-08-20T17:08:32.250Z\",\"ptyIdentUID\":\"123456789012345678\",\"ptyIdentUpdDt\":\"2075-08-20T17:08:32.250Z\",\"ptyIdentVerifDt\":\"2020-08-20T17:08:32.250Z\",\"ptyIdentIssuerType\":\"BELL\",\"ptyIdentIssuerName\":\"the name of the issuer\"},{\"ptyUID\":\"123459819261074321\",\"ptyIdentItemTypeCd\":\"CAS\",\"ptyIdentCreationDt\":\"2013-03-03\",\"ptyIdentItemIssuingGeoAreaTypeCd\":\"PRISO\",\"ptyIdentEndDt\":\"2099-03-03\",\"ptyIdentItemExpirDt\":\"2099-03-03\",\"ptyIdentItemIssuingGeoAreaCd\":\"CA-QC\",\"ptyIdentItemNo\":\"rogers1223456789-001\",\"ptyIdentStatusCd\":\"ACTIVE\",\"ptyIdentRegUpdDt\":\"2020-08-20T17:08:32.250Z\",\"ptyIdentUID\":\"123456789012345678\",\"ptyIdentUpdDt\":\"2076-08-20T17:08:32.250Z\",\"ptyIdentVerifDt\":\"2020-08-20T17:08:32.250Z\",\"ptyIdentIssuerType\":\"BELL\",\"ptyIdentIssuerName\":\"the name of the issuer\"},{\"ptyUID\":\"123459819261074321\",\"ptyIdentItemTypeCd\":\"CAS\",\"ptyIdentCreationDt\":\"2013-03-03\",\"ptyIdentItemIssuingGeoAreaTypeCd\":\"PRISO\",\"ptyIdentEndDt\":\"2099-03-03\",\"ptyIdentItemExpirDt\":\"2099-03-03\",\"ptyIdentItemIssuingGeoAreaCd\":\"CA-QC\",\"ptyIdentItemNo\":\"telus1223456789-001\",\"ptyIdentStatusCd\":\"ACTIVE\",\"ptyIdentRegUpdDt\":\"2020-08-20T17:08:32.250Z\",\"ptyIdentUID\":\"123456789012345678\",\"ptyIdentUpdDt\":\"2078-08-20T17:08:32.250Z\",\"ptyIdentVerifDt\":\"2020-08-20T17:08:32.250Z\",\"ptyIdentIssuerType\":\"BELL\",\"ptyIdentIssuerName\":\"the name of the issuer\"}]}";
    GetPtyIdentificationsResponse getPtyIdentificationsResponse =
        mapHelper(GetPtyIdentificationsResponse.class, response);
    assertThat(
            mcpResponseToDtoMapper
                .mapIndividualPtyIdentification(getPtyIdentificationsResponse)
                .getOther())
        .extracting(
            Other::getIdentificationType1,
            Other::getIdentificationValue1,
            Other::getIdentificationType2,
            Other::getIdentificationValue2)
        .containsExactly("CAS", "telus1223456789-001", "CAS", "rogers1223456789-001");
  }

  @Test
  public void testMapPtyId_Null() {
    assertThatThrownBy(() -> mcpResponseToDtoMapper.mapIndividualPtyIdentification(null))
        .isInstanceOf(InvalidResponseException.class);
  }

  @Test
  public void testMapPtyId_NoId() {
    assertThatThrownBy(
            () ->
                mcpResponseToDtoMapper.mapIndividualPtyIdentification(
                    new GetPtyIdentificationsResponse()))
        .isInstanceOf(InvalidResponseException.class);
  }

  @Test
  public void testMapContactIndividual_HappyPath() {
    String response =
        "{\"contacts\":{\"ptyUID\":\"563460098040349201\",\"ptyElectronicCtcInfo\":[{\"ptyContactMethdUsgTypeCd\":\"PERS\","
            + "\"ptyContactEffctvDt\":\"2020-09-09T20:39:12.274Z\",\"ptyElectronicCtcInfoTypeCode\":\"EMAIL\",\"ptyElectronicCtcInfoAddrNm\":\"albus.dumbledore@hogwarts.com\",\"keys\":{\"ptyContactMethdUID\":\"565760098040541801\",\"ptyContactMethdUpdDt\":\"2020-09-24T20:46:45.417Z\",\"ptyContactMethdGroupUpdDt\":\"2020-09-24T20:46:45.428Z\",\"ptyElectronicCtcInfoUID\":\"561660098040542601\",\"ptyElectronicCtcInfoUpdDt\":\"2020-09-24T20:46:45.425Z\"}}],\"ptyTelecommunication\":[{\"ptyContactMethdUsgTypeCd\":\"PERS\",\"ptyContactEffctvDt\":\"2020-09-09T20:39:12.274Z\",\"ptyTlcDvcTypeCd\":\"PHONE\",\"ptyTlcCntryPhoneCd\":\"CA\",\"ptyTlcAreaPhoneCd\":\"514\",\"ptyTlcCompletePhoneNo\":\"5142960586\",\"ptyTlcLocalNo\":\"2960586\",\"ptyTlcExtension\":\"5445\",\"keys\":{\"ptyContactMethdUID\":\"562960098040543601\",\"ptyContactMethdUpdDt\":\"2020-09-24T20:46:45.435Z\",\"ptyContactMethdGroupUpdDt\":\"2020-09-24T20:46:45.457Z\",\"ptyTlcUID\":\"566260098040545501\",\"ptyTlcUpdDt\":\"2020-09-24T20:46:45.454Z\",\"ptyTlcPhoneUID\":\"563060098040544201\",\"ptyTlcPhoneUpdDt\":\"2020-09-24T20:46:45.441Z\"}}]}}";
    GetPtyContactsResponse getPtyContactsResponse =
        mapHelper(GetPtyContactsResponse.class, response);
    assertThat(mcpResponseToDtoMapper.mapIndividualContactInfo(getPtyContactsResponse).getProfile())
        .extracting(Profile::getCell, Profile::getPhone, Profile::getEmail)
        .containsExactly(null, "5142960586", "albus.dumbledore@hogwarts.com");
  }

  @Test
  public void testMapRelatedOrganizationToIndividualList_HappyPath() {
    String response =
        "{\"count\":\"5\",\"totalCount\":\"15\",\"relationships\":[{\"partyRelationType\":\"ADMIN\",\"initiatingPartyRole\":\"AUTHRZDREP\",\"oppositePartyRole\":\"MEMBER\",\"initiatingPartyType\":\"I\",\"oppositePartyType\":\"O\",\"initiatingBncId\":\"5fa23f64-9911-4545-b3fc-2c963f12cab7\",\"oppositeBncId\":\"orgBnc1\",\"lastUpdateDate\":\"2018-03-03T15:49:15.815Z\"},{\"partyRelationType\":\"ADMIN\",\"initiatingPartyRole\":\"AUTHRZDREP\",\"oppositePartyRole\":\"MEMBER\",\"initiatingPartyType\":\"I\",\"oppositePartyType\":\"O\",\"initiatingBncId\":\"5fa23f64-9911-4545-b3fc-2c963f12cab7\",\"oppositeBncId\":\"orgBnc2\",\"lastUpdateDate\":\"2018-03-03T15:49:15.815Z\"}]}";
    GetRelationshipsResponse getRelationshipsResponse =
        mapHelper(GetRelationshipsResponse.class, response);

    List<String> strings =
        mcpResponseToDtoMapper.mapRelatedOrganizationBncIdList(getRelationshipsResponse);
    assertThat(strings).isNotNull().isNotEmpty().containsExactly("orgBnc1", "orgBnc2");
  }

  @Test
  public void testMapRelationship_Null() {
    assertThatThrownBy(() -> mcpResponseToDtoMapper.mapRelatedOrganizationBncIdList(null))
        .isInstanceOf(InvalidResponseException.class);
  }

  @Test
  public void test() {
    Mono<IndividualName> empty = Mono.empty();
    //   Flux.just("1", "2").doOnComplete(() -> System.out.print("done")).log().subscribe();

    empty
        .map(individualName -> individualName.getGivenName())
        .switchIfEmpty(Mono.defer(() -> Mono.error(new IllegalStateException("error"))))
        .log()
        .doAfterTerminate(() -> System.out.println("doAfterTerminate"))
        .doFirst(() -> System.out.println("doFirst"))
        .doOnCancel(() -> System.out.println("doOnCancel"))
        .doOnSubscribe(subscription -> System.out.println("doOnSubscribe"))
        .doOnRequest(value -> System.out.println("doOnRequest"))
        .doOnNext(value -> System.out.println("doOnNext"))
        .doOnNext(value -> System.out.println("doFirst"))
        .doOnEach(stringSignal -> System.out.println("doOnEach"))
        .doOnSuccess(stringSignal -> System.out.println("doOnSuccess"))
        .doOnTerminate(() -> System.out.println("doOnTerminate"))
        .subscribe(s -> System.out.println("done" + s));
  }

  private <T> T mapHelper(Class<T> clazz, String json) {
    try {
      return objectMapper.readValue(json, clazz);
    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
  }
}
