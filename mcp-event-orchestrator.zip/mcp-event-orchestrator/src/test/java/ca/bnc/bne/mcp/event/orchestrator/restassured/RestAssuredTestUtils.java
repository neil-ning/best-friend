package ca.bnc.bne.mcp.event.orchestrator.restassured;


import org.reflections.Reflections;

import java.util.Set;

public final class RestAssuredTestUtils {

    public static Set<Class<? extends IMockReponseStrategy>> getAllMockResponseStrategies(){

        Reflections reflections = new Reflections(RestAssuredTestUtils.class.getPackageName());

        Set<Class<? extends IMockReponseStrategy>> strategies = reflections.getSubTypesOf(IMockReponseStrategy.class);

        return strategies;
    }
}
