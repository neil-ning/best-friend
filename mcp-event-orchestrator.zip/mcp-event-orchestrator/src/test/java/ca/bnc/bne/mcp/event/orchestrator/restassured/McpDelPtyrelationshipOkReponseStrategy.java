package ca.bnc.bne.mcp.event.orchestrator.restassured;

import okhttp3.mockwebserver.MockResponse;
import org.json.JSONException;

import java.io.IOException;
import java.net.URISyntaxException;

public class McpDelPtyrelationshipOkReponseStrategy implements IMockReponseStrategy {
    @Override
    public MockResponse supply() throws IOException, URISyntaxException, JSONException {
        return new MockResponse().setResponseCode(200);
    }

    @Override
    public String endpoint() {
        return "/mcp/v1/partyrelationship-api/party-relationships/relationshipId";
    }
}
