package ca.bnc.bne.mcp.event.orchestrator.restassured;

import okhttp3.mockwebserver.Dispatcher;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.RecordedRequest;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URISyntaxException;


class MockDispatcher extends Dispatcher {

    Logger logger = LoggerFactory.getLogger(MockDispatcher.class);

    MockResponseStrategyContext context;

    MockResponseStrategyFactory factory;

    MockDispatcher(MockResponseStrategyFactory factory,
                   MockResponseStrategyContext context) {
        this.factory = factory;
        this.context = context;
    }

    @Override
    public MockResponse dispatch(RecordedRequest request) throws InterruptedException{

        String endpoint = request.getPath();

        logger.info("MockDispatcher entrance endpoint is [{}]", endpoint);

        int idx = endpoint.indexOf("?");

        endpoint = idx == -1 ? endpoint : StringUtils.substringBefore(endpoint, "?");

        logger.info("MockDispatcher exact entrance endpoint is [{}]", endpoint);

        try {
            context.setStrategy(factory.getStrategy(endpoint));
            return context.provideMockResponse();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }

        return new MockResponse().setResponseCode(500);
    }
}
