package ca.bnc.bne.mcp.event.orchestrator.mapper;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import ca.bnc.bne.mcp.event.orchestrator.dto.okta.OktaResponse;
import ca.bnc.bne.mcp.event.orchestrator.exception.model.InvalidResponseException;
import ca.bnc.bne.mcp.event.orchestrator.exception.model.McpBusinessRuleException;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.General;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.IndividualRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventRequest.TargetSystemEnum;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.OrganizationInput;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.GetIndividualBaseResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.organization.GetOrganizationResponseType;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyAddress.GetPtyAddressesResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyContact.GetPtyContactsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyIdentification.GetPtyIdentificationsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyRelationship.GetRelationshipsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.socioDemo.GetIndividualSocioDemographicsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.StandardResponse;
import ca.bnc.bne.mcp.event.orchestrator.handler.EventTargetSystem;
import ca.bnc.bne.mcp.event.orchestrator.service.mcp.McpService;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

public class EventMapperTest {

  @Mock
  private McpService mcpService;
  @Mock
  private McpResponseToBneRequestMapper mcpResponseToBneRequestMapper;
  @InjectMocks
  private EventMapper eventMapper;

  @BeforeEach
  void init() {
    initMocks(this);
    eventMapper.setOktaResponseMonoGcc(
        Mono.just(new OktaResponse().scope("scope").accessToken("token").expiresIn(3600)));
  }

  @Test
  public void testMapBaseIndividual_HappyPath() {

    when(mcpService.getBaseIndividualMono(any(), any()))
        .thenReturn(Mono.just(new GetIndividualBaseResponse()));
    when(mcpResponseToBneRequestMapper.mapBaseIndividual(any()))
        .thenReturn(new IndividualRequest());

    StepVerifier.create(eventMapper.baseIndividualMono("bnc", "GCC"))
                .expectNext(new IndividualRequest())
                .verifyComplete();
  }

  @Test
  public void testMapBaseIndividual_ServiceError() {

    when(mcpService.getBaseIndividualMono(any(), any()))
        .thenReturn(Mono.error(() -> new McpBusinessRuleException("e")));
    when(mcpResponseToBneRequestMapper.mapBaseIndividual(any()))
        .thenReturn(new IndividualRequest());

    StepVerifier.create(eventMapper.baseIndividualMono("bnc", "GCC"))
                .expectError(McpBusinessRuleException.class)
                .verify();
  }

  @Test
  public void testMapIndividualContact_HappyPath() {

    when(mcpService.getPtyContactsMono(any(), any()))
        .thenReturn(Mono.just(new GetPtyContactsResponse()));
    when(mcpResponseToBneRequestMapper.mapIndividualContactInfo(any()))
        .thenReturn(new IndividualRequest());

    StepVerifier.create(eventMapper.individualContactMono("bnc", "GCC"))
                .expectNext(new IndividualRequest())
                .verifyComplete();
  }

  @Test
  public void testMapIndividualContact_ServiceError() {

    when(mcpService.getPtyContactsMono(any(), any()))
        .thenReturn(Mono.error(() -> new McpBusinessRuleException("e")));
    when(mcpResponseToBneRequestMapper.mapIndividualContactInfo(any()))
        .thenReturn(new IndividualRequest());

    StepVerifier.create(eventMapper.individualContactMono("bnc", "GCC"))
                .expectError(McpBusinessRuleException.class)
                .verify();
  }

  @Test
  public void testMapIndividualContact_MappingError() {

    when(mcpService.getPtyContactsMono(any(), any()))
        .thenReturn(Mono.just(new GetPtyContactsResponse()));
    when(mcpResponseToBneRequestMapper.mapIndividualContactInfo(any()))
        .thenThrow(new InvalidResponseException("e"));

    StepVerifier.create(eventMapper.individualContactMono("bnc", "GCC"))
                .expectError(InvalidResponseException.class)
                .verify();
  }

  @Test
  public void testMapIndividualSocioDemo_HappyPath() {

    when(mcpService.getSocioDemoMono(any(), any()))
        .thenReturn(Mono.just(new GetIndividualSocioDemographicsResponse()));
    when(mcpResponseToBneRequestMapper.mapIndividualSocioDemographic(any()))
        .thenReturn(new IndividualRequest());

    StepVerifier.create(eventMapper.individualSocioDemoMono("bnc", "GCC"))
                .expectNext(new IndividualRequest())
                .verifyComplete();
  }

  @Test
  public void testMapIndividualSocioDemo_ServiceError() {

    when(mcpService.getSocioDemoMono(any(), any()))
        .thenReturn(Mono.error(() -> new McpBusinessRuleException("e")));
    when(mcpResponseToBneRequestMapper.mapIndividualSocioDemographic(any()))
        .thenReturn(new IndividualRequest());

    StepVerifier.create(eventMapper.individualSocioDemoMono("bnc", "GCC"))
                .expectError(McpBusinessRuleException.class)
                .verify();
  }

  @Test
  public void testMapIndividualId_HappyPath() {

    when(mcpService.getPtyIdentificationMono(any(), any()))
        .thenReturn(Mono.just(new GetPtyIdentificationsResponse()));
    when(mcpResponseToBneRequestMapper.mapIndividualPtyIdentification(any()))
        .thenThrow(new InvalidResponseException("e"));

    StepVerifier.create(eventMapper.individualPtyIdentificationMono("bnc", "GCC"))
                .expectError(InvalidResponseException.class)
                .verify();
  }

  @Test
  public void testMapIndividualId_ServiceError() {

    when(mcpService.getPtyIdentificationMono(any(), any()))
        .thenReturn(Mono.error(() -> new McpBusinessRuleException("e")));
    when(mcpResponseToBneRequestMapper.mapIndividualPtyIdentification(any()))
        .thenReturn(new IndividualRequest());

    StepVerifier.create(eventMapper.individualPtyIdentificationMono("bnc", "GCC"))
                .expectError(McpBusinessRuleException.class)
                .verify();
  }

  @Test
  public void testRelatedOrganizationFromIndividual_HappyPath() {
    when(mcpService.getPtyRelationshipMono(any(), any(), any()))
        .thenReturn(Mono.just(new GetRelationshipsResponse()));
    when(mcpResponseToBneRequestMapper.mapRelatedOrganizationBncIdList(any()))
        .thenReturn(List.of("org1", "org2"));
    when(mcpService.getBaseOrganizationMono(any(), any()))
        .thenReturn(Mono.just(new GetOrganizationResponseType()));
    when(mcpResponseToBneRequestMapper.mapOrganizationBncIdToOtherSystemBySrcId(any(), any()))
        .thenReturn(List.of("orgGcc1", "orgGcc2"));

    StepVerifier.create(eventMapper.relatedOrganizationIdsFromIndividualFlux("bnc", "GCC"))
                .expectNext(
                    new IndividualRequest().general(new General().orgGccNbr("orgGcc1").orgBncId("org1")))
                .expectNext(
                    new IndividualRequest().general(new General().orgGccNbr("orgGcc2").orgBncId("org1")))
                .expectNext(
                    new IndividualRequest().general(new General().orgGccNbr("orgGcc1").orgBncId("org2")))
                .expectNext(
                    new IndividualRequest().general(new General().orgGccNbr("orgGcc2").orgBncId("org2")))
                .verifyComplete();
  }

  @Test
  public void testRelatedOrganizationFromIndividual_Error() {
    when(mcpService.getPtyRelationshipMono(any(), any(), any()))
        .thenReturn(Mono.error(() -> new McpBusinessRuleException("e")));
    when(mcpResponseToBneRequestMapper.mapRelatedOrganizationBncIdList(any()))
        .thenReturn(List.of("org1", "org2"));
    when(mcpService.getBaseOrganizationMono(any(), any()))
        .thenReturn(Mono.just(new GetOrganizationResponseType()));
    when(mcpResponseToBneRequestMapper.mapOrganizationBncIdToOtherSystemBySrcId(any(), any()))
        .thenReturn(List.of("orgGcc1", "orgGcc2"));

    StepVerifier.create(eventMapper.relatedOrganizationIdsFromIndividualFlux("bnc", "GCC"))
                .expectError(McpBusinessRuleException.class)
                .verify();
  }

  @Test
  public void testMapBaseOrg_HappyPath() {

    when(mcpService.getBaseOrganizationMono(any(), any()))
        .thenReturn(Mono.just(new GetOrganizationResponseType()));
    when(mcpResponseToBneRequestMapper.mapBaseOrganization(any()))
        .thenReturn(new OrganizationInput());

    StepVerifier.create(eventMapper.baseOrganizationMono("bnc", "GCC"))
                .expectNext(new OrganizationInput())
                .verifyComplete();
  }

  @Test
  public void testMapOrgAddr_HappyPath() {

    when(mcpService.getPtyAddressMono(any(), any()))
        .thenReturn(Mono.just(new GetPtyAddressesResponse()));
    when(mcpResponseToBneRequestMapper.mapOrganizationAddress(any()))
        .thenReturn(new OrganizationInput());

    StepVerifier.create(eventMapper.organizationAddressMono("bnc", "GCC"))
                .expectNext(new OrganizationInput())
                .verifyComplete();
  }

  @Test
  public void testMapOrgContact_HappyPath() {

    when(mcpService.getPtyContactsMono(any(), any()))
        .thenReturn(Mono.just(new GetPtyContactsResponse()));
    when(mcpResponseToBneRequestMapper.mapOrganizationContactInfo(any()))
        .thenReturn(new OrganizationInput());

    StepVerifier.create(eventMapper.organizationContactMono("bnc", "GCC"))
                .expectNext(new OrganizationInput())
                .verifyComplete();
  }

  @Test
  public void testOrgFcc_HappyPath() {
    when(mcpService.getBaseOrganizationMono(any(), any()))
        .thenReturn(Mono.just(new GetOrganizationResponseType()));
    when(mcpResponseToBneRequestMapper.mapOrganizationBncIdToOtherSystemBySrcId(any(), any()))
        .thenReturn(List.of("orgFcc1", "orgFcc2"));

    StepVerifier.create(eventMapper.organizationFccFlux("bnc", "GCC"))
                .expectNext(new OrganizationInput().noFcc("orgFcc1"))
                .expectNext(new OrganizationInput().noFcc("orgFcc2"))
                .verifyComplete();
  }

  @Test
  public void testAddGccToMcp_HappyPath() {
    when(mcpService.postSystemKeysByBncId(any(), any(), any()))
        .thenReturn(Mono.just(new StandardResponse()));

    StepVerifier.create(eventMapper.addNewGccIdToMcpSystemKeys("bnc", "gcc", EventTargetSystem.GCC.srcCd , "messageId"))
                .expectNext(new StandardResponse())
                .verifyComplete();
  }

  @Test
  public void testOrganizationIdFromIndividual_NoOrgs() {
    when(mcpService.getPtyRelationshipMono(any(), any(), any()))
        .thenReturn(Mono.just(new GetRelationshipsResponse()));
    when(mcpResponseToBneRequestMapper.mapRelatedOrganizationBncIdList(any()))
        .thenReturn(new ArrayList<>());

    StepVerifier.create(eventMapper.relatedOrganizationIdsFromIndividualFlux("bnc", "GCC"))
                .verifyComplete();
  }
}
