package ca.bnc.bne.mcp.event.orchestrator.restassured;

import okhttp3.mockwebserver.MockResponse;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URISyntaxException;

public class McpUpdateIndividualBaseBadResponseStrategy implements IMockReponseStrategy {
    @Override
    public MockResponse supply() throws IOException, URISyntaxException, JSONException {
        return new MockResponse().setResponseCode(400)
                .setBody(new JSONObject().put("status",400)
                        .put("title","BUSINESS RULES VIOLATION")
                        .put("type", "https://wiki.bnc.ca/api/probs/400/business-error")
                        .put("detail","The request violates one or many business rule(s)").toString());
    }

    @Override
    public String endpoint() {
        return "/mcp/v2/individual-api/individuals/base";
    }
}
