package ca.bnc.bne.mcp.event.orchestrator.handler.organization;

import ca.bnc.bne.mcp.event.orchestrator.dto.okta.OktaResponse;
import ca.bnc.bne.mcp.event.orchestrator.dto.server.UpdateIndividualRequest;
import ca.bnc.bne.mcp.event.orchestrator.exception.model.McpWriteException;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.*;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyAddress.UpdatePtyAddressesRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyContact.UpdatePtyContactsRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyRelationship.PostRelationship;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyRelationship.RemovedRelationship;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.socioDemo.UpdateIndividualSocioDemographicsWithBNCIDRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.AddPartySysKeyRequestBncId;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.StandardResponse;
import ca.bnc.bne.mcp.event.orchestrator.handler.individual.IndividualServiceHandler;
import ca.bnc.bne.mcp.event.orchestrator.service.iam.IamService;
import ca.bnc.bne.mcp.event.orchestrator.service.mcp.McpService;
import ca.bnc.bne.mcp.event.orchestrator.service.okta.OktaService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.Arrays;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class OrganizationServiceHandlerTest {

    private static final Logger logger = LoggerFactory.getLogger(OrganizationServiceHandlerTest.class);

    @InjectMocks
    private OrganizationServiceHandler serviceHandler;

    @Mock
    private McpService mcpService;



    @BeforeEach
    void setUp() {
        //MockitoAnnotations.initMocks(this);

        serviceHandler = new OrganizationServiceHandler(mcpService);
    }

    @Test
    public void whenCall_addNewSysIdToMcpSystemKeys_thenReturnSuccessResponse() {

        StandardResponse resp = new StandardResponse().returnStatusCode("200");

        when(mcpService.postSystemKeysByBncId(any(AddPartySysKeyRequestBncId.class), anyString(), anyString()))
                .thenReturn(Mono.just(resp));

        StepVerifier.create(serviceHandler.addNewSysIdToMcpSystemKeys("bncId", "sysId", "srcCd", "requestId", "fakeToken"))
                .expectNextMatches(standardResponse -> standardResponse.getReturnStatusCode().equals("200"))
                .verifyComplete();
    }

    @Test
    public void whenCall_addNewSysIdToMcpSystemKeys_thenReturnFailureResponse() {

        StandardResponse resp = new StandardResponse().returnStatusCode("400");

        when(mcpService.postSystemKeysByBncId(any(AddPartySysKeyRequestBncId.class), anyString(), anyString()))
                .thenReturn(Mono.just(resp));

        StepVerifier.create(serviceHandler.addNewSysIdToMcpSystemKeys("bncId", "sysId", "srcCd", "requestId", "fakeToken"))
                .expectNextMatches(standardResponse -> standardResponse.getReturnStatusCode().equals("400"))
                .verifyComplete();
    }

    @Test
    public void whenCall_addNewSysIdToMcpSystemKeys_thenThrowsError() {

        when(mcpService.postSystemKeysByBncId(any(AddPartySysKeyRequestBncId.class), anyString(), anyString()))
                .thenReturn(Mono.error(new McpWriteException("addNewSysIdToMcpSystemKeys occurs error")));

        StepVerifier.create(serviceHandler
                .addNewSysIdToMcpSystemKeys("bncId", "sysId", "srcCd", "requestId", "fakeToken"))
                .expectError(McpWriteException.class)
                .verify();
    }

}
