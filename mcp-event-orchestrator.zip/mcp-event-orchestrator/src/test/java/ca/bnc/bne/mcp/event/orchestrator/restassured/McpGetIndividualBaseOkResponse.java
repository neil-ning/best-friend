package ca.bnc.bne.mcp.event.orchestrator.restassured;

import ca.bnc.bne.mcp.event.orchestrator.util.JsonFileUtil;
import okhttp3.mockwebserver.MockResponse;

import java.io.IOException;
import java.net.URISyntaxException;

public class McpGetIndividualBaseOkResponse implements IMockReponseStrategy {
    @Override
    public MockResponse supply() throws IOException, URISyntaxException {
        return new MockResponse().setResponseCode(200)
                .addHeader("Content-Type", "application/json; charset=utf-8")
                .setBody(JsonFileUtil.readString("service/mcp/get-individual-base-resp-new.json"));
    }

    @Override
    public String endpoint() {
        return "/mcp/v2/individual-api/individuals/base";
    }
}
