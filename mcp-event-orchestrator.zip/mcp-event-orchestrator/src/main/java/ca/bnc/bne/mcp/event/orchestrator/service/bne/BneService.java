package ca.bnc.bne.mcp.event.orchestrator.service.bne;

import ca.bnc.bne.mcp.event.orchestrator.exception.model.GccBusinessRuleException;
import ca.bnc.bne.mcp.event.orchestrator.exception.model.InvalidResponseException;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.IndividualRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.IndividualResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.ErrorResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.OrganizationInput;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.OrganizationResponse;
import org.slf4j.Logger;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

import java.time.Duration;
import java.util.function.Function;

import static ca.bnc.bne.mcp.event.orchestrator.util.Constants.TARGET_SYSTEM;

@Service
@ConfigurationProperties("bne")
public class BneService {

    private static final Logger logger = org.slf4j.LoggerFactory.getLogger(BneService.class);
    private final WebClient webClient;
    private Endpoint endpoint;

  public BneService(WebClient.Builder builder) {
    this.webClient = builder.build();
    }

  /* General scenarios to consider when dealing with WebClient:
      1. Happy path (200 + proper resp body)
      2. 200 + no resp body (this generally should not occur. If it does, throw exception. Message should not be retried)
      3. Error status + resp body. Either use onStatus() with retrieve() or have custom flatmap logic through exchange()
  */

    public Mono<IndividualResponse> updateIndividual(IndividualRequest request, String targetSys) {
        return webClient
                .put()
                .uri(endpoint.individual)
                .header(TARGET_SYSTEM, targetSys)
                .bodyValue(request)
                .retrieve()
                .onStatus(HttpStatus::is4xxClientError, individualExceptionFunction())
                .bodyToMono(IndividualResponse.class)
                .switchIfEmpty(
            Mono.error(() -> new InvalidResponseException("Empty response from individual api.")));
    //  .retryWhen(retry());
    }

    public Mono<IndividualResponse> deleteIndividual(IndividualRequest request, String targetSys) {
        return webClient
                .method(HttpMethod.DELETE)
                .uri(endpoint.individual)
                .header(TARGET_SYSTEM, targetSys)
                .bodyValue(request)
                .retrieve()
                .onStatus(HttpStatus::is4xxClientError, individualExceptionFunction())
                .bodyToMono(IndividualResponse.class)
                .switchIfEmpty(
            Mono.error(() -> new InvalidResponseException("Empty response from individual api.")));
    // .retryWhen(retry());
    }

    public Mono<IndividualResponse> createIndividual(IndividualRequest request, String targetSys) {
        return webClient
                .post()
                .uri(endpoint.individual)
                .header(TARGET_SYSTEM, targetSys)
                .bodyValue(request)
                .retrieve()
                .onStatus(HttpStatus::is4xxClientError, individualExceptionFunction())
                .bodyToMono(IndividualResponse.class)
                .switchIfEmpty(
            Mono.error(() -> new InvalidResponseException("Empty response from individual api.")));
    // .retryWhen(retry());
    }

    public Mono<OrganizationResponse> createOrganization(OrganizationInput input, String targetSys) {
        return webClient
                .post()
                .uri(endpoint.organization)
                .header(TARGET_SYSTEM, targetSys)
                .bodyValue(input)
                .retrieve()
                .onStatus(HttpStatus::is4xxClientError, organizationExceptionFunction())
                .bodyToMono(OrganizationResponse.class)
                .switchIfEmpty(
            Mono.error(
                () -> new InvalidResponseException("Empty response from organization api.")));
    }

    public Mono<OrganizationResponse> updateOrganization(OrganizationInput input, String targetSys) {
        return webClient
                .put()
                .uri(endpoint.organization)
                .header(TARGET_SYSTEM, targetSys)
                .bodyValue(input)
                .retrieve()
                .onStatus(HttpStatus::is4xxClientError, organizationExceptionFunction())
                .bodyToMono(OrganizationResponse.class)
                .switchIfEmpty(
            Mono.error(
                () -> new InvalidResponseException("Empty response from organization api.")));
    }

    public Mono<OrganizationResponse> deleteOrganization(OrganizationInput input, String targetSys) {
        return webClient
                .method(HttpMethod.DELETE)
                .uri(endpoint.organization)
                .header(TARGET_SYSTEM, targetSys)
                .bodyValue(input)
                .retrieve()
                .onStatus(HttpStatus::is4xxClientError, organizationExceptionFunction())
                .bodyToMono(OrganizationResponse.class)
                .switchIfEmpty(
            Mono.error(
                () -> new InvalidResponseException("Empty response from organization api.")));
    }

    private Function<ClientResponse, Mono<? extends Throwable>> organizationExceptionFunction() {
        return clientResponse ->
                clientResponse
            .bodyToMono(ErrorResponse.class)
                        .switchIfEmpty(
                Mono.defer(() -> Mono.just(new ErrorResponse().message("No error response body."))))
                        .flatMap(
                                organizationResponse ->
                                        Mono.error(
                                                () -> new GccBusinessRuleException(organizationResponse.getMessage())));
    }

    private Function<ClientResponse, Mono<? extends Throwable>> individualExceptionFunction() {
        return clientResponse ->
                clientResponse
                        .bodyToMono(IndividualResponse.class)
                        .switchIfEmpty(
                                Mono.defer(
                                        () ->
                                                Mono.just(
                                                        new IndividualResponse().code(400).message("No error response body."))))
                        .flatMap(
                                individualResponse ->
                                        Mono.error(
                                                () -> new GccBusinessRuleException(individualResponse.getMessage())));
    }

    private Retry retry() {
        return Retry.backoff(3, Duration.ofSeconds(1))
                .jitter(0d)
                .doBeforeRetry(
                        retrySignal ->
                                logger.info(
                                        "Service failed. Retrying. Error message = {}. ",
                                        retrySignal.failure().getMessage()))
                .doAfterRetry(
                        retrySignal -> logger.info("Retry count = {}", retrySignal.totalRetries() + 1))
                .onRetryExhaustedThrow((retryBackoffSpec, retrySignal) -> retrySignal.failure());
    }

    public WebClient getWebClient() {
        return this.webClient;
    }

    public Endpoint getEndpoint() {
        return this.endpoint;
    }

    public void setEndpoint(Endpoint endpoint) {
        this.endpoint = endpoint;
    }

    static class Endpoint {

        private String organization;
        private String individual;

        public String getOrganization() {
            return organization;
        }

        public Endpoint setOrganization(String organization) {
            this.organization = organization;
            return this;
        }

        public String getIndividual() {
            return individual;
        }

        public Endpoint setIndividual(String individual) {
            this.individual = individual;
            return this;
        }
    }
}
