package ca.bnc.bne.mcp.event.orchestrator.strategy;

import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.OrganizationInput;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.OrganizationResponse;
import ca.bnc.bne.mcp.event.orchestrator.service.bne.BneService;
import reactor.core.publisher.Mono;

public enum OrganizationTechActionStrategy {
  CREATE {
    public Mono<OrganizationResponse> callOrganization(
        BneService bneService, OrganizationInput request, String targetSys) {
      return bneService.createOrganization(request, targetSys);
    }
  },
  UPDATE {
    public Mono<OrganizationResponse> callOrganization(
        BneService bneService, OrganizationInput request, String targetSys) {
      return bneService.updateOrganization(request, targetSys);
    }
  },
  DELETE {
    public Mono<OrganizationResponse> callOrganization(
        BneService bneService, OrganizationInput request, String targetSys) {
      return bneService.deleteOrganization(request, targetSys);
    }
  };

  public abstract Mono<OrganizationResponse> callOrganization(
      BneService service, OrganizationInput request, String targetSys);
}
