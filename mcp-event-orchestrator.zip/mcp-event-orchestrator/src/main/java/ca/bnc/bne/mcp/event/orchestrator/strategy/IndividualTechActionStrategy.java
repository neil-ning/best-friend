package ca.bnc.bne.mcp.event.orchestrator.strategy;

import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.IndividualRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.IndividualResponse;
import ca.bnc.bne.mcp.event.orchestrator.service.bne.BneService;
import reactor.core.publisher.Mono;

public enum IndividualTechActionStrategy {
  CREATE {
    public Mono<IndividualResponse> callIndividual(
        BneService bneService, IndividualRequest request, String targetSys) {
      return bneService.createIndividual(request, targetSys);
    }
  },
  UPDATE {
    public Mono<IndividualResponse> callIndividual(
        BneService bneService, IndividualRequest request, String targetSys) {
      return bneService.updateIndividual(request, targetSys);
    }
  },
  DELETE {
    public Mono<IndividualResponse> callIndividual(
        BneService bneService, IndividualRequest request, String targetSys) {
      return bneService.deleteIndividual(request, targetSys);
    }
  };

  public abstract Mono<IndividualResponse> callIndividual(
      BneService service, IndividualRequest request, String targetSys);
}
