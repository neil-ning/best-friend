package ca.bnc.bne.mcp.event.orchestrator.controller.event;

import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventInformation.PartyTypeEnum;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventRequest;
import ca.bnc.bne.mcp.event.orchestrator.handler.individual.IndividualEventHandler;
import ca.bnc.bne.mcp.event.orchestrator.handler.organization.OrganizationEventHandler;
import ca.bnc.bne.mcp.event.orchestrator.strategy.EventStrategy;
import java.util.HashMap;
import java.util.Map;
import javax.validation.Valid;
import org.slf4j.Logger;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/mcp/event")
public class EventController {

  private static final Logger logger = org.slf4j.LoggerFactory.getLogger(EventController.class);
  private final IndividualEventHandler individualHandler;
  private final OrganizationEventHandler organizationHandler;

  public EventController(
      IndividualEventHandler individualHandler, OrganizationEventHandler organizationHandler) {
    this.individualHandler = individualHandler;
    this.organizationHandler = organizationHandler;
  }

  @PostMapping(
      value = "/handle",
      produces = MediaType.APPLICATION_JSON_VALUE,
      consumes = MediaType.APPLICATION_JSON_VALUE)
  public Mono<Void> handleEvent(@RequestBody @Valid EventRequest request) {
    // Cant use doOnNext here because the inner publisher is not linked and will not execute
    return Mono.defer(() -> Mono.just(request))
        .doOnNext(r -> logger.info(r.toString()))
        .flatMap(
            e ->
                new HandlerSupplier()
                    .getHandler(request.getEventInformation().getPartyType())
                    .invoke(request))
        .doOnSuccess(aVoid -> logger.info("Completed processing event."));
  }

  class HandlerSupplier {

    private final Map<PartyTypeEnum, EventStrategy> eventStrategyMap;

    public HandlerSupplier() {
      this.eventStrategyMap = new HashMap<>();
      registerStrategy();
    }

    private void registerStrategy() {
      eventStrategyMap.put(PartyTypeEnum.I, individualHandler);
      eventStrategyMap.put(PartyTypeEnum.O, organizationHandler);
    }

    public EventStrategy getHandler(PartyTypeEnum partyType) {
      EventStrategy eventStrategy = eventStrategyMap.get(partyType);
      if (eventStrategy == null) {
        throw new IllegalArgumentException("Handler not registered.");
      }
      return eventStrategy;
    }
  }
}
