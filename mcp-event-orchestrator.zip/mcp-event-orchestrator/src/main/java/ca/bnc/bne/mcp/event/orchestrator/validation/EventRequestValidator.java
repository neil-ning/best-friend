package ca.bnc.bne.mcp.event.orchestrator.validation;

import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventInformation;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventInformation.PartyTypeEnum;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.PartyKey;
import ca.bnc.bne.mcp.event.orchestrator.strategy.IndividualBusinessObjectStrategy;
import ca.bnc.bne.mcp.event.orchestrator.strategy.OrganizationBusinessObjectStrategy;
import java.util.EnumSet;
import org.apache.commons.lang3.EnumUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Component
public class EventRequestValidator implements Validator {

  @Override
  public boolean supports(Class<?> clazz) {
    return EventRequest.class.equals(clazz);
  }

  @Override
  public void validate(Object target, Errors errors) {
    EventRequest request = (EventRequest) target;
    validateEventRequest(request, errors);

    EventInformation eventInformation = request.getEventInformation();
    validateEventInformation(eventInformation, errors);

    PartyKey partyKey = eventInformation.getPartyKey();
    validatePartyKey(partyKey, errors);

    validateBusinessObjects(eventInformation, errors);
  }

  private void validateEventRequest(EventRequest request, Errors errors) {
    if (request.getEventInformation() == null) {
      errors.rejectValue(
          "eventInformation", "eventInformation.empty", "Event Information must be non empty");
    }
  }

  private void validateEventInformation(EventInformation eventInformation, Errors errors) {
    if (!EnumSet.allOf(EventInformation.PartyActionEnum.class)
        .contains(eventInformation.getPartyAction())) {
      errors.rejectValue(
          "eventInformation.partyAction",
          "invalid.partyAction",
          "Party Action is not a valid value. Please only use one of the following: EDIT, MERGE, UNMERGE");
    }
    if (!EnumSet.allOf(EventInformation.PartyTypeEnum.class)
        .contains(eventInformation.getPartyType())) {
      errors.rejectValue(
          "eventInformation.partyType",
          "invalid.partyType",
          "Party type is not a valid value. Please only use one of the following: I (Individual), O (Organization)");
    }
    if (eventInformation.getPartyKey() == null) {
      errors.rejectValue(
          "eventInformation.partyKey", "partyKey.empty", "PartyKey must be non empty");
    }
    if (eventInformation.getEventAction() == null) {
      errors.rejectValue(
          "eventInformation.eventAction", "eventAction.empty", "Event action must be non empty");
    }
  }

  private void validatePartyKey(PartyKey partyKey, Errors errors) {
    if (StringUtils.isEmpty(partyKey.getBncId())) {
      errors.rejectValue("eventInformation.partyKey.bncId", "bncId.empty", "bncId is missing");
    }
    if (!EnumSet.allOf(PartyKey.PartyRoleEnum.class).contains(partyKey.getPartyRole())) {
      errors.rejectValue(
          "eventInformation.partyKey.partyRole",
          "invalid.partyRole",
          "Party role is not a valid value. Please only use one of the following: EDITEE, MERGER, MERGEE, UNMERGER, UNMERGEE");
    }
  }

  private void validateBusinessObjects(EventInformation eventInformation, Errors errors) {
    boolean validBo = true;
    if (eventInformation.getPartyType() == PartyTypeEnum.I) {
      validBo =
          EnumUtils.isValidEnum(
              IndividualBusinessObjectStrategy.class,
              eventInformation.getEventAction().getBusinessObject().toString());
    } else if (eventInformation.getPartyType() == PartyTypeEnum.O) {
      validBo =
          EnumUtils.isValidEnum(
              OrganizationBusinessObjectStrategy.class,
              eventInformation.getEventAction().getBusinessObject().toString());
    }
    if (!validBo) {
      errors.rejectValue(
          "eventInformation.eventAction.businessObject",
          "invalid.bo",
          "Invalid business object. Please check if the business object can be handled by the partyType.");
    }
  }
}
