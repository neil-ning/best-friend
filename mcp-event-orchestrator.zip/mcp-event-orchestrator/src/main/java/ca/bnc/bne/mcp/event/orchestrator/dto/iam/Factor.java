package ca.bnc.bne.mcp.event.orchestrator.dto.iam;


public class Factor {
  private String phoneNumber;
  private String phoneExtension;

  public Factor(String phoneNumber) {
    this.phoneNumber = phoneNumber;
  }

  public Factor(String phoneNumber, String phoneExtension) {
    this.phoneNumber = phoneNumber;
    this.phoneExtension = phoneExtension;
  }

  public String getPhoneNumber() {
    return phoneNumber;
  }

  public void setPhoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
  }

  public String getPhoneExtension() {
    return phoneExtension;
  }

  public void setPhoneExtension(String phoneExtension) {
    this.phoneExtension = phoneExtension;
  }

  @Override
  public String toString() {
    return "Factor{" +
        "phoneNumber='" + phoneNumber + '\'' +
        ", phoneExtension='" + phoneExtension + '\'' +
        '}';
  }
}
