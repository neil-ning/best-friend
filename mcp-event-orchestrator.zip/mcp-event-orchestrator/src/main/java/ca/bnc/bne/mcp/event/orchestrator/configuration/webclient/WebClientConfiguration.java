package ca.bnc.bne.mcp.event.orchestrator.configuration.webclient;

import io.netty.channel.ChannelOption;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.SSLException;
import org.slf4j.Logger;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.web.reactive.function.client.WebClientCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;
import reactor.netty.tcp.SslProvider;
import reactor.netty.tcp.TcpClient;

@Configuration
@ConfigurationProperties("webclient")
public class WebClientConfiguration implements WebClientCustomizer {

  private static final Logger logger =
      org.slf4j.LoggerFactory.getLogger(WebClientConfiguration.class);
  private int connectTimeout = 30000;
  private int readTimeout = 30000;
  private int writeTimeout = 30000;

  // WebClientAutoConfiguration creates Builder bean for us so we just need to customize it
  @Override
  public void customize(WebClient.Builder webClientBuilder) {
    webClientBuilder.clientConnector(
        new ReactorClientHttpConnector(
            HttpClient.from(tcpClient()).secure(this::accept))); // configure to use SSL
  }

  private TcpClient tcpClient() {
    return TcpClient.create()
        .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, connectTimeout)
        .doOnConnected(
            connection -> {
              connection.addHandlerLast(new ReadTimeoutHandler(readTimeout, TimeUnit.MILLISECONDS));
              connection.addHandlerLast(
                  new WriteTimeoutHandler(writeTimeout, TimeUnit.MILLISECONDS));
            });
  }

  @Bean
  public SslContext context() throws SSLException {
    return SslContextBuilder.forClient().trustManager(InsecureTrustManagerFactory.INSTANCE).build();
  }

  private void accept(SslProvider.SslContextSpec ssl) {
    try {
      ssl.sslContext(context());
    } catch (SSLException e) {
      logger.error(e.getMessage());
    }
  }

  public int getConnectTimeout() {
    return connectTimeout;
  }

  public WebClientConfiguration setConnectTimeout(int connectTimeout) {
    this.connectTimeout = connectTimeout;
    return this;
  }

  public int getReadTimeout() {
    return readTimeout;
  }

  public WebClientConfiguration setReadTimeout(int readTimeout) {
    this.readTimeout = readTimeout;
    return this;
  }

  public int getWriteTimeout() {
    return writeTimeout;
  }

  public WebClientConfiguration setWriteTimeout(int writeTimeout) {
    this.writeTimeout = writeTimeout;
    return this;
  }
}
