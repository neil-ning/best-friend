package ca.bnc.bne.mcp.event.orchestrator.service.okta;

import ca.bnc.bne.mcp.event.orchestrator.dto.okta.OktaResponse;
import ca.bnc.bne.mcp.event.orchestrator.exception.model.OktaTokenException;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.client.ExchangeFilterFunctions;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;
import reactor.util.retry.Retry;

import java.time.Duration;
import java.util.Collections;

import javax.net.ssl.SSLException;

import static ca.bnc.bne.mcp.event.orchestrator.util.Constants.OKTA_GRANT_KEY;
import static ca.bnc.bne.mcp.event.orchestrator.util.Constants.OKTA_GRANT_VALUE;
import static ca.bnc.bne.mcp.event.orchestrator.util.Constants.OKTA_SCOPE_KEY;
import static ca.bnc.bne.mcp.event.orchestrator.util.Constants.OKTA_SCOPE_VALUE_MCP;

@Service
@EnableCaching
public class OktaService {

        private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(OktaService.class);
        private final WebClient gccWebClient, sbieWebClient;

        @Value("${okta.gcc.context-path}")
        private String gccContextPath;
        @Value("${okta.sbie.context-path}")
        private String sbieContextPath;

        public static final String GCC = "GCC", SBIE = "SBIE";

        public OktaService(@Value("${okta.base-url}") String baseUrl,
                        @Value("${okta.gcc.credentials.username}") String gccUsername,
                        @Value("${okta.gcc.credentials.pw}") String gccPw,
                        @Value("${okta.sbie.credentials.username}") String sbieUsername,
                        @Value("${okta.sbie.credentials.pw}") String sbiePw) throws SSLException {

        LOGGER.debug(
                "OktaService initializes webClient with baseUrl:[{}], gccUsername:[{}], gccPw:[{}], sbieUsername:[{}],sbiePw:[{}]"
                , baseUrl, gccUsername, gccPw, sbieUsername, sbiePw);

        //TODO : bypass SSL certification for now. 
        //We need get back to this issue later to see how to install the certificates for OCTA token API.

        SslContext sslContext = SslContextBuilder.forClient().trustManager(InsecureTrustManagerFactory.INSTANCE).build();
        ClientHttpConnector  httpConnector  = new ReactorClientHttpConnector(HttpClient.create().secure(t -> t.sslContext(sslContext) ));

        this.gccWebClient = WebClient.builder()
                .clientConnector(httpConnector) 
                .baseUrl(baseUrl)
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED_VALUE)
                .filter(ExchangeFilterFunctions.basicAuthentication(gccUsername, gccPw))
                .build();

        sbieWebClient = WebClient.builder()
                .clientConnector(httpConnector)                
                .baseUrl(baseUrl)
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED_VALUE)
                .filter(ExchangeFilterFunctions.basicAuthentication(sbieUsername, sbiePw))
                .build();
    }

  public Mono<OktaResponse> postOktaAccessTokenGcc(String targetSys){
    return postOktaAccessToken(GCC);
  }

  public Mono<OktaResponse> postOktaAccessTokenSbie(String targetSys){
      return postOktaAccessToken(SBIE);
  }

    public Mono<OktaResponse> postOktaAccessToken(String targetSys) {

        LOGGER.info("OKTA_GRANT_KEY:[{}]", OKTA_GRANT_VALUE);

        MultiValueMap<String, String> oktaRequest = new LinkedMultiValueMap<>();
        oktaRequest.put(
                OKTA_GRANT_KEY, Collections.singletonList(OKTA_GRANT_VALUE));
        //oktaRequest.put(
        //Constants.OKTA_SCOPE_KEY, Collections.singletonList(Constants.OKTA_SCOPE_VALUE_MCP + Constants.OKTA_SCOPE_VALUE_IAM));
        oktaRequest.put(OKTA_SCOPE_KEY, Collections.singletonList(OKTA_SCOPE_VALUE_MCP));

        if(StringUtils.equalsIgnoreCase(targetSys, GCC)){
          return gccWebClient
                  .post()
                  .uri(gccContextPath)
                  .bodyValue(oktaRequest)
                  .retrieve()
                  .bodyToMono(OktaResponse.class).log()
                  .onErrorResume(
                          WebClientResponseException.class,
                          e -> Mono.error(() -> new OktaTokenException(e.getResponseBodyAsString())))
                  .switchIfEmpty(Mono.error(() -> new OktaTokenException("No Okta token received!")))
                  .retryWhen(retry());
        }else if(StringUtils.equalsIgnoreCase(targetSys, SBIE)){
          return sbieWebClient
                  .post()
                  .uri(sbieContextPath)
                  .bodyValue(oktaRequest)
                  .retrieve()
                  .bodyToMono(OktaResponse.class).log()
                  .onErrorResume(
                          WebClientResponseException.class,
                          e -> Mono.error(() -> new OktaTokenException(e.getResponseBodyAsString())))
                  .switchIfEmpty(Mono.error(() -> new OktaTokenException("No Okta token received!")))
                  .retryWhen(retry());
        }

        return Mono.error(()-> new IllegalArgumentException("postOktaAccessToken method Entered an illegal argument targetSys."));
    }

    public Mono<OktaResponse> cacheToken(String targetSys) {
        return postOktaAccessToken(targetSys)
                .cache(
                        oktaResponse -> Duration.ofSeconds(3000),
                        throwable -> Duration.ZERO,
                        () -> Duration.ZERO);
    }

    private Retry retry() {
        return Retry.backoff(3, Duration.ofSeconds(1))
                .jitter(0d)
                .doBeforeRetry(
                        retrySignal ->
                                LOGGER.info(
                                        "Service failed. Retrying. Error message = {}. ",
                                        retrySignal.failure().getMessage()))
                .doAfterRetry(
                        retrySignal -> LOGGER.info("Retry count = {}", retrySignal.totalRetries() + 1))
                .onRetryExhaustedThrow((retryBackoffSpec, retrySignal) -> retrySignal.failure());
    }

  public void setGccContextPath(String gccContextPath) {
    this.gccContextPath = gccContextPath;
  }

  public void setSbieContextPath(String sbieContextPath) {
    this.sbieContextPath = sbieContextPath;
  }
}
