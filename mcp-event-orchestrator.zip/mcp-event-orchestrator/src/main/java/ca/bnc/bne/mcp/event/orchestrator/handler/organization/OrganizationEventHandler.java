package ca.bnc.bne.mcp.event.orchestrator.handler.organization;

import ca.bnc.bne.mcp.event.orchestrator.exception.model.InvalidResponseException;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventAction.BusinessObjectEnum;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventAction.TechnicalActionEnum;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventInformation;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventInformation.PartyActionEnum;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.PartyKey;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.OrganizationInput;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.OrganizationInput.EventBusinessObjectEnum;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.OrganizationInput.EventPtyActionEnum;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.OrganizationInput.EventTechActionEnum;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.OrganizationResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.StandardResponse;
import ca.bnc.bne.mcp.event.orchestrator.handler.EventTargetSystem;
import ca.bnc.bne.mcp.event.orchestrator.mapper.EventMapper;
import ca.bnc.bne.mcp.event.orchestrator.mapper.organization.OrganizationMapper;
import ca.bnc.bne.mcp.event.orchestrator.service.bne.BneService;
import ca.bnc.bne.mcp.event.orchestrator.strategy.EventStrategy;
import ca.bnc.bne.mcp.event.orchestrator.strategy.OrganizationBusinessObjectStrategy;
import ca.bnc.bne.mcp.event.orchestrator.strategy.OrganizationTechActionStrategy;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import org.slf4j.Logger;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
public class OrganizationEventHandler implements EventStrategy {

  private static final Logger logger =
      org.slf4j.LoggerFactory.getLogger(OrganizationEventHandler.class);

  private final EventMapper eventMapper;
  private final BneService bneService;
  private OrganizationMapper organizationMapper;

  public OrganizationEventHandler(
      EventMapper eventMapper, BneService bneService, OrganizationMapper organizationMapper) {
    this.eventMapper = eventMapper;
    this.bneService = bneService;
    this.organizationMapper = organizationMapper;
  }

  @Override
  public Mono<Void> invoke(EventRequest request) {
    EventInformation event = request.getEventInformation();
    String id = request.getMessageId();
    PartyKey key = event.getPartyKey();
    String bncId = key.getBncId();
    BusinessObjectEnum businessObject = event.getEventAction().getBusinessObject();
    TechnicalActionEnum techAction = event.getEventAction().getTechnicalAction();
    PartyActionEnum partyAction = event.getPartyAction();
    String targetSys = request.getTargetSystem().toString();

    return buildOrganizationRequest(invokeMcpServices(bncId, businessObject,targetSys))
        .map(r -> buildBaseRequest(id, bncId, businessObject, techAction, partyAction, r))
        .flatMapMany(r -> buildOrganizationInputWithNewOrgBncId(key.getMergeInformation(), r))
        .flatMap(r -> buildOrganizationInputWithGccId(key.getMemberIds(), r))
        .doOnNext(organizationInput -> logger.info(organizationInput.toString()))
        .flatMap(r -> callBneOrganization(techAction, r, targetSys))
        .flatMap(resp -> addGccSystemKeyToMcp(id, bncId, resp, targetSys))
        .checkpoint()
        .then()
        .log();
  }

  private OrganizationInput buildBaseRequest(
      String id,
      String bncId,
      BusinessObjectEnum businessObject,
      TechnicalActionEnum techAction,
      PartyActionEnum partyAction,
      OrganizationInput r) {
    return r.requestId(id)
        .orgBncId(bncId)
        .eventBusinessObject(EventBusinessObjectEnum.fromValue(businessObject.toString()))
        .eventTechAction(EventTechActionEnum.valueOf(techAction.toString()))
        .eventPtyAction(EventPtyActionEnum.fromValue(partyAction.toString()));
  }

  private List<Mono<OrganizationInput>> invokeMcpServices(
      String bncId, BusinessObjectEnum businessObject, String targetSys) {
    return OrganizationBusinessObjectStrategy.valueOf(businessObject.toString())
        .invokeMcpServices(bncId, eventMapper, targetSys);
  }

  private Mono<OrganizationResponse> callBneOrganization(
      TechnicalActionEnum techAction, OrganizationInput r, String targetSys) {
    return OrganizationTechActionStrategy.valueOf(techAction.toString())
        .callOrganization(bneService, r, targetSys);
  }

  Mono<StandardResponse> addGccSystemKeyToMcp(
      String messageId, String bncId, OrganizationResponse response,  String targetSys) {
    return Mono.justOrEmpty(response)
        .flatMap(organizationResponse -> Mono.justOrEmpty(organizationResponse.getSystemId()))
        .flatMap(systemId -> eventMapper.addNewGccIdToMcpSystemKeys(bncId, systemId, EventTargetSystem.valueOf(targetSys).srcCd , messageId))
        .switchIfEmpty(
            Mono.fromSupplier(
                () ->
                    new StandardResponse()
                        .returnStatusCode("200")
                        .returnStatusMessage("No system id returned.")
                        .returnDate(LocalDateTime.now().toString())));
  }

  Mono<OrganizationInput> buildOrganizationRequest(List<Mono<OrganizationInput>> monos) {
    return Mono.zip(
            monos,
            objects ->
                Arrays.stream(objects)
                    .map(o -> (OrganizationInput) o)
                    .reduce(
                        new OrganizationInput(),
                        (organizationInput, organizationInput2) ->
                            organizationMapper.updateOrganizationInput(
                                organizationInput, organizationInput2)))
        .switchIfEmpty(
            Mono.error(
                () ->
                    new InvalidResponseException(
                        "One or more MCP responses returned empty. Please check")));
  }

  Flux<OrganizationInput> buildOrganizationInputWithNewOrgBncId(
      List<String> mergeIds, OrganizationInput input) {
    return buildAndMapFromCollection(mergeIds, input, input::newOrgBncId);
  }

  Flux<OrganizationInput> buildOrganizationInputWithGccId(
      List<String> gccIds, OrganizationInput input) {
    return buildAndMapFromCollection(gccIds, input, input::orgSystemId);
  }

  public EventMapper getEventMapper() {
    return eventMapper;
  }

  public BneService getBneService() {
    return bneService;
  }

  public OrganizationMapper getOrganizationMapper() {
    return organizationMapper;
  }

  public OrganizationEventHandler setOrganizationMapper(OrganizationMapper organizationMapper) {
    this.organizationMapper = organizationMapper;
    return this;
  }
}
