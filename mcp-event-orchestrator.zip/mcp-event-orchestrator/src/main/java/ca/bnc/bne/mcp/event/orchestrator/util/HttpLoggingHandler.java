package ca.bnc.bne.mcp.event.orchestrator.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;

import java.nio.charset.StandardCharsets;

import io.netty.handler.logging.LoggingHandler;

/**
 * https://www.baeldung.com/spring-log-webclient-calls
 */
public class HttpLoggingHandler extends LoggingHandler {

    @Override
    protected String format(ChannelHandlerContext ctx, String event, Object arg) {
        if (arg instanceof ByteBuf) {
            ByteBuf msg = (ByteBuf) arg;
            try {
                /*json content*/
                ObjectMapper objectMapper = new ObjectMapper();
                return objectMapper.readTree(msg.toString(StandardCharsets.UTF_8)).toPrettyString();
            } catch (JsonProcessingException e) {
                /*non-json content*/
            }
            return msg.toString(StandardCharsets.UTF_8);
        }
        return super.format(ctx, event, arg);
    }
}
