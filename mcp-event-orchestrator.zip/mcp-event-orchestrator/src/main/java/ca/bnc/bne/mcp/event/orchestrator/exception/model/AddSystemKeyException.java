package ca.bnc.bne.mcp.event.orchestrator.exception.model;

public class AddSystemKeyException extends RuntimeException {

  public AddSystemKeyException() {
    super();
  }

  public AddSystemKeyException(Throwable cause) {
    super(cause);
  }

  public AddSystemKeyException(String message) {
    super(message);
  }

  public AddSystemKeyException(String message, Throwable cause) {
    super(message, cause);
  }
}
