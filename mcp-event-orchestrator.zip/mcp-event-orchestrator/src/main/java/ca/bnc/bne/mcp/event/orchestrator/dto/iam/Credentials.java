package ca.bnc.bne.mcp.event.orchestrator.dto.iam;


public class Credentials {
  private String password;

  Credentials(String password) {
    this.password = password;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }
}
