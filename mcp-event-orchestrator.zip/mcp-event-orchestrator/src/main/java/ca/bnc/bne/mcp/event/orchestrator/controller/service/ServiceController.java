package ca.bnc.bne.mcp.event.orchestrator.controller.service;


import ca.bnc.bne.mcp.event.orchestrator.dto.server.UpdateIndividualRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.OrganizationCompanyResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.*;
import ca.bnc.bne.mcp.event.orchestrator.handler.individual.IndividualServiceHandler;
import ca.bnc.bne.mcp.event.orchestrator.handler.organization.OrganizationServiceHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import javax.validation.Valid;
import java.time.LocalDateTime;

import static ca.bnc.bne.mcp.event.orchestrator.util.Constants.*;

/**
 * Controller to handle the data change service calls from SBIE side
 */
@RestController
public class ServiceController {

    private static final Logger logger = LoggerFactory.getLogger(ServiceController.class);

    private final OrganizationServiceHandler organizationServiceHandler;
    private final IndividualServiceHandler individualServiceHandler;

    public ServiceController(OrganizationServiceHandler organizationServiceHandler,
                            IndividualServiceHandler individualServiceHandler) {
        this.organizationServiceHandler = organizationServiceHandler;
        this.individualServiceHandler = individualServiceHandler;
    }

    @ResponseStatus(HttpStatus.OK)
    @PatchMapping(value = REST_API_PATH_SERVICE_ORGANIZATION, produces = {MediaType.APPLICATION_JSON_VALUE})
    public Mono<OrganizationCompanyResponse> addNewOrganizationSystemKey(
            @RequestParam @Valid String bncId,
            @RequestParam @Valid String sysId,
            @RequestParam @Valid String srcCd,
            @RequestHeader(required = false) @Valid String requestId,
            @RequestHeader(required = true) @Valid String Authorization) {
        final String token = Authorization.substring("Bearer ".length());
        return organizationServiceHandler.addNewSysIdToMcpSystemKeys(bncId, sysId, srcCd, requestId, token)
                .map(standardResponse -> {
            OrganizationCompanyResponse resp = new OrganizationCompanyResponse()
                    .requestId(requestId)
                    .status(Integer.valueOf(standardResponse.getReturnStatusCode()))
                    .message(standardResponse.getReturnStatusMessage())
                    .timestamp(standardResponse.getReturnDate());

            return resp;
        });
    }

    @PatchMapping(value = REST_API_PATH_SERVICE_ADMIN, produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseStatus(HttpStatus.OK)
    public Mono<IndividualAdminResponse> addNewIndividualSystemKey(
            @RequestParam @Valid String bncId,
            @RequestParam @Valid String sysId,
            @RequestParam @Valid String srcCd,
            @RequestHeader(required = false) @Valid String requestId,
            @RequestHeader(required = true) @Valid String Authorization) {
        final String token = Authorization.substring("Bearer ".length());

        return individualServiceHandler.addNewSysIdToMcpSystemKeys(bncId, sysId, srcCd, token, requestId)
                .map(standardResponse -> {
                    IndividualAdminResponse resp = new IndividualAdminResponse()
                            .status(Integer.valueOf(standardResponse.getReturnStatusCode()))
                            .message(standardResponse.getReturnStatusMessage())
                            .timestamp(standardResponse.getReturnDate());

                    return resp;
                });
    }

    @ResponseStatus(HttpStatus.CREATED)
    @PostMapping(value = REST_API_PATH_SERVICE_USER, consumes = {MediaType.APPLICATION_JSON_VALUE}
    , produces = {MediaType.APPLICATION_JSON_VALUE})
    public Mono<AddIndividualResponse> addNewIndividual(
            @RequestBody @Valid CreateIndividualRequest createIndividualRequest,
            @RequestParam @Valid String orgBncId,
            @RequestHeader(required = false) @Valid String requestId,
            @RequestHeader(required = true) @Valid String Authorization) {
        final String token = Authorization.substring("Bearer ".length());

        return individualServiceHandler.createIndividual(createIndividualRequest, orgBncId, token, requestId);
    }


    @ResponseStatus(HttpStatus.OK)
    @PutMapping(value = REST_API_PATH_SERVICE_USER, consumes = {MediaType.APPLICATION_JSON_VALUE}
            , produces = {MediaType.APPLICATION_JSON_VALUE})
    public Mono<UpdateIndividualResponse> updateIndividual(
            @RequestParam @Valid String userBncId,
            @RequestBody @Valid UpdateIndividualRequest updateIndividualRequest,
            @RequestHeader(required = false) @Valid String requestId,
            @RequestHeader(required = true) @Valid String Authorization) {
        final String token = Authorization.substring("Bearer ".length());

        Mono<Void> ret = individualServiceHandler.updateIndividual(userBncId, updateIndividualRequest, token, requestId);

        return ret.thenReturn(new UpdateIndividualResponse().status(HttpStatus.OK.value())
                .message("update individual in mcp success").requestId(requestId).timestamp(LocalDateTime.now().toString()));
    }

    @ResponseStatus(HttpStatus.NO_CONTENT)
    @DeleteMapping(value = REST_API_PATH_SERVICE_USER, produces = {MediaType.APPLICATION_JSON_VALUE})
    public Mono<DeleteIndividualResponse> deleteIndividual(
            @RequestParam @Valid String userBncId,
            @RequestParam @Valid String userSysId,
            @RequestParam @Valid String srcCd,
            @RequestParam @Valid String relationshipId,
            @RequestHeader(required = false) @Valid String requestId,
            @RequestHeader(required = true) @Valid String Authorization) {
        final String token = Authorization.substring("Bearer ".length());

        return individualServiceHandler.deleteIndividual(userBncId, userSysId, srcCd, relationshipId, token, requestId)
                .thenReturn(new DeleteIndividualResponse().requestId(requestId).message("delete individual success")
                .status(HttpStatus.NO_CONTENT.value()).timestamp(LocalDateTime.now().toString()));
    }
}
