package ca.bnc.bne.mcp.event.orchestrator.exception.error;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.validation.FieldError;

public class ValidationError extends Error {

  private List<ValidationInfo> errors;

  public ValidationError addValidationErrors(List<FieldError> fieldErrors) {
    this.errors =
        fieldErrors.stream()
            .map(
                fieldError ->
                    new ValidationInfo()
                        .setField(fieldError.getField())
                        .setMessage(fieldError.getDefaultMessage())
                        .setObject(fieldError.getObjectName()))
            .collect(Collectors.toList());

    return this;
  }

  public List<ValidationInfo> getErrors() {
    return errors;
  }

  public ValidationError setErrors(List<ValidationInfo> errors) {
    this.errors = errors;
    return this;
  }

  static class ValidationInfo {

    private String object;
    private String field;
    private String message;

    public String getObject() {
      return object;
    }

    public ValidationInfo setObject(String object) {
      this.object = object;
      return this;
    }

    public String getField() {
      return field;
    }

    public ValidationInfo setField(String field) {
      this.field = field;
      return this;
    }

    public String getMessage() {
      return message;
    }

    public ValidationInfo setMessage(String message) {
      this.message = message;
      return this;
    }
  }
}
