package ca.bnc.bne.mcp.event.orchestrator.handler.individual;

import ca.bnc.bne.mcp.event.orchestrator.exception.model.InvalidResponseException;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.General;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.IndividualRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.IndividualRequest.EventBusinessObjectEnum;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.IndividualRequest.EventPtyActionEnum;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.IndividualRequest.EventTechActionEnum;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.IndividualResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventAction.BusinessObjectEnum;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventAction.TechnicalActionEnum;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventInformation;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventInformation.PartyActionEnum;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.PartyKey;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.StandardResponse;
import ca.bnc.bne.mcp.event.orchestrator.handler.EventTargetSystem;
import ca.bnc.bne.mcp.event.orchestrator.mapper.EventMapper;
import ca.bnc.bne.mcp.event.orchestrator.mapper.individual.IndividualMapper;
import ca.bnc.bne.mcp.event.orchestrator.service.bne.BneService;
import ca.bnc.bne.mcp.event.orchestrator.strategy.EventStrategy;
import ca.bnc.bne.mcp.event.orchestrator.strategy.IndividualBusinessObjectStrategy;
import ca.bnc.bne.mcp.event.orchestrator.strategy.IndividualTechActionStrategy;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.slf4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
public class IndividualEventHandler implements EventStrategy {
  private static final Logger logger =
      org.slf4j.LoggerFactory.getLogger(IndividualEventHandler.class);

  private final BneService bneService;
  private final EventMapper eventMapper;
  private IndividualMapper individualMapper;

  public IndividualEventHandler(
      BneService bneService, EventMapper eventMapper, IndividualMapper individualMapper) {
    this.bneService = bneService;
    this.eventMapper = eventMapper;
    this.individualMapper = individualMapper;
  }

  @Override
  public Mono<Void> invoke(EventRequest request) {
    EventInformation event = request.getEventInformation();
    String messageId = request.getMessageId();
    PartyKey partyKey = event.getPartyKey();
    String bncId = partyKey.getBncId();
    BusinessObjectEnum businessObject = event.getEventAction().getBusinessObject();
    TechnicalActionEnum techAction = event.getEventAction().getTechnicalAction();
    PartyActionEnum partyAction = event.getPartyAction();
    String targetSys = request.getTargetSystem().toString();

    return buildIndividualRequestMono(invokeMcpServices(bncId, businessObject, targetSys))// get series information associated with individual
        .map(r -> buildBaseRequest(messageId, bncId, businessObject, techAction, partyAction, r))
        .flatMapMany(r -> buildIndividualRequestWithOrganizationInfo(relationshipRequired(r), r, targetSys))
        .flatMap(r -> buildIndividualRequestWithMemberIds(r, partyKey.getMemberIds()))
        .flatMap(
            r ->
                buildIndividualRequestWithMergeInfo(
                    partyKey.getMergeInformation(), r)) // this will only be
        // applicable when it is UNMERGEE (from inbound request)
        .doOnNext(r -> logger.info(r.toString()))
        .flatMap(r -> invokeBneIndividual(r, techAction, targetSys))
        .flatMap(resp -> addGccIdToSystemKeys(messageId, bncId, resp, targetSys))
        .checkpoint()
        .then()
        .log();
  }

  private IndividualRequest buildBaseRequest(
      String messageId,
      String bncId,
      BusinessObjectEnum businessObject,
      TechnicalActionEnum techAction,
      PartyActionEnum partyAction,
      IndividualRequest r) {
    return r.indBncId(bncId)
        .requestId(messageId)
        .eventBusinessObject(EventBusinessObjectEnum.fromValue(businessObject.toString()))
        .eventTechAction(EventTechActionEnum.fromValue(techAction.toString()))
        .eventPtyAction(EventPtyActionEnum.fromValue(partyAction.toString()));
  }

  private List<Mono<IndividualRequest>> invokeMcpServices(
      String bncId, BusinessObjectEnum businessObject, String targetSys) {
    return IndividualBusinessObjectStrategy.valueOf(businessObject.toString())
        .invokeMcpServices(bncId, eventMapper, targetSys);
  }

  Mono<IndividualRequest> buildIndividualRequestMono(List<Mono<IndividualRequest>> monos) {
    return Mono.zip(
            monos,
            dataList ->
                Stream.of(dataList)
                    .map(o -> (IndividualRequest) o)
                    .reduce(
                        new IndividualRequest(), (r, o) -> individualMapper.updateIndividual(r, o)))
        .switchIfEmpty(
            Mono.error(
                () ->
                    new InvalidResponseException(
                        "One or more MCP responses returned empty. Please check.")));
  }

  Flux<IndividualRequest> buildIndividualRequestWithMemberIds(
      IndividualRequest r, List<String> gccIds) {
    if (r.getGeneral() == null) {
      r.setGeneral(new General());
    }
    return buildAndMapFromCollection(gccIds, r, s -> r.general(r.getGeneral().indGccNbr(s)));
  }

  Flux<IndividualRequest> buildIndividualRequestWithOrganizationInfo(
      boolean required, IndividualRequest target, String targetSys) {
    // if there are no relationships, we just let the event fall through
    return !required
        ? Flux.just(target)
        : eventMapper
            .relatedOrganizationIdsFromIndividualFlux(target.getIndBncId(), targetSys)
            .flatMap(
                r ->
                    Mono.just(r)
                        .zipWith(
                            Mono.just(target), (s, t) -> individualMapper.updateIndividual(s, t)));
  }

  boolean relationshipRequired(IndividualRequest request) {
    Map<EventTechActionEnum, List<EventBusinessObjectEnum>> entries =
        Map.ofEntries(
            Map.entry(
                EventTechActionEnum.CREATE,
                List.of(EventBusinessObjectEnum.ROLERLNTP, EventBusinessObjectEnum.BASEIND)),
            Map.entry(EventTechActionEnum.DELETE, List.of(EventBusinessObjectEnum.ROLERLNTP)));

    List<EventBusinessObjectEnum> collect =
        Stream.ofNullable(entries.get(request.getEventTechAction()))
            .flatMap(Collection::stream)
            .filter(e -> request.getEventBusinessObject() == e)
            .collect(Collectors.toList());

    return !CollectionUtils.isEmpty(collect);
  }

  Flux<IndividualRequest> buildIndividualRequestWithMergeInfo(
      List<String> mergerIds, IndividualRequest r) {
    if (r.getGeneral() == null) { // reactor will never pass a null r
      r.setGeneral(new General());
    }
    return buildAndMapFromCollection(
        mergerIds, r, mergerId -> r.general(r.getGeneral().newIndBncId(mergerId)));
  }

  Mono<StandardResponse> addGccIdToSystemKeys(
      String messageId, String bncId, IndividualResponse resp, String targetSys) {
    return Mono.justOrEmpty(resp)
        .flatMap(r -> Mono.justOrEmpty(resp.getMessage()))
        .flatMap(systemId -> eventMapper.addNewGccIdToMcpSystemKeys(bncId, systemId, EventTargetSystem.valueOf(targetSys).srcCd, messageId))
        .switchIfEmpty(
            Mono.fromSupplier(
                () ->
                    new StandardResponse()
                        .returnStatusCode("200")
                        .returnDate(LocalDateTime.now().toString())
                        .returnStatusMessage("No system id returned from service.")));
  }

  Mono<IndividualResponse> invokeBneIndividual(
      IndividualRequest request, TechnicalActionEnum technicalActionEnum, String targetSys) {
    return IndividualTechActionStrategy.valueOf(technicalActionEnum.name())
        .callIndividual(bneService, request, targetSys);
  }

  public BneService getBneService() {
    return bneService;
  }

  public EventMapper getEventMapper() {
    return eventMapper;
  }

  public IndividualMapper getIndividualMapper() {
    return individualMapper;
  }

  public IndividualEventHandler setIndividualMapper(IndividualMapper individualMapper) {
    this.individualMapper = individualMapper;
    return this;
  }
}
