package ca.bnc.bne.mcp.event.orchestrator.exception.model;

public class McpWriteException extends RuntimeException {
  public static final String FAILED_TO_CREATE_INDIVIDUAL_IN_MCP = "Failed to create individual in MCP";
  public static final String FAILED_TO_LINK_INDIVIDUAL_TO_ORGANIZATION_IN_MCP = "Failed to link individual to organization in MCP";
  public static final String FAILED_TO_UNLINK_INDIVIDUAL_TO_ORGANIZATION_IN_MCP = "Failed to unlink individual to organization in MCP";
  public static final String FAILED_TO_UPDATE_INDIVIDUAL_BASE_IN_MCP = "Failed to update individual base in MCP";
  public static final String FAILED_TO_UPDATE_INDIVIDUAL_CONTACT_IN_MCP = "Failed to update individual contact in MCP";
  public static final String FAILED_TO_UPDATE_INDIVIDUAL_ADDRESS_IN_MCP = "Failed to update individual address in MCP";
  public static final String FAILED_TO_UPDATE_INDIVIDUAL_SOCIO_DEMOGRAPHICS_IN_MCP = "Failed to update individual Socio Demographics in MCP";
  public static final String FAILED_TO_DELETE_SYSTEM_KEY_IN_MCP = "Failed to delete system key in MCP";
  public static final String FAILED_TO_LOOKUP_INDIVIDUAL_IN_MCP = "Failed to look up individual using system id in MCP";

    public McpWriteException() {
    super("Error in writing MCP");
  }

  public McpWriteException(Throwable cause) {
    super(cause);
  }

  public McpWriteException(String message) {
    super(message);
  }

  public McpWriteException(String message, Throwable cause) {
    super(message, cause);
  }
}
