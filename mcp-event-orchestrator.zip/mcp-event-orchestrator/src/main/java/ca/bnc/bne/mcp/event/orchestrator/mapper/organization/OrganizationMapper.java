package ca.bnc.bne.mcp.event.orchestrator.mapper.organization;

import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.Address;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.OrganizationInput;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyAddress.Addresses;
import org.mapstruct.AfterMapping;
import org.mapstruct.CollectionMappingStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.ReportingPolicy;

@Mapper(
    componentModel = "spring",
    unmappedTargetPolicy = ReportingPolicy.IGNORE,
    nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
    collectionMappingStrategy = CollectionMappingStrategy.ACCESSOR_ONLY)
public abstract class OrganizationMapper {

  public abstract OrganizationInput updateOrganizationInput(
      OrganizationInput inputRequest, @MappingTarget OrganizationInput targetRequest);

  @Mappings({
    @Mapping(target = "noCivique", source = "addrCivicNo"),
    @Mapping(target = "rue", source = "stName"),
    @Mapping(target = "ville", source = "localityComplete"),
    @Mapping(target = "codePostalZip", source = "postalCdUnformatted"),
    @Mapping(target = "cePays", source = "cntryIso2"),
    @Mapping(target = "ceProvinceEtat", source = "provCntryStd")
  })
  public abstract Address mapOrganizationAddressFromMcp(Addresses mcpAddress);

  @AfterMapping
  void mapProvince(@MappingTarget Address target, Addresses source) {
    String province = source.getProvCntryStd();
    target.setCeProvinceEtat(province.substring(province.length() - 2));
  }
}
