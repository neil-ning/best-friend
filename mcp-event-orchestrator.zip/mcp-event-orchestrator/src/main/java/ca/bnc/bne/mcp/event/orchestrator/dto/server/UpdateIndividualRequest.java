package ca.bnc.bne.mcp.event.orchestrator.dto.server;

import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.UpdateIndividualBaseRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyAddress.UpdatePtyAddressesRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyContact.UpdatePtyContactsWithBNCIDRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.socioDemo.UpdateIndividualSocioDemographicsWithBNCIDRequest;

public class UpdateIndividualRequest {

    private Boolean isBaseIndividualUpdate, isPtyAddressesUpdate, isPtyContactsUpdate, isIndividualSocioUpdate;

    private UpdateIndividualBaseRequest baseIndividual;

    public Boolean getBaseIndividualUpdate() {
        return isBaseIndividualUpdate;
    }

    public void setBaseIndividualUpdate(Boolean baseIndividualUpdate) {
        isBaseIndividualUpdate = baseIndividualUpdate;
    }

    public Boolean getPtyAddressesUpdate() {
        return isPtyAddressesUpdate;
    }

    public void setPtyAddressesUpdate(Boolean ptyAddressesUpdate) {
        isPtyAddressesUpdate = ptyAddressesUpdate;
    }

    public Boolean getPtyContactsUpdate() {
        return isPtyContactsUpdate;
    }

    public void setPtyContactsUpdate(Boolean ptyContactsUpdate) {
        isPtyContactsUpdate = ptyContactsUpdate;
    }

    public Boolean getIndividualSocioUpdate() {
        return isIndividualSocioUpdate;
    }

    public void setIndividualSocioUpdate(Boolean individualSocioUpdate) {
        isIndividualSocioUpdate = individualSocioUpdate;
    }

    private UpdatePtyAddressesRequest ptyAddresses;
    private UpdatePtyContactsWithBNCIDRequest ptyContacts;
    private UpdateIndividualSocioDemographicsWithBNCIDRequest individualSocio;


    public UpdateIndividualBaseRequest getBaseIndividual() {
        return baseIndividual;
    }

    public void setBaseIndividual(UpdateIndividualBaseRequest baseIndividual) {
        this.baseIndividual = baseIndividual;
    }

    public UpdatePtyAddressesRequest getPtyAddresses() {
        return ptyAddresses;
    }

    public void setPtyAddresses(UpdatePtyAddressesRequest ptyAddresses) {
        this.ptyAddresses = ptyAddresses;
    }

    public UpdatePtyContactsWithBNCIDRequest getPtyContacts() {
        return ptyContacts;
    }

    public void setPtyContacts(UpdatePtyContactsWithBNCIDRequest ptyContacts) {
        this.ptyContacts = ptyContacts;
    }

    public UpdateIndividualSocioDemographicsWithBNCIDRequest getIndividualSocio() {
        return individualSocio;
    }

    public void setIndividualSocio(UpdateIndividualSocioDemographicsWithBNCIDRequest individualSocio) {
        this.individualSocio = individualSocio;
    }
}
