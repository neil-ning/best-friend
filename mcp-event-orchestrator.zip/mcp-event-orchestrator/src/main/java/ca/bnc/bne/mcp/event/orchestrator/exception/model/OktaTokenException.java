package ca.bnc.bne.mcp.event.orchestrator.exception.model;

public class OktaTokenException extends RuntimeException {

  public OktaTokenException() {
    super();
  }

  public OktaTokenException(Throwable cause) {
    super(cause);
  }

  public OktaTokenException(String message) {
    super(message);
  }

  public OktaTokenException(String message, Throwable cause) {
    super(message, cause);
  }
}
