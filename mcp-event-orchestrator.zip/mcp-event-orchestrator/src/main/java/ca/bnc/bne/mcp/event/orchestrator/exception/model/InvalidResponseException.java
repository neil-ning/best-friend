package ca.bnc.bne.mcp.event.orchestrator.exception.model;

public class InvalidResponseException extends RuntimeException {

  public InvalidResponseException() {
    super();
  }

  public InvalidResponseException(Throwable cause) {
    super(cause);
  }

  public InvalidResponseException(String message) {
    super(message);
  }

  public InvalidResponseException(String message, Throwable cause) {
    super(message, cause);
  }
}
