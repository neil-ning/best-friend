package ca.bnc.bne.mcp.event.orchestrator.dto.iam;

public class ValidationError {
    private String field;
    private String code;

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Override
    public String toString() {
        return "ValidationError{" + "field='" + field + '\'' + ", code='" + code + '\'' + '}';
    }
}
