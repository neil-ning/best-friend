package ca.bnc.bne.mcp.event.orchestrator.util;

public interface Constants {
    public static final String REST_API_PATH_SERVICE_ORGANIZATION = "/sbie/service/client";
    public static final String REST_API_PATH_SERVICE_USER = "/sbie/service/user";
    public static final String REST_API_PATH_SERVICE_ADMIN = "/sbie/service/admin";

    String SBIE_SRC = "1395";
    String GCC_SRC = "0641";
    String FCC_SRC = "68";

    String TARGET_SYSTEM = "target-system";

    String ORG_ADDR_TYPE = "HEADOFF";
    String ORG_NAME_TYPE = "LGLNAME";

    String EMAIL_TYPE = "EMAIL";
    String FAX_TYPE = "FAX";
    String CELL = "CELL";
    String HOME_PHONE = "PHONE";

    String IBM_CLIENT_ID = "x-ibm-client-id";

    String OKTA_GRANT_KEY = "grant_type";
    String OKTA_SCOPE_KEY = "scope";

    String OKTA_GRANT_VALUE = "client_credentials";
    /*String OKTA_SCOPE_VALUE_MCP =
            "system:mcp:individuals_base:read " +
                    "system:mcp:individuals_base:search " +
                    "system:mcp:individuals_base:create " +
                    "system:mcp:individuals_base:update " +
                    "system:mcp:individuals_labels:read " +
                    "system:mcp:organizations:read " +
                    "system:mcp:organizations:search " +
                    "system:mcp:organizations:create " +
                    "system:mcp:organizations:update " +
                    "system:mcp:organizations_labels:read " +
                    "system:mcp:partyaddresses:read " +
                    "system:mcp:partyaddresses:search " +
                    "system:mcp:partyaddresses:create " +
                    "system:mcp:partyaddresses:update " +
                    "system:mcp:partycontacts:read " +
                    "system:mcp:partycontacts:search " +
                    "system:mcp:partycontacts:create " +
                    "system:mcp:partycontacts:update " +
                    "system:mcp:partyidentifications:read " +
                    "system:mcp:partyidentifications:search " +
                    "system:mcp:partyidentifications:create " +
                    "system:mcp:partyidentifications:update " +
                    "system:mcp:partyrelationships:read " +
                    "system:mcp:partyrelationships:search " +
                    "system:mcp:partyrelationships:update " +
                    "system:mcp:partyrelationships:delete " +
                    "system:mcp:partysystemkeys:create " +
                    "system:mcp:partysystemkeys:delete " +
                    "system:ebx:application_domain_values:read " +
                    "system:ebx:application_domain_values_rules:read " +
                    "system:mcp:individuals_sociodemographics:read " +
                    "system:mcp:individuals_sociodemographics:search " +
                    "system:mcp:organizations_sociodemographics:read " +
                    "system:mcp:organizations_sociodemographics:search ";*/

    String OKTA_SCOPE_VALUE_MCP = "system:mcp:partyaddresses:read system:mcp:partycontacts:read system:mcp:partyaddresses:create system:mcp:partyaddresses:update system:mcp:partycontacts:create system:mcp:partycontacts:update system:mcp:partyidentifications:read system:mcp:individuals_occupations:read system:mcp:individuals_occupations:search system:mcp:individuals_occupations:create system:mcp:individuals_occupations:update system:mcp:individuals_sociodemographics:read system:mcp:partyaddresses:search system:mcp:individuals_base:create system:mcp:individuals_base:read system:mcp:individuals_base:search system:mcp:partycontacts:search system:mcp:partyidentifications:search system:mcp:partyidentifications:create system:mcp:partyidentifications:update system:mcp:individuals_sociodemographics:search system:mcp:individuals_sociodemographics:create system:mcp:individuals_sociodemographics:update system:mcp:individuals_base:update system:melissa:location:read system:mcp:partysystemkeys:create system:mcp:partysystemkeys:delete system:mcp:partysystemkeys:create system:mcp:partysystemkeys:delete system:ebx:application_domain_values:read system:ebx:application_domain_values_rules:read system:mcp:organizations:read system:mcp:organizations:search system:mcp:organizations:create system:mcp:organizations:update system:mcp:organizations_labels:read system:mcp:organizations_labels:update system:mcp:individuals_labels:read system:mcp:individuals_labels:update system:mcp:search_individuals:search system:assistedcommercialaccountopening:caop:create system:assistedcommercialaccountopening:caop:read system:wealth:investmentagreements:read system:mcp:search_employments:search system:mcp:organizations_labels:create system:mcp:individuals_labels:create system:mcp:partyrelationships:search system:mcp:partyrelationships:read system:mcp:partyrelationships:create system:mcp:partyrelationships:update system:mcp:partyrelationships:delete system:isrpb:clientaccountorigination:create system:wealth:investmentportfolios:read system:mcp:search_organizations:search";

    String OKTA_SCOPE_VALUE_IAM =
            "system:iamx:profiles:get " +
                    "system:iamx:profiles:enterprise:create " +
                    "system:iamx:profiles:update " +
                    "system:iamx:credentials:password:update " +
                    "system:iamx:credentials:question:update " +
                    "system:iamx:profiles:enterprise:delete " +
                    "system:iamx:profiles:delete";
}
