package ca.bnc.bne.mcp.event.orchestrator.dto.iam;

import java.util.List;


public class IamxResponse {
  private String timestamp;
  private String code;
  private String message;
  private String sourceApplication;
  private List<ValidationError> validationErrors;

  public IamxResponse setTimestamp(String timestamp) {
    this.timestamp = timestamp;
    return this;
  }

  public IamxResponse setCode(String code) {
    this.code = code;
    return this;
  }

  public IamxResponse setMessage(String message) {
    this.message = message;
    return this;
  }

  public IamxResponse setSourceApplication(String sourceApplication) {
    this.sourceApplication = sourceApplication;
    return this;
  }

  public IamxResponse setValidationErrors(List<ValidationError> validationErrors) {
    this.validationErrors = validationErrors;
    return this;
  }

  public String getTimestamp() {
    return timestamp;
  }

  public String getCode() {
    return code;
  }

  public String getMessage() {
    return message;
  }

  public String getSourceApplication() {
    return sourceApplication;
  }

  public List<ValidationError> getValidationErrors() {
    return validationErrors;
  }

  @Override
  public String toString() {
    return "IamxResponse{" +
        "timestamp='" + timestamp + '\'' +
        ", code='" + code + '\'' +
        ", message='" + message + '\'' +
        ", sourceApplication='" + sourceApplication + '\'' +
        ", validationErrors=" + validationErrors +
        '}';
  }
}
