package ca.bnc.bne.mcp.event.orchestrator.exception.handler;

import ca.bnc.bne.mcp.event.orchestrator.exception.error.Error;
import ca.bnc.bne.mcp.event.orchestrator.exception.error.ValidationError;
import ca.bnc.bne.mcp.event.orchestrator.exception.model.AddSystemKeyException;
import ca.bnc.bne.mcp.event.orchestrator.exception.model.GccBusinessRuleException;
import ca.bnc.bne.mcp.event.orchestrator.exception.model.InvalidResponseException;
import ca.bnc.bne.mcp.event.orchestrator.exception.model.McpBusinessRuleException;
import ca.bnc.bne.mcp.event.orchestrator.exception.model.OktaTokenException;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.bind.support.WebExchangeBindException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

@Order(Ordered.HIGHEST_PRECEDENCE)
@RestControllerAdvice(basePackages = "ca.bnc.bne.mcp.event.orchestrator.controller.event")
public class EventExceptionHandler {

  @ExceptionHandler(WebExchangeBindException.class)
  public ResponseEntity<Object> handleValidationException(WebExchangeBindException ex) {
    return ResponseEntity.status(400)
                         .body(new ValidationError().addValidationErrors(ex.getFieldErrors()));
  }

  @ExceptionHandler(WebClientResponseException.class)
  public ResponseEntity<Object> handleWebClientException(WebClientResponseException ex) {
    return ResponseEntity.status(ex.getStatusCode())
                         .body(new Error().message(ex.getMessage()).debugMessage(ex.getResponseBodyAsString()));
  }

  @ExceptionHandler(InvalidResponseException.class)
  public ResponseEntity<Object> handleInvalidResponseException(InvalidResponseException ex) {
    return ResponseEntity.status(424)
                         .body(new Error().message(ex.getMessage()));
  }

  @ExceptionHandler(McpBusinessRuleException.class)
  public ResponseEntity<Object> handleMcpBusinessRuleException(McpBusinessRuleException ex) {
    return ResponseEntity.status(424)
                         .body(new Error().message(ex.getMessage()));
  }

  @ExceptionHandler(GccBusinessRuleException.class)
  public ResponseEntity<Object> handleGccBusinessRuleException(GccBusinessRuleException ex) {
    return ResponseEntity.status(424)
                         .body(new Error().message(ex.getMessage()));
  }

  @ExceptionHandler(AddSystemKeyException.class)
  public ResponseEntity<Object> handleSystemKeyException(AddSystemKeyException ex) {
    return ResponseEntity.status(424)
                         .body(new Error().message(ex.getMessage()));
  }

  @ExceptionHandler(OktaTokenException.class)
  public ResponseEntity<Object> handleOktaTokenException(OktaTokenException ex) {
    return ResponseEntity.status(401)
                         .body(new Error().message(ex.getMessage()));
  }

  @ExceptionHandler(Exception.class)
  public ResponseEntity<Object> handleUnexpectedException(Exception ex) {
    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                         .body(new Error().message(ex.getMessage()));
  }
}
