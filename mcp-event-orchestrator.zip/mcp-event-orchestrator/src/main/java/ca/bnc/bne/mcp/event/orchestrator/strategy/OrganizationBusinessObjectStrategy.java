package ca.bnc.bne.mcp.event.orchestrator.strategy;

import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.OrganizationInput;
import ca.bnc.bne.mcp.event.orchestrator.mapper.EventMapper;
import java.util.List;
import reactor.core.publisher.Mono;

public enum OrganizationBusinessObjectStrategy {
  BASEORG {
    public List<Mono<OrganizationInput>> invokeMcpServices(String bncId, EventMapper eventMapper, String targetSys) {
      return List.of(
          eventMapper.baseOrganizationMono(bncId, targetSys),
          eventMapper.organizationAddressMono(bncId, targetSys),
          eventMapper.organizationContactMono(bncId, targetSys));
    }
  },
  PTYADDR {
    public List<Mono<OrganizationInput>> invokeMcpServices(String bncId, EventMapper eventMapper, String targetSys) {
      return List.of(eventMapper.organizationAddressMono(bncId, targetSys));
    }
  },
  PTYCTCMETH {
    public List<Mono<OrganizationInput>> invokeMcpServices(String bncId, EventMapper eventMapper, String targetSys) {
      return List.of(eventMapper.organizationContactMono(bncId, targetSys));
    }
  },
  SYSTEMKEY {
    public List<Mono<OrganizationInput>> invokeMcpServices(String bncId, EventMapper eventMapper, String targetSys) {
      return List.of(Mono.just(new OrganizationInput()));
    }
  };

  public abstract List<Mono<OrganizationInput>> invokeMcpServices(
      String bncId, EventMapper eventMapper, String targetSys);
}
