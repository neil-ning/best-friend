package ca.bnc.bne.mcp.event.orchestrator.exception.model;

public class McpBusinessRuleException extends RuntimeException {

  public McpBusinessRuleException() {
    super("No party found for provided BNCID");
  }

  public McpBusinessRuleException(Throwable cause) {
    super(cause);
  }

  public McpBusinessRuleException(String message) {
    super(message);
  }

  public McpBusinessRuleException(String message, Throwable cause) {
    super(message, cause);
  }
}
