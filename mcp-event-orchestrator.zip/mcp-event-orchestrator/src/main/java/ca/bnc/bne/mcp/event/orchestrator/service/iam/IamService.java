package ca.bnc.bne.mcp.event.orchestrator.service.iam;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.client.WebClient;

import ca.bnc.bne.mcp.event.orchestrator.dto.iam.AccessProfile;
import ca.bnc.bne.mcp.event.orchestrator.dto.iam.Factor;
import ca.bnc.bne.mcp.event.orchestrator.dto.iam.IamxProfile;
import ca.bnc.bne.mcp.event.orchestrator.dto.iam.IamxResponse;
import ca.bnc.bne.mcp.event.orchestrator.exception.model.IamWriteException;
import reactor.core.publisher.Mono;

@Service
public class IamService {
  @Value("${iam.endpoint.create-profile}")
  private String uriCreateProfile;
  @Value("${iam.endpoint.delete-profile}")
  private String uriDeleteProfile;
  @Value("${iam.endpoint.update-phone}")
  private String uriUpdatePhone;
  @Value("${iam.endpoint.update-email}")
  private String uriUpdateEmail;
  @Value("${iam.endpoint.update-voice")
  private String uriUpdateVoice;

  private static final Logger logger = org.slf4j.LoggerFactory.getLogger(IamService.class);

  private final WebClient webClient;

  public IamService(WebClient.Builder builder, @Value("${iam.base-url}") String baseUrl) {
    webClient = builder.baseUrl(baseUrl).defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
        .build();
  }

  public Mono<IamxResponse> createProfile(String username, String password, String referenceSystem, String referenceId,
      String oktaToken) {
    final IamxProfile iamxProfile = new IamxProfile(username, password, referenceSystem, referenceId);
    return webClient
            .post()
            .uri(uriCreateProfile)
            .bodyValue(iamxProfile)
            .headers(httpHeaders -> httpHeaders.setBearerAuth(oktaToken))
            .retrieve()
              .onStatus(HttpStatus::isError, clientResponse -> Mono.error(new IamWriteException(IamWriteException.FAILED_TO_CREATE_PROFILE_IN_IAM)))
            .bodyToMono(IamxResponse.class)
              .doOnSuccess(ok -> logger.info("okta profile created in IAM for username={}", username))
              .doOnError(err -> logger.error("okta profile creation failed in IAM", err));
  }

  public Mono<IamxResponse> deleteProfile(String username) {
    return webClient
            .delete()
            .uri(uriDeleteProfile, username)
            .retrieve()
              .onStatus(HttpStatus::isError, clientResponse -> Mono.error(new IamWriteException(IamWriteException.FAILED_TO_DELETE_PROFILE_IN_IAM)))
            .bodyToMono(IamxResponse.class)
              .doOnSuccess(ok -> logger.info("okta profile deleted in IAM for username={}", username))
              .doOnError(err -> logger.error("okta profile delete failed in IAM", err));
  }

  public Mono<IamxResponse> updateMfaPreference(String username, String phone, String email, String voice,
      String extension) {
    Mono<IamxResponse> mfaPhone = StringUtils.isEmpty(phone) ? deleteMfaPhone(username)
        : updateMfaPhone(username, phone);
    Mono<IamxResponse> mfaVoice = StringUtils.isEmpty(voice) ? deleteMfaVoice(username)
        : updateMfaVoice(username, voice, extension);

    return mfaPhone.then(updateMfaEmail(username, email)).then(mfaVoice);           
  }

  private Mono<IamxResponse> updateMfaEmail(String username, String email) {
    final IamxProfile iamxProfile = new IamxProfile().setAccessProfile(new AccessProfile(email));
    return webClient
            .put()
            .uri(uriUpdateEmail, username).bodyValue(iamxProfile)
            .retrieve()
              .onStatus(HttpStatus::isError, clientResponse -> Mono.error(new IamWriteException(IamWriteException.FAILED_TO_UPDATE_EMAIL_IN_IAM)))
            .bodyToMono(IamxResponse.class)
              .doOnSuccess(ok -> logger.info("okta MFA email updated in IAM for username={}", username))
              .doOnError(err -> logger.error("okta MFA email update failed in IAM", err));
  }

  private Mono<IamxResponse> updateMfaPhone(String username, String phone) {
    final IamxProfile iamxProfile = new IamxProfile().setFactor(new Factor(phone));
    return webClient
            .put()
            .uri(uriUpdatePhone, username)
            .bodyValue(iamxProfile)
            .retrieve()
              .onStatus(HttpStatus::isError, clientResponse -> Mono.error(new IamWriteException(IamWriteException.FAILED_TO_UPDATE_PHONE_IN_IAM)))
            .bodyToMono(IamxResponse.class)
              .doOnSuccess(ok -> logger.info("okta MFA phone updated in IAM for username={}", username))
              .doOnError(err -> logger.error("okta MFA phone update failed in IAM", err));
  }

  private Mono<IamxResponse> deleteMfaPhone(String username) {
    return webClient
            .delete()
            .uri(uriUpdatePhone, username)
            .retrieve()
              .onStatus(HttpStatus::isError, clientResponse -> Mono.error(new IamWriteException(IamWriteException.FAILED_TO_DELETE_PHONE_IN_IAM)))
            .bodyToMono(IamxResponse.class)
              .doOnSuccess(ok -> logger.info("okta MFA phone deleted in IAM for username={}", username))
              .doOnError(err -> logger.error("okta MFA phone delete failed in IAM", err));
  }

  private Mono<IamxResponse> updateMfaVoice(String username, String voice, String extension) {
    final var iamxProfile = new IamxProfile().setFactor(new Factor(voice, extension));
    return webClient
            .put()
            .uri(uriUpdateVoice, username)
            .bodyValue(iamxProfile)
            .retrieve()
              .onStatus(HttpStatus::isError, clientResponse -> Mono.error(new IamWriteException(IamWriteException.FAILED_TO_UPDATE_VOICE_IN_IAM)))
            .bodyToMono(IamxResponse.class)
              .doOnSuccess(ok -> logger.debug("okta MFA voice updated in IAM for username={}", username))
              .doOnError(err -> logger.error("okta MFA voice update in IAM failed", err));
  }

  private Mono<IamxResponse> deleteMfaVoice(String username) {
    return webClient
            .delete()
            .uri(uriUpdateVoice, username)
            .retrieve()
              .onStatus(HttpStatus::isError, clientResponse -> Mono.error(new IamWriteException(IamWriteException.FAILED_TO_DELETE_VOICE_IN_IAM)))
            .bodyToMono(IamxResponse.class)
              .doOnSuccess(ok -> logger.debug("okta Mfa voice deleted for username={}", username))
              .doOnError(err -> logger.error("okta MFA voice delete failed", err));
  }
}
