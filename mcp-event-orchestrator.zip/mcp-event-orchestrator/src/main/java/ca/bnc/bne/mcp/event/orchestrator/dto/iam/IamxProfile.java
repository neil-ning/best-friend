package ca.bnc.bne.mcp.event.orchestrator.dto.iam;


public class IamxProfile {

  private AccessProfile accessProfile;
  private Credentials credentials;
  private Factor factor;

  public IamxProfile() {}

  public IamxProfile(String login, String password, String bngfReferenceSystem, String bngfReferenceId) {
    this.accessProfile = new AccessProfile(login, bngfReferenceSystem, bngfReferenceId);
    this.credentials = new Credentials(password);
  }

  public AccessProfile getAccessProfile() {
    return accessProfile;
  }

  public IamxProfile setAccessProfile(AccessProfile accessProfile) {
    this.accessProfile = accessProfile;
    return this;
  }

  public Credentials getCredentials() {
    return credentials;
  }

  public IamxProfile setCredentials(Credentials credentials) {
    this.credentials = credentials;
    return this;
  }

  public Factor getFactor() {
    return factor;
  }

  public IamxProfile setFactor(Factor factor) {
    this.factor = factor;
    return this;
  }

  @Override
  public String toString() {
    return "IamxProfile{" +
        "accessProfile=" + accessProfile +
        ", factor=" + factor +
        '}';
  }
}
