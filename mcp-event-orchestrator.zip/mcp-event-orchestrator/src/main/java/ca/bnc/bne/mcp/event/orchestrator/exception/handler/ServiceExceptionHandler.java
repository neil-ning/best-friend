package ca.bnc.bne.mcp.event.orchestrator.exception.handler;

import ca.bnc.bne.mcp.event.orchestrator.exception.error.Error;
import ca.bnc.bne.mcp.event.orchestrator.exception.model.IamWriteException;
import ca.bnc.bne.mcp.event.orchestrator.exception.model.McpWriteException;
import ca.bnc.bne.mcp.event.orchestrator.exception.model.OktaTokenException;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * For service controller
 * > Return 400 for bad request
 * > Return 424 for back end service interaction errors MCP/IAM/OCTA
 * > Return 500 for all other unknown errors
 *
 * Refer to swagger files for the contract
 */
@Order(Ordered.HIGHEST_PRECEDENCE)
@RestControllerAdvice(basePackages = "ca.bnc.bne.mcp.event.orchestrator.controller.service")
public class ServiceExceptionHandler {
  //TODO: add exception handling for request validation with 400 status code

  @ExceptionHandler(McpWriteException.class)
  public ResponseEntity<Object> handleInvalidResponseException(McpWriteException ex) {
    return ResponseEntity.status(424)
                         .body(new Error().message(ex.getMessage()));
  }

  @ExceptionHandler(IamWriteException.class)
  public ResponseEntity<Object> handleMcpBusinessRuleException(IamWriteException ex) {
    return ResponseEntity.status(424)
                         .body(new Error().message(ex.getMessage()));
  }

  @ExceptionHandler(OktaTokenException.class)
  public ResponseEntity<Object> handleOktaTokenException(OktaTokenException ex) {
    return ResponseEntity.status(424)
                         .body(new Error().message(ex.getMessage()));
  }

  @ExceptionHandler(Exception.class)
  public ResponseEntity<Object> handleUnexpectedException(Exception ex) {
    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                         .body(new Error().message(ex.getMessage()));
  }
}
