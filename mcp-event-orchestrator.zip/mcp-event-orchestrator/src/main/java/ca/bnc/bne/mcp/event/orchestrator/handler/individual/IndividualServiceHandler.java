package ca.bnc.bne.mcp.event.orchestrator.handler.individual;

import ca.bnc.bne.mcp.event.orchestrator.dto.server.UpdateIndividualRequest;
import ca.bnc.bne.mcp.event.orchestrator.exception.model.McpWriteException;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.AddIndividualResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.CreateIndividualRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.CreateIndividualResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.GetIndividualBaseResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.PartyMember;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyRelationship.PostRelationship;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyRelationship.Relationship;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyRelationship.RelationshipProperty;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyRelationship.RemovedRelationship;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.socioDemo.SocioDemographicKeyRessource;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.socioDemo.SocioDemographicKeyRessourceWithBNCID;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.socioDemo.UpdateIndividualSocioDemographicsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.socioDemo.UpdateIndividualSocioDemographicsWithBNCIDRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.AddPartySysKeyRequestBncId;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.AddPartySysKeysBncId;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.AddPtyMember;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.PartyIdentification;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.PtyIdBncId;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.RemovePartySysKeyRequestBncId;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.RemovePartySysKeysBncId;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.RemovePtyMember;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.StandardResponse;
import ca.bnc.bne.mcp.event.orchestrator.service.iam.IamService;
import ca.bnc.bne.mcp.event.orchestrator.service.mcp.McpService;
import ca.bnc.bne.mcp.event.orchestrator.service.okta.OktaService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Hooks;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.util.Arrays;
import java.util.function.Function;

import static ca.bnc.bne.mcp.event.orchestrator.exception.model.McpWriteException.FAILED_TO_CREATE_INDIVIDUAL_IN_MCP;
import static ca.bnc.bne.mcp.event.orchestrator.exception.model.McpWriteException.FAILED_TO_UNLINK_INDIVIDUAL_TO_ORGANIZATION_IN_MCP;

@Component
public class IndividualServiceHandler {

    private static final Logger logger = LoggerFactory.getLogger(IndividualServiceHandler.class);

    private final McpService mcpService;
    private final IamService iamService;
    private final OktaService oktaService;

    public IndividualServiceHandler(
            McpService mcpService, IamService iamService, OktaService oktaService) {
        this.mcpService = mcpService;
        this.iamService = iamService;
        this.oktaService = oktaService;
    }

    /**
     * create an individual in MCP
     *
     * @param createIndividualRequest
     * @param orgBncId
     * @param requestId
     * @return
     */
    public Mono<AddIndividualResponse> createIndividual(
            final CreateIndividualRequest createIndividualRequest
            , final String orgBncId, final String accessToken, final String requestId) {

        logger.info("processing create individual");
        PartyMember member = createIndividualRequest.getIndividual().getPartyMember().get(0);
        String memberId = member.getMemberIdNo();
        String srccd = member.getSrcCd();

        //1. create individual in MCP
        // TODO: not make sure getting BNCID from list of partyidentification is correct
        return mcpService.createIndividual(srccd, createIndividualRequest, accessToken)
                .map(extractPartyIdentification())
                .flatMap(addIndividualNewSysId(memberId, srccd, accessToken, requestId))
                .flatMap(linkIndividualAndOrg(orgBncId, accessToken))
                .onErrorMap(e -> new McpWriteException(FAILED_TO_CREATE_INDIVIDUAL_IN_MCP, e));

    }

    private Function<ca.bnc.bne.mcp.event.orchestrator
            .gen.model.mcp.individual.PartyIdentification, Mono<? extends AddIndividualResponse>>
    linkIndividualAndOrg(String orgBncId, String accessToken) {
        return partyIdentification -> {
            logger.info("processing build relationship between organization and individual");
            // 3. build relationship between an organization and a new individual
            // TODO: while building relationship between organization and individual, needs to know how to set PartyRelationType,
            //       InitiatingPartyRole,oppositePartyRole,initiatingBncId,oppositeBncId
            // TODO: build relationship between individual and organization,
            //      the response lacks relationshipid, despite it is described in swagger file.

            PostRelationship postRelationship = new PostRelationship()
                    .initiatingBncId(orgBncId)
                    .initiatingPartyRole(PostRelationship.InitiatingPartyRoleEnum.AUTHRZDREP)//To Be Determined"
                    .oppositeBncId(partyIdentification.getPtyIdentItemNo())
                    .oppositePartyRole(PostRelationship.OppositePartyRoleEnum.ACCOUNTANT) //To Be Determined"
                    .relationshipProperties(Arrays.asList(new RelationshipProperty())); //To Be Determined"

            // TODO: if sbie can keep individual bncid and relationshipId
            // get relationship id from iam
            return mcpService.linkIndividualToOrganizationExchange(postRelationship, accessToken).map(
                    relationshipId -> new AddIndividualResponse()
                            .partyIdentification(partyIdentification).relationshipId(relationshipId)
            );
        };
    }

    private Function<ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.PartyIdentification,
            Mono<? extends ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.PartyIdentification>>
    addIndividualNewSysId(String individualSysId, String srcCd, String accessToken, String requestId) {
        return partyIdentification -> {
            logger.info("processing add a new system key to party member list");
            // 2. add a new system key to party member list
            String bncId = partyIdentification.getPtyIdentItemNo();

            return addNewSysIdToMcpSystemKeys(bncId, individualSysId, srcCd, accessToken, requestId)
                    .thenReturn(partyIdentification);

        };
    }

    private Function<CreateIndividualResponse, ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.PartyIdentification> extractPartyIdentification() {
        return createIndividualResponse -> createIndividualResponse.getIndividual().getPartyIdentification().get(0);
    }

    private AddPartySysKeyRequestBncId buildAddPartySysKeyRequestBncId(String individualSysId, String srcCd, String requestId, String bncId) {
        return new AddPartySysKeyRequestBncId()
                .addPartySysKeys(
                        new AddPartySysKeysBncId()
                                .requestID(requestId)
                                .addPtyMember(new AddPtyMember().memberIdNo(individualSysId).srcCd(srcCd))
                                .ptyId(new PtyIdBncId()
                                        .partyIdentification(
                                                new PartyIdentification()
                                                        .ptyIdentItemNo(bncId)
                                                        .ptyIdentItemTypeCd("BNCID"))));
    }

    public Mono<StandardResponse> addNewSysIdToMcpSystemKeys(
            String bncId, String sysId, String srcCd, String oktaToken, String requestId) {
        AddPartySysKeyRequestBncId request = buildAddPartySysKeyRequestBncId(sysId, srcCd, requestId, bncId);
        return mcpService.postSystemKeysByBncId(request, oktaToken, bncId);
    }

    /**
     * update individual associated with information
     *
     * @param userBncId
     * @param updateIndividualRequest
     * @param accessToken
     * @param requestId
     * @return
     */
    public Mono<Void> updateIndividual(String userBncId,
                                       UpdateIndividualRequest updateIndividualRequest,
                                       String accessToken, String requestId) {

        logger.info("processing update individual information.");

        //Hooks.onOperatorDebug();
        Flux flux = Flux.empty();

        if (updateIndividualRequest.getBaseIndividualUpdate()) {
            logger.info("doing update individual base information.");
            flux = flux.mergeWith(mcpService.updateIndividualBaseByBncId(userBncId,
                    updateIndividualRequest.getBaseIndividual(), accessToken));
        }

        if (updateIndividualRequest.getPtyAddressesUpdate()) {
            logger.info("doing update individual Address.");
            flux = flux.mergeWith(mcpService.updateIndividualAddress(userBncId,
                    updateIndividualRequest.getPtyAddresses(), accessToken));
        }

        if (updateIndividualRequest.getPtyContactsUpdate()) {
            logger.info("doing update individual Contact.");
            flux = flux.mergeWith(mcpService.updateIndividualContact(userBncId,
                    updateIndividualRequest.getPtyContacts(), accessToken));
        }

        if (updateIndividualRequest.getIndividualSocioUpdate()) {
            logger.info("doing update individual Socio.");
            flux = flux.mergeWith(updateSocio(updateIndividualRequest.getIndividualSocio(),
                    userBncId, accessToken));
        }

        return flux.parallel().log().runOn(Schedulers.parallel())
                .sequential().log().
                        onErrorMap(err -> new McpWriteException("Faild to update individual info with exception:"
                , (Throwable) err)).then();

        //return flux.log().single();
    }

    private Mono<UpdateIndividualSocioDemographicsResponse> updateSocio(
            UpdateIndividualSocioDemographicsWithBNCIDRequest socioRequest, String indivBncId, String accessToken) {

        return mcpService.getSocioDemoMono(indivBncId, accessToken)
                .flatMap(socioDemographicsResponse -> {

                    SocioDemographicKeyRessource respKeyRessource = socioDemographicsResponse.getSocioDemographic();
                    SocioDemographicKeyRessourceWithBNCID reqKeyRessource = socioRequest.getSocioDemographic();

                    if (reqKeyRessource.getGenderCd() == null) {
                        reqKeyRessource.setGenderCd(respKeyRessource.getGenderCd());
                    }

                    if (reqKeyRessource.getIndvMaritalStatusTypeCd() == null) {
                        reqKeyRessource.setIndvMaritalStatusTypeCd(respKeyRessource.getIndvMaritalStatusTypeCd());
                    }

                    if (reqKeyRessource.getIndvUpdDt() == null) {
                        reqKeyRessource.setIndvUpdDt(respKeyRessource.getIndvUpdDt());
                    }

                    if (reqKeyRessource.getNbOfDependents() == null) {
                        reqKeyRessource.setNbOfDependents(respKeyRessource.getNbOfDependents());
                    }

                    if (reqKeyRessource.getPtyUID() == null) {
                        reqKeyRessource.setPtyUID(respKeyRessource.getPtyUID());
                    }

                    if (reqKeyRessource.getPtyUpdDt() == null) {
                        reqKeyRessource.setPtyUpdDt(respKeyRessource.getPtyUpdDt());
                    }

                    return mcpService.updateIndividualSocio(indivBncId, socioRequest, accessToken);
                });
    }

    /**
     * delete individual from mcp
     *
     * @param userBncId
     * @param userSysId
     * @param srcCd
     * @param relationshipId
     * @param requestId
     * @return
     */
    public Mono<Void> deleteIndividual(String userBncId, String userSysId, String srcCd, String relationshipId, String accessToken, String requestId) {

        logger.info("processing delete individual information from MCP.");

        logger.info("retrieve individual info from mcp according to individualSysId and srcCd.");
        // 1.retrieve individual info from mcp according to individualSysId and srcCd
                    /*return mcpService.getIndividual(userSysId, srcCd, accessToken)
                            .map(getIndividualBncId())
                            .flatMap(getPartyRelationship(userSysId, accessToken))
                            .flatMap(unlinkIndividualToOrg(relationshipId, accessToken))
                            .flatMap(removeIndividualSysKey(userSysId, srcCd, requestId, accessToken));*/
        // TODO: delete individual?
        return removeIndividualSysKeyNew(userBncId, userSysId, srcCd, accessToken, requestId)
                .flatMap(standardResponse -> unlinkIndividualToOrgNew(relationshipId, accessToken))
                .onErrorMap(e -> {
                    logger.error("delete individual occurred exception:", e);
                    return new McpWriteException("failed to delete individual to organization in mcp", e);
                });
    }

    private Function<Relationship, Mono<? extends StandardResponse>>
    removeIndividualSysKey(String userSysId, String srcCd, String requestId, String accessToken) {
        return relationship -> {
            logger.info("delete individual system key from mcp.");
            // 4.delete individual system key from mcp

            // TODO: not assure bncId is correct
            String indvBncId = relationship.getOppositeBncId();

            PtyIdBncId ptyIdBncId = new PtyIdBncId().partyIdentification(new PartyIdentification()
                    .ptyIdentItemNo(indvBncId).ptyIdentItemTypeCd("BNCID"));

            RemovePtyMember removePtyMember = new RemovePtyMember();
            removePtyMember.setMemberIdNo(userSysId);
            removePtyMember.setSrcCd(srcCd);

            RemovePartySysKeysBncId removePartySysKeysBncId = new RemovePartySysKeysBncId();
            removePartySysKeysBncId.setRequestID(requestId);
            removePartySysKeysBncId.setPtyId(ptyIdBncId);
            removePartySysKeysBncId.setRemovePtyMember(removePtyMember);

            RemovePartySysKeyRequestBncId requestBncId = new RemovePartySysKeyRequestBncId();
            requestBncId.setRemovePartySysKeys(removePartySysKeysBncId);

            return mcpService.deleteSystemKeysByBncId(indvBncId, requestBncId, accessToken);
        };
    }

    private Mono<StandardResponse>
    removeIndividualSysKeyNew(String userBncId, String userSysId, String srcCd, String accessToken, String requestId) {
        logger.info("delete individual system key from mcp.");
        // 4.delete individual system key from mcp

        PtyIdBncId ptyIdBncId = new PtyIdBncId().partyIdentification(new PartyIdentification()
                .ptyIdentItemNo(userBncId).ptyIdentItemTypeCd("BNCID"));

        RemovePtyMember removePtyMember = new RemovePtyMember();
        removePtyMember.setMemberIdNo(userSysId);
        removePtyMember.setSrcCd(srcCd);

        RemovePartySysKeysBncId removePartySysKeysBncId = new RemovePartySysKeysBncId();
        removePartySysKeysBncId.setRequestID(requestId);
        removePartySysKeysBncId.setPtyId(ptyIdBncId);
        removePartySysKeysBncId.setRemovePtyMember(removePtyMember);

        RemovePartySysKeyRequestBncId requestBncId = new RemovePartySysKeyRequestBncId();
        requestBncId.setRemovePartySysKeys(removePartySysKeysBncId);

        return mcpService.deleteSystemKeysByBncId(userBncId, requestBncId, accessToken);
    }

    private Function<Relationship, Mono<? extends Relationship>> unlinkIndividualToOrg(String relationshipId, String accessToken) {
        return relationship -> {
            logger.info("unlink relationship between organization and individual.");
            // 3.unlink relationship between organization and individual
            // TODO: delete individual relationship from organization
            //  , need to know a proper way to find relationshipId
            RemovedRelationship removedRelationship = new RemovedRelationship();
            // TODO: lack relationship ID
            return mcpService.unlinkIndividualToOrganization(relationshipId, removedRelationship, accessToken)
                    .thenReturn(relationship);
        };
    }

    private Mono<Void> unlinkIndividualToOrgNew(String relationshipId, String accessToken) {
        logger.info("unlink relationship between organization and individual.");
        // 3.unlink relationship between organization and individual
        RemovedRelationship removedRelationship = new RemovedRelationship();
        return mcpService.unlinkIndividualToOrganization(relationshipId, removedRelationship, accessToken);
    }

    private Function<String, Mono<? extends Relationship>> getPartyRelationship(String orgBncId, String accessToken) {
        return individualBncId -> {
            logger.info("retrieving individual relationships.");
            // 2.retrieve individual relationships
            //TODO:  need to know a proper way to find relationshipId and partyFilter values
            return mcpService.getPtyRelationshipMono(individualBncId, "", accessToken)
                    .map(relationships -> relationships.getRelationships()
                            .stream()
                            .filter(relationship -> individualBncId.equals(relationship.getOppositeBncId())
                                    && orgBncId.equals(relationship.getInitiatingBncId())
                            ).findFirst().get());
        };
    }

    private Function<GetIndividualBaseResponse, String> getIndividualBncId() {
        return individualBaseResponse ->
                individualBaseResponse.getIndividual()
                        .getPartyIdentification().stream()
                        .filter(partyIdentification -> StringUtils.equals(partyIdentification.getPtyIdentStatusCd(), "ACTIVE"))
                        .findFirst().get().getPtyIdentItemNo();
    }
}
