package ca.bnc.bne.mcp.event.orchestrator.dto.iam;


public class AccessProfile {
  private String login;
  private String bngfIdentitySource;
  private String bngfReferenceId;
  private String newEmail;

  public AccessProfile() {}

  public AccessProfile(String login, String bngfIdentitySource, String bngfReferenceId) {
    this.login = login;
    this.bngfIdentitySource = bngfIdentitySource;
    this.bngfReferenceId = bngfReferenceId;
  }

  public AccessProfile(String newEmail) {
    this.newEmail = newEmail;
  }

  public String getNewEmail() {
    return newEmail;
  }

  public void setNewEmail(String newEmail) {
    this.newEmail = newEmail;
  }

  public String getLogin() {
    return login;
  }

  public void setLogin(String login) {
    this.login = login;
  }

  public String getBngfIdentitySource() {
    return bngfIdentitySource;
  }

  public void setBngfIdentitySource(String bngfIdentitySource) {
    this.bngfIdentitySource = bngfIdentitySource;
  }

  public String getBngfReferenceId() {
    return bngfReferenceId;
  }

  public void setBngfReferenceId(String bngfReferenceId) {
    this.bngfReferenceId = bngfReferenceId;
  }

  @Override
  public String toString() {
    return "AccessProfile{" +
        "login='" + login + '\'' +
        ", bngfIdentitySource='" + bngfIdentitySource + '\'' +
        ", bngfReferenceId='" + bngfReferenceId + '\'' +
        ", newEmail='" + newEmail + '\'' +
        '}';
  }
}
