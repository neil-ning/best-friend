package ca.bnc.bne.mcp.event.orchestrator.handler.organization;

import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.*;
import ca.bnc.bne.mcp.event.orchestrator.service.mcp.McpService;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
public class OrganizationServiceHandler {
    private final McpService mcpService;

    public OrganizationServiceHandler(
            McpService mcpService) {
        this.mcpService = mcpService;
    }

    public Mono<StandardResponse> addNewSysIdToMcpSystemKeys(
            String bncId, String sysId, String srcCd, String requestId, String token) {
        AddPartySysKeyRequestBncId request =
                new AddPartySysKeyRequestBncId()
                        .addPartySysKeys(
                                new AddPartySysKeysBncId()
                                        .requestID(requestId)
                                        .addPtyMember(new AddPtyMember().memberIdNo(sysId).srcCd(srcCd))
                                        .ptyId(
                                                new PtyIdBncId()
                                                        .partyIdentification(
                                                                new PartyIdentification()
                                                                        .ptyIdentItemNo(bncId)
                                                                        .ptyIdentItemTypeCd("BNCID"))));

        return mcpService.postSystemKeysByBncId(request, token, bncId);
    }
}
