package ca.bnc.bne.mcp.event.orchestrator.mapper.individual;

import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.IndividualRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.Profile;
import org.mapstruct.CollectionMappingStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.ReportingPolicy;

@Mapper(
    componentModel = "spring",
    unmappedTargetPolicy = ReportingPolicy.IGNORE,
    nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
    collectionMappingStrategy = CollectionMappingStrategy.ACCESSOR_ONLY)
public interface IndividualMapper {

  void updateIndividualProfile(Profile inputProfile, @MappingTarget Profile targetProfile);

  IndividualRequest updateIndividual(
      IndividualRequest inputRequest, @MappingTarget IndividualRequest targetRequest);
}
