package ca.bnc.bne.mcp.event.orchestrator.util;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class JsonFileUtil {
    public static String readString(String file) throws IOException, URISyntaxException {
        return Files.readString(Paths.get(JsonFileUtil.class.getClassLoader().getResource(file).toURI()));
    }

    public static <T> T readObject(String file, Class<T> requestType) throws IOException {
        ObjectMapper objectMapper =
                new ObjectMapper()
                        .setSerializationInclusion(JsonInclude.Include.NON_EMPTY)
                        .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, true)
                        .configure(JsonParser.Feature.ALLOW_COMMENTS, true)
                        .configure(MapperFeature.USE_STD_BEAN_NAMING, true)
                        .configure(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true)
                        .configure(SerializationFeature.WRAP_ROOT_VALUE, false)
                        .configure(DeserializationFeature.UNWRAP_ROOT_VALUE, false)
                        .configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, false)
                        .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
                        .findAndRegisterModules();
        return objectMapper.readValue(new String(JsonFileUtil.class.getClassLoader().getResourceAsStream(file).readAllBytes()), requestType);
    }

    public static String writeString(Object object) throws JsonProcessingException {
        ObjectMapper objectMapper =
                new ObjectMapper()
                        .setSerializationInclusion(JsonInclude.Include.NON_EMPTY)
                        .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, true)
                        .configure(JsonParser.Feature.ALLOW_COMMENTS, true)
                        .configure(MapperFeature.USE_STD_BEAN_NAMING, true)
                        .configure(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true)
                        .configure(SerializationFeature.WRAP_ROOT_VALUE, false)
                        .configure(DeserializationFeature.UNWRAP_ROOT_VALUE, false)
                        .configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, false)
                        .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
                        .findAndRegisterModules();
        return objectMapper.writeValueAsString(object);
    }
}
