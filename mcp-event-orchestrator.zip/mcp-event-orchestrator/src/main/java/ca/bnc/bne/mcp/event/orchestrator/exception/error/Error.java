package ca.bnc.bne.mcp.event.orchestrator.exception.error;

import java.time.LocalDateTime;

public class Error {

  private LocalDateTime timestamp;
  private String message;
  private String debugMessage;

  public Error() {
    this.timestamp = LocalDateTime.now();
  }

  public Error debugMessage(String message) {
    this.debugMessage = message;
    return this;
  }

  public Error message(String message) {
    this.message = message;
    return this;
  }

  public LocalDateTime getTimestamp() {
    return timestamp;
  }

  public Error setTimestamp(LocalDateTime timestamp) {
    this.timestamp = timestamp;
    return this;
  }

  public String getMessage() {
    return message;
  }

  public Error setMessage(String message) {
    this.message = message;
    return this;
  }

  public String getDebugMessage() {
    return debugMessage;
  }

  public Error setDebugMessage(String debugMessage) {
    this.debugMessage = debugMessage;
    return this;
  }
}
