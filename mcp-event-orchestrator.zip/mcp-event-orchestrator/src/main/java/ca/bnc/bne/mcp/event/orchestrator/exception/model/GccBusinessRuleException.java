package ca.bnc.bne.mcp.event.orchestrator.exception.model;

public class GccBusinessRuleException extends RuntimeException {

  public GccBusinessRuleException() {
    super("No party found for provided BNCID");
  }

  public GccBusinessRuleException(Throwable cause) {
    super(cause);
  }

  public GccBusinessRuleException(String message) {
    super(message);
  }

  public GccBusinessRuleException(String message, Throwable cause) {
    super(message, cause);
  }
}
