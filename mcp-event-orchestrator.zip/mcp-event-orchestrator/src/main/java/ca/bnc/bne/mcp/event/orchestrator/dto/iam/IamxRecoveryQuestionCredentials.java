package ca.bnc.bne.mcp.event.orchestrator.dto.iam;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;

import javax.validation.constraints.NotNull;


@JsonTypeName("credentials")
@JsonTypeInfo(include = JsonTypeInfo.As.WRAPPER_OBJECT, use = JsonTypeInfo.Id.NAME)
public class IamxRecoveryQuestionCredentials {

  @NotNull
  @JsonProperty("recovery_question")
  private IamxRecoveryQuestion iamxRecoveryQuestion;

  @JsonCreator
  public IamxRecoveryQuestionCredentials(IamxRecoveryQuestion iamxRecoveryQuestion) {
    this.iamxRecoveryQuestion = new IamxRecoveryQuestion(iamxRecoveryQuestion.getQuestionId(),
        iamxRecoveryQuestion.getAnswer());
  }

  public IamxRecoveryQuestion getIamxRecoveryQuestion() {
    return iamxRecoveryQuestion;
  }

  public void setIamxRecoveryQuestion(IamxRecoveryQuestion iamxRecoveryQuestion) {
    this.iamxRecoveryQuestion = iamxRecoveryQuestion;
  }
}
