package ca.bnc.bne.mcp.event.orchestrator.handler;

public enum EventTargetSystem {
    GCC("GCC", "641"),        
    SBIE("SBIE", "1395");

    public String label;
    public String srcCd;

    EventTargetSystem(String label, String srcCd) {
      this.label = label;
      this.srcCd = srcCd;
    }
}
