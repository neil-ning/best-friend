package ca.bnc.bne.mcp.event.orchestrator.mapper;

import ca.bnc.bne.mcp.event.orchestrator.exception.model.InvalidResponseException;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.IndividualRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.Other;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.Profile;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.BasicInfo;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.Contact;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.OrganizationInput;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.BaseIndividualRSP;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.GetIndividualBaseResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.IndividualNamePlusKey;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.organization.GetOrganizationResponseType;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.organization.OrganizationNameType;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.organization.OrganizationType;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.organization.PartyMemberType;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyAddress.Addresses;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyAddress.GetPtyAddressesResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyAddress.PartyAddress;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyContact.GetPtyContactsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyContact.PtyContactsType;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyContact.PtyElectronicCtcInfo;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyContact.PtyTelecommunication;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyIdentification.GetPtyIdentificationsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyIdentification.PartyIdentifications;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyRelationship.GetRelationshipsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyRelationship.Relationship;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.socioDemo.GetIndividualSocioDemographicsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.socioDemo.SocioDemographicKeyRessource;
import ca.bnc.bne.mcp.event.orchestrator.mapper.organization.OrganizationMapper;
import ca.bnc.bne.mcp.event.orchestrator.util.Constants;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.springframework.stereotype.Component;

@Component
public class McpResponseToBneRequestMapper {

  private final OrganizationMapper organizationMapper;

  public McpResponseToBneRequestMapper(OrganizationMapper organizationMapper) {
    this.organizationMapper = organizationMapper;
  }

  public IndividualRequest mapBaseIndividual(GetIndividualBaseResponse getIndividualBaseResponse) {
    BaseIndividualRSP individual =
        Optional.ofNullable(getIndividualBaseResponse)
            .map(GetIndividualBaseResponse::getIndividual)
            .orElseThrow(
                () -> {
                  throw new InvalidResponseException("Base individual response is empty!");
                });

    IndividualNamePlusKey name =
        Stream.ofNullable(individual.getIndividualName())
            .flatMap(Collection::stream)
            .filter(
                individualNamePlusKey -> dateFilter(individualNamePlusKey.getIndividualNmEndDt()))
            .max(Comparator.comparing(IndividualNamePlusKey::getIndividualNmEffctvDt))
            .orElseThrow(
                () -> {
                  throw new InvalidResponseException("No name found!");
                });

    return new IndividualRequest()
        .profile(
            new Profile()
                .lastname(name.getSurname())
                .firstname(name.getGivenName())
                .birthday(individual.getIndvBirthDt().format(DateTimeFormatter.BASIC_ISO_DATE))
                .language(Profile.LanguageEnum.fromValue(individual.getPrefContactLangCd())));
  }

  public IndividualRequest mapIndividualSocioDemographic(
      GetIndividualSocioDemographicsResponse socioDemographicsResponse) {

    String gender =
        Optional.ofNullable(socioDemographicsResponse)
            .map(GetIndividualSocioDemographicsResponse::getSocioDemographic)
            .map(SocioDemographicKeyRessource::getGenderCd)
            .orElseThrow(
                () -> {
                  throw new InvalidResponseException("No gender found!");
                });

    return new IndividualRequest().profile(new Profile().sex(Profile.SexEnum.fromValue(gender)));
  }

  // TODO: Find a smarter way to do this
  public IndividualRequest mapIndividualPtyIdentification(
      GetPtyIdentificationsResponse getPtyIdentificationsResponse) {
    getPtyIdentificationsResponse =
        Optional.ofNullable(getPtyIdentificationsResponse)
            .orElseThrow(() -> new InvalidResponseException("No identification info returned."));

    List<PartyIdentifications> ptyIdentifications =
        Stream.ofNullable(getPtyIdentificationsResponse.getPartyIdentifications())
            .flatMap(Collection::stream)
            .filter(i -> i.getPtyIdentStatusCd().equalsIgnoreCase("ACTIVE"))
            .filter(i -> i.getPtyIdentItemExpirDt().isAfter(LocalDate.now()))
            .sorted(Comparator.comparing(PartyIdentifications::getPtyIdentUpdDt).reversed())
            .limit(2)
            .collect(Collectors.toList());

    if (ptyIdentifications.isEmpty()) {
      throw new InvalidResponseException("No identifications returned!");
    } else {
      Other other = new Other();
      if (ptyIdentifications.get(0) != null) {
        other.identificationType1(ptyIdentifications.get(0).getPtyIdentItemTypeCd());
        other.identificationValue1(ptyIdentifications.get(0).getPtyIdentItemNo());
      }
      if (ptyIdentifications.size() == 2 && ptyIdentifications.get(1) != null) {
        other.identificationType2(ptyIdentifications.get(1).getPtyIdentItemTypeCd());
        other.identificationValue2(ptyIdentifications.get(1).getPtyIdentItemNo());
      }
      return new IndividualRequest().other(other);
    }
  }

  public IndividualRequest mapIndividualContactInfo(GetPtyContactsResponse getPtyContactsResponse) {
    PtyContactsType contacts =
        Optional.ofNullable(getPtyContactsResponse)
            .map(GetPtyContactsResponse::getContacts)
            .orElseThrow(
                () -> {
                  throw new InvalidResponseException("No pty contacts returned.");
                });

    return new IndividualRequest()
        .profile(
            new Profile()
                .cell(getTelecommunicationInfoByType(contacts, Constants.CELL))
                .phone(getTelecommunicationInfoByType(contacts, Constants.HOME_PHONE))
                .email(getElectronicInfoByType(contacts, Constants.EMAIL_TYPE)));
  }

  public List<String> mapRelatedOrganizationBncIdList(
      GetRelationshipsResponse relationshipsResponse) {
    relationshipsResponse =
        Optional.ofNullable(relationshipsResponse)
            .orElseThrow(
                () -> {
                  throw new InvalidResponseException("No relationship response returned.");
                });

    return Stream.ofNullable(relationshipsResponse.getRelationships())
        .flatMap(Collection::stream)
        .filter(r -> r.getInitiatingPartyRole() == Relationship.InitiatingPartyRoleEnum.AUTHRZDREP)
        .map(Relationship::getOppositeBncId)
        .collect(Collectors.toList());
  }

  public OrganizationInput mapBaseOrganization(GetOrganizationResponseType organizationResponse) {
    OrganizationType organization =
        Optional.ofNullable(organizationResponse)
            .map(GetOrganizationResponseType::getOrganization)
            .orElseThrow(() -> new InvalidResponseException("No organization returned!"));

    return new OrganizationInput()
        .basicInfo(
            new BasicInfo()
                .langue(
                    BasicInfo.LangueEnum.fromValue(
                        organization.getPrefContactLangCd().toUpperCase()))
                .nomCIE(
                    Stream.ofNullable(organization.getOrganizationNames())
                        .flatMap(Collection::stream)
                        .filter(n -> n.getOrgNmTypeCd().equalsIgnoreCase(Constants.ORG_NAME_TYPE))
                        .filter(n -> dateFilter(n.getOrgNmEndDt()))
                        .max(Comparator.comparing(OrganizationNameType::getOrgNmUpdDt))
                        .map(OrganizationNameType::getOrgName)
                        .orElseThrow(
                            () -> {
                              throw new InvalidResponseException("No legal organization name!");
                            })));
  }

  public OrganizationInput mapOrganizationAddress(GetPtyAddressesResponse ptyAddressResponse) {
    ptyAddressResponse =
        Optional.ofNullable(ptyAddressResponse)
            .orElseThrow(() -> new InvalidResponseException("No address returned"));

    Addresses address =
        Stream.ofNullable(ptyAddressResponse.getPartyAddresses())
            .flatMap(Collection::stream)
            .filter(a -> a.getPtyAddrUsageTypeCd().equalsIgnoreCase(Constants.ORG_ADDR_TYPE))
            .max(Comparator.comparing(PartyAddress::getPtyAddrUpdDt))
            .map(PartyAddress::getAddress)
            .orElseThrow(
                () -> {
                  throw new InvalidResponseException("Address of type head office not found.");
                });

    return new OrganizationInput()
        .address(organizationMapper.mapOrganizationAddressFromMcp(address));
  }

  public OrganizationInput mapOrganizationContactInfo(
      GetPtyContactsResponse getPtyContactsResponse) {
    PtyContactsType contacts =
        Optional.ofNullable(getPtyContactsResponse)
            .map(GetPtyContactsResponse::getContacts)
            .orElseThrow(
                () -> new InvalidResponseException("No organization contact info returned."));

    return new OrganizationInput()
        .contact(
            new Contact()
                .phone(getTelecommunicationInfoByType(contacts, Constants.HOME_PHONE))
                .email(getElectronicInfoByType(contacts, Constants.EMAIL_TYPE))
                .fax(getTelecommunicationInfoByType(contacts, Constants.FAX_TYPE)));
  }

  public List<String> mapOrganizationBncIdToOtherSystemBySrcId(
      GetOrganizationResponseType organizationResponse, String srcCd) {
    OrganizationType organization =
        Optional.ofNullable(organizationResponse)
            .map(GetOrganizationResponseType::getOrganization)
            .orElseThrow(() -> new InvalidResponseException("No organization returned!"));

    return Stream.ofNullable(organization.getPartyMembers())
        .flatMap(Collection::stream)
        .filter(partyMemberType -> partyMemberType.getSrcCd().contains(srcCd))
        .map(PartyMemberType::getMemberIdNo)
        .collect(Collectors.toList());
  }

  private String getElectronicInfoByType(PtyContactsType contacts, String type) {
    return Stream.ofNullable(contacts.getPtyElectronicCtcInfo())
        .flatMap(Collection::stream)
        .filter(e -> e.getPtyElectronicCtcInfoTypeCode().equalsIgnoreCase(type))
        .filter(e -> dateFilter(e.getPtyContactEndDt()))
        .max(Comparator.comparing(PtyElectronicCtcInfo::getPtyContactEffctvDt))
        .map(PtyElectronicCtcInfo::getPtyElectronicCtcInfoAddrNm)
        .orElse(null);
  }

  private String getTelecommunicationInfoByType(PtyContactsType contacts, String type) {
    return Stream.ofNullable(contacts.getPtyTelecommunication())
        .flatMap(Collection::stream)
        .filter(e -> e.getPtyTlcDvcTypeCd().equalsIgnoreCase(type))
        .filter(e -> dateFilter(e.getPtyContactEndDt()))
        .max(Comparator.comparing(PtyTelecommunication::getPtyContactEffctvDt))
        .map(PtyTelecommunication::getPtyTlcCompletePhoneNo)
        .orElse(null);
  }

  private boolean dateFilter(OffsetDateTime time) {
    return time == null || time.isAfter(OffsetDateTime.now());
  }
}
