package ca.bnc.bne.mcp.event.orchestrator.strategy;

import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.IndividualRequest;
import ca.bnc.bne.mcp.event.orchestrator.mapper.EventMapper;
import java.util.List;
import reactor.core.publisher.Mono;

public enum IndividualBusinessObjectStrategy {
  BASEINDIV {
    public List<Mono<IndividualRequest>> invokeMcpServices(String bncId, EventMapper eventMapper,String targetSys) {
      return List.of(
          eventMapper.baseIndividualMono(bncId, targetSys),
          eventMapper.individualSocioDemoMono(bncId, targetSys),
          eventMapper.individualPtyIdentificationMono(bncId, targetSys),
          eventMapper.individualContactMono(bncId, targetSys));
    }
  },
  PTYEXTID {
    public List<Mono<IndividualRequest>> invokeMcpServices(String bncId, EventMapper eventMapper,String targetSys) {
      return List.of(eventMapper.individualPtyIdentificationMono(bncId, targetSys));
    }
  },
  PTYCTCMETH {
    public List<Mono<IndividualRequest>> invokeMcpServices(String bncId, EventMapper eventMapper,String targetSys) {
      return List.of(eventMapper.individualContactMono(bncId, targetSys));
    }
  },
  ROLERLNTP {
    public List<Mono<IndividualRequest>> invokeMcpServices(String bncId, EventMapper eventMapper, String targetSys) {
      return List.of(
          eventMapper.baseIndividualMono(bncId, targetSys),
          eventMapper.individualSocioDemoMono(bncId, targetSys),
          eventMapper.individualPtyIdentificationMono(bncId, targetSys),
          eventMapper.individualContactMono(bncId, targetSys));
    }
  },
  SOCIODEMO {
    public List<Mono<IndividualRequest>> invokeMcpServices(String bncId, EventMapper eventMapper, String targetSys) {
      return List.of(eventMapper.individualSocioDemoMono(bncId, targetSys));
    }
  },
  SYSTEMKEY {
    public List<Mono<IndividualRequest>> invokeMcpServices(String bncId, EventMapper eventMapper, String targetSys) {
      return List.of(Mono.just(new IndividualRequest()));
    }
  };

  public abstract List<Mono<IndividualRequest>> invokeMcpServices(
      String bncId, EventMapper eventMapper, String targetSys);
}
