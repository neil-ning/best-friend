package ca.bnc.bne.mcp.event.orchestrator.dto.iam;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


import javax.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class IamxRecoveryQuestion {
  @NotNull
  @JsonProperty("question")
  private String questionId;
  @NotNull
  private String answer;

  @JsonCreator
  public IamxRecoveryQuestion(String questionId, String answer) {
    this.questionId = questionId;
    this.answer = answer;
  }

  public String getQuestionId() {
    return questionId;
  }

  public void setQuestionId(String questionId) {
    this.questionId = questionId;
  }

  public String getAnswer() {
    return answer;
  }

  public void setAnswer(String answer) {
    this.answer = answer;
  }
}
