package ca.bnc.bne.mcp.event.orchestrator.util;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonParser.Feature;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class JsonUtil {

  private static ObjectMapper mapper;
  private final ObjectMapper defaultMapper;

  public JsonUtil(@Qualifier("globalMapper") ObjectMapper defaultMapper) {
    this.defaultMapper = defaultMapper;
  }

  public static String stringify(Object object) throws JsonProcessingException {
    return mapper.writeValueAsString(object);
  }

  public static <K> K deepCopy(Object object, Class<K> klass) throws JsonProcessingException {
    return mapper.readValue(mapper.writeValueAsString(object), klass);
  }

  public static <K> K parse(String json, Class<K> klass) throws JsonProcessingException {
    return mapper.readValue(json, klass);
  }

  @PostConstruct
  public void initMapper() {
    mapper = defaultMapper;
  }

  @Configuration
  public static class GlobalMapper {

    @Primary
    @Bean(name = "globalMapper")
    public ObjectMapper mapper() {
      return new ObjectMapper()
          .setSerializationInclusion(Include.NON_EMPTY)
          .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, true)
          .configure(Feature.ALLOW_COMMENTS, true)
          .configure(MapperFeature.USE_STD_BEAN_NAMING, true)
          .configure(Feature.ALLOW_UNQUOTED_FIELD_NAMES, true)
          .configure(SerializationFeature.WRAP_ROOT_VALUE, false)
          .configure(DeserializationFeature.UNWRAP_ROOT_VALUE, false)
          .configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, false)
          .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
          .findAndRegisterModules();
    }
  }
}
