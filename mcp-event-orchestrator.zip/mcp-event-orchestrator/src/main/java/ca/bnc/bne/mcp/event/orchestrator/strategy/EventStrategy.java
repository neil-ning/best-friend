package ca.bnc.bne.mcp.event.orchestrator.strategy;

import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.orchestrator.event.EventRequest;
import java.util.Collection;
import java.util.function.Function;
import org.springframework.util.CollectionUtils;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface EventStrategy {

  Mono<Void> invoke(EventRequest request);

  default <T> Flux<T> buildAndMapFromCollection(
      Collection<String> collection, T input, Function<String, T> mapper) {
    return CollectionUtils.isEmpty(collection)
        ? Flux.just(input)
        : Flux.fromIterable(collection).map(mapper);
  }
}
