package ca.bnc.bne.mcp.event.orchestrator.mapper;

import ca.bnc.bne.mcp.event.orchestrator.dto.okta.OktaResponse;
import ca.bnc.bne.mcp.event.orchestrator.exception.model.OktaTokenException;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.General;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.individual.IndividualRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.bne.organization.OrganizationInput;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.AddPartySysKeyRequestBncId;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.AddPartySysKeysBncId;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.AddPtyMember;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.PartyIdentification;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.PtyIdBncId;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.StandardResponse;
import ca.bnc.bne.mcp.event.orchestrator.service.mcp.McpService;
import ca.bnc.bne.mcp.event.orchestrator.service.okta.OktaService;
import ca.bnc.bne.mcp.event.orchestrator.util.Constants;
import javax.annotation.PostConstruct;
import org.slf4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
public class EventMapper {

  private static final Logger logger = org.slf4j.LoggerFactory.getLogger(EventMapper.class);

  private final McpService mcpService;
  private final OktaService oktaService;
  private final McpResponseToBneRequestMapper mcpResponseToBneRequestMapper;
  private Mono<OktaResponse> oktaResponseMonoGcc, oktaResponseMonoSbie;

  public EventMapper(
      McpService mcpService, OktaService oktaService, McpResponseToBneRequestMapper mapper) {
    this.mcpService = mcpService;
    this.oktaService = oktaService;
    this.mcpResponseToBneRequestMapper = mapper;
  }

  @PostConstruct
  public void startUp() {
    this.oktaResponseMonoGcc = oktaService.cacheToken(OktaService.GCC);
    this.oktaResponseMonoSbie = oktaService.cacheToken(OktaService.SBIE);
  }

  public Mono<IndividualRequest> baseIndividualMono(String bncId, String targetSys) {
    return getOktaTokenMono(targetSys)
        .flatMap(oktaToken -> mcpService.getBaseIndividualMono(bncId, oktaToken))
        .doOnNext(r -> logger.info(r.toString()))
        .map(mcpResponseToBneRequestMapper::mapBaseIndividual);
  }

  public Mono<IndividualRequest> individualContactMono(String bncId, String targetSys) {
    return getOktaTokenMono(targetSys)
        .flatMap(oktaToken -> mcpService.getPtyContactsMono(bncId, oktaToken))
        .doOnNext(r -> logger.info(r.toString()))
        .map(mcpResponseToBneRequestMapper::mapIndividualContactInfo);
  }

  public Mono<IndividualRequest> individualSocioDemoMono(String bncId, String targetSys) {
    return getOktaTokenMono(targetSys)
        .flatMap(oktaToken -> mcpService.getSocioDemoMono(bncId, oktaToken))
        .doOnNext(r -> logger.info(r.toString()))
        .map(mcpResponseToBneRequestMapper::mapIndividualSocioDemographic);
  }

  public Mono<IndividualRequest> individualPtyIdentificationMono(String bncId, String targetSys) {
    return getOktaTokenMono(targetSys)
        .flatMap(oktaToken -> mcpService.getPtyIdentificationMono(bncId, oktaToken))
        .doOnNext(r -> logger.info(r.toString()))
        .map(mcpResponseToBneRequestMapper::mapIndividualPtyIdentification);
  }

  public Flux<IndividualRequest> relatedOrganizationIdsFromIndividualFlux(String individualBncId, String targetSys) {
    // if there are no related organizations, then it will be empty Flux
    return getOktaTokenMono(targetSys)
        .flatMap(oktaToken -> mcpService.getPtyRelationshipMono(individualBncId, "AUTHRZDREP", oktaToken))
        .doOnNext(r -> logger.info(r.toString()))
        .map(mcpResponseToBneRequestMapper::mapRelatedOrganizationBncIdList)
        .flatMapMany(Flux::fromIterable)
        .flatMap(
            orgBnc ->
                organizationSrcIdsFromBncIdFlux(orgBnc, Constants.GCC_SRC, targetSys)
                    .filter(s -> !StringUtils.isEmpty(s))
                    .map(
                        orgGcc ->
                            new IndividualRequest()
                                .general(new General().orgGccNbr(orgGcc).orgBncId(orgBnc))));
  }

  public Mono<OrganizationInput> baseOrganizationMono(String bncId, String targetSys) {
    return getOktaTokenMono(targetSys)
        .flatMap(oktaToken -> mcpService.getBaseOrganizationMono(bncId, oktaToken))
        .doOnNext(r -> logger.info(r.toString()))
        .map(mcpResponseToBneRequestMapper::mapBaseOrganization);
  }

  public Mono<OrganizationInput> organizationAddressMono(String bncId, String targetSys) {
    return getOktaTokenMono(targetSys)
        .flatMap(oktaToken -> mcpService.getPtyAddressMono(bncId, oktaToken))
        .doOnNext(r -> logger.info(r.toString()))
        .map(mcpResponseToBneRequestMapper::mapOrganizationAddress);
  }

  public Mono<OrganizationInput> organizationContactMono(String bncId, String targetSys) {
    return getOktaTokenMono(targetSys)
        .flatMap(oktaToken -> mcpService.getPtyContactsMono(bncId, oktaToken))
        .doOnNext(r -> logger.info(r.toString()))
        .map(mcpResponseToBneRequestMapper::mapOrganizationContactInfo);
  }

  public Flux<OrganizationInput> organizationFccFlux(String bncId, String targetSys) {
    return organizationSrcIdsFromBncIdFlux(bncId, Constants.FCC_SRC, targetSys)
        .map(fcc -> new OrganizationInput().noFcc(fcc));
  }

  public Mono<StandardResponse> addNewGccIdToMcpSystemKeys(
      String bncId, String systemId, String srcCd, String messageId) {
    return addNewSystemKeyToMcp(bncId, systemId, srcCd, messageId, OktaService.GCC);
  }

  public Mono<StandardResponse> addNewSystemKeyToMcp(
          String bncId, String idToAdd, String srcCd, String messageId, String targetSys) {
    AddPartySysKeyRequestBncId request =
        new AddPartySysKeyRequestBncId()
            .addPartySysKeys(
                new AddPartySysKeysBncId()
                    .requestID(messageId)
                    .addPtyMember(new AddPtyMember().memberIdNo(idToAdd).srcCd(srcCd))
                    .ptyId(
                        new PtyIdBncId()
                            .partyIdentification(
                                new PartyIdentification()
                                    .ptyIdentItemNo(bncId)
                                    .ptyIdentItemTypeCd("BNCID"))));

    return getOktaTokenMono(targetSys)
        .flatMap(oktaToken -> mcpService.postSystemKeysByBncId(request, oktaToken, bncId));
  }

  Flux<String> organizationSrcIdsFromBncIdFlux(String bncId, String srcCd, String targetSys) {
    return getOktaTokenMono(targetSys)
        .flatMap(oktaToken -> mcpService.getBaseOrganizationMono(bncId, oktaToken))
        .doOnNext(r -> logger.info(r.toString()))
        .map(
            orgResponse ->
                mcpResponseToBneRequestMapper.mapOrganizationBncIdToOtherSystemBySrcId(
                    orgResponse, srcCd))
        .flatMapMany(Flux::fromIterable);
  }

  Mono<String> getOktaTokenMono(String targetSys) {

    if(org.apache.commons.lang3.StringUtils.equals(OktaService.GCC, targetSys)){
      return oktaResponseMonoGcc
              .map(OktaResponse::getAccessToken)
              .switchIfEmpty(Mono.error(() -> new OktaTokenException("No token returned.")));
    }else{
      return oktaResponseMonoSbie
              .map(OktaResponse::getAccessToken)
              .switchIfEmpty(Mono.error(() -> new OktaTokenException("No token returned.")));
    }
  }

  public OktaService getOktaService() {
    return oktaService;
  }

  public McpResponseToBneRequestMapper getMcpResponseToBneRequestMapper() {
    return mcpResponseToBneRequestMapper;
  }

  public void setOktaResponseMonoGcc(Mono<OktaResponse> oktaResponseMonoGcc) {
    this.oktaResponseMonoGcc = oktaResponseMonoGcc;
  }

  public void setOktaResponseMonoSbie(Mono<OktaResponse> oktaResponseMonoSbie) {
    this.oktaResponseMonoSbie = oktaResponseMonoSbie;
  }
}
