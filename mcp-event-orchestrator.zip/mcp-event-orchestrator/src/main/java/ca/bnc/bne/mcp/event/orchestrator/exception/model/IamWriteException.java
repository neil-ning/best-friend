package ca.bnc.bne.mcp.event.orchestrator.exception.model;

public class IamWriteException extends RuntimeException {
  public static final String FAILED_TO_CREATE_PROFILE_IN_IAM = "Failed to create profile in IAM";
  public static final String FAILED_TO_DELETE_PROFILE_IN_IAM = "Failed to delete profile in IAM";
  public static final String FAILED_TO_UPDATE_EMAIL_IN_IAM = "Failed to update email in IAM";
  public static final String FAILED_TO_UPDATE_PHONE_IN_IAM = "Failed to update phone in IAM";
  public static final String FAILED_TO_DELETE_PHONE_IN_IAM = "Failed to delete phone in IAM";
  public static final String FAILED_TO_UPDATE_VOICE_IN_IAM = "Failed to update voice in IAM";
  public static final String FAILED_TO_DELETE_VOICE_IN_IAM = "Failed to delete voice in IAM";

  public IamWriteException() {
    super("Error in writing IAM");
  }

  public IamWriteException(Throwable cause) {
    super(cause);
  }

  public IamWriteException(String message) {
    super(message);
  }

  public IamWriteException(String message, Throwable cause) {
    super(message, cause);
  }
}
