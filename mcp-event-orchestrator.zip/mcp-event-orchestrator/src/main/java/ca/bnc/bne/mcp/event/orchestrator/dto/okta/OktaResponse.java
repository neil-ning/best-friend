package ca.bnc.bne.mcp.event.orchestrator.dto.okta;

import com.fasterxml.jackson.annotation.JsonProperty;

public class OktaResponse {

  @JsonProperty("token_type")
  private String tokenType;

  @JsonProperty("expires_in")
  private int expiresIn;

  @JsonProperty("access_token")
  private String accessToken;

  private String scope;

  public OktaResponse tokenType(String tokenType) {
    this.tokenType = tokenType;
    return this;
  }

  public OktaResponse expiresIn(int expiresIn) {
    this.expiresIn = expiresIn;
    return this;
  }

  public OktaResponse accessToken(String accessToken) {
    this.accessToken = accessToken;
    return this;
  }

  public OktaResponse scope(String scope) {
    this.scope = scope;
    return this;
  }

  public String getTokenType() {
    return tokenType;
  }

  public int getExpiresIn() {
    return expiresIn;
  }

  public String getAccessToken() {
    return accessToken;
  }

  public String getScope() {
    return scope;
  }
}
