package ca.bnc.bne.mcp.event.orchestrator.service.mcp;

import ca.bnc.bne.mcp.event.orchestrator.exception.model.AddSystemKeyException;
import ca.bnc.bne.mcp.event.orchestrator.exception.model.InvalidResponseException;
import ca.bnc.bne.mcp.event.orchestrator.exception.model.McpBusinessRuleException;
import ca.bnc.bne.mcp.event.orchestrator.exception.model.McpWriteException;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.CreateIndividualRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.CreateIndividualResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.GetIndividualBaseResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.Problem;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.UpdateIndividualBaseRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.individual.UpdateIndividualBaseResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.organization.GetOrganizationResponseType;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyAddress.GetPtyAddressesResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyAddress.UpdatePtyAddressesRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyAddress.UpdatePtyAddressesResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyContact.GetPtyContactsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyContact.UpdatePtyContactsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyContact.UpdatePtyContactsWithBNCIDRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyIdentification.GetPtyIdentificationsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyRelationship.GetRelationshipsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyRelationship.PostRelationship;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.ptyRelationship.RemovedRelationship;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.socioDemo.GetIndividualSocioDemographicsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.socioDemo.UpdateIndividualSocioDemographicsResponse;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.socioDemo.UpdateIndividualSocioDemographicsWithBNCIDRequest;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.AddPartySysKeyRequestBncId;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.RemovePartySysKeyRequestBncId;
import ca.bnc.bne.mcp.event.orchestrator.gen.model.mcp.systemKeys.StandardResponse;
import ca.bnc.bne.mcp.event.orchestrator.util.Constants;
import ca.bnc.bne.mcp.event.orchestrator.util.HttpLoggingHandler;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.netty.channel.BootstrapHandlers;
import reactor.netty.http.client.HttpClient;
import reactor.util.retry.Retry;

import java.time.Duration;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;

@Service
@ConfigurationProperties("mcp")
public class McpService {
    private static final Logger logger = org.slf4j.LoggerFactory.getLogger(McpService.class);
    private final WebClient webClient;
    private Endpoint endpoint;

    public McpService(
            @Value("${mcp.base-url}") String baseUrl,
            @Value("${mcp.client-id}") String clientId,
            WebClient.Builder builder) {

        HttpClient httpClient = HttpClient.create()
                .tcpConfiguration(tcpClient ->
                        tcpClient.bootstrap(bootstrap ->
                                BootstrapHandlers.updateLogSupport(bootstrap, new HttpLoggingHandler())));

        this.webClient =
                builder
                        .baseUrl(baseUrl)
                        //.clientConnector(new ReactorClientHttpConnector(httpClient))
                        .codecs(
                                clientCodecConfigurer ->
                                        clientCodecConfigurer.defaultCodecs().enableLoggingRequestDetails(true))
                        .defaultHeader(Constants.IBM_CLIENT_ID, clientId)
                        .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                        .build();
    }

    public Mono<GetIndividualBaseResponse> getBaseIndividualMono(String bncId, String oktaToken) {
        return webClient
                .get()
                .uri(endpoint.individual, bncId)
                .headers(httpHeaders -> httpHeaders.setBearerAuth(oktaToken))
                .retrieve()
                .onStatus(checkSpecificHttpStatus(HttpStatus.BAD_REQUEST), mcpExceptionFunction())
                .bodyToMono(GetIndividualBaseResponse.class)
        .switchIfEmpty(Mono.error(() -> new InvalidResponseException("Empty MCP response body.")));
    }

    public Mono<GetOrganizationResponseType> getBaseOrganizationMono(String bncId, String oktaToken) {
        return webClient
                .get()
                .uri(endpoint.organization, bncId)
                .headers(httpHeaders -> httpHeaders.setBearerAuth(oktaToken))
                .retrieve()
                .onStatus(checkSpecificHttpStatus(HttpStatus.BAD_REQUEST), mcpExceptionFunction())
                .bodyToMono(GetOrganizationResponseType.class)
        .switchIfEmpty(Mono.error(() -> new InvalidResponseException("Empty MCP response body.")));
    }

    public Mono<GetPtyContactsResponse> getPtyContactsMono(String bncId, String oktaToken) {
        return webClient
                .get()
                .uri(endpoint.ptyContacts, bncId)
                .headers(httpHeaders -> httpHeaders.setBearerAuth(oktaToken))
                .retrieve()
                .onStatus(checkSpecificHttpStatus(HttpStatus.BAD_REQUEST), mcpExceptionFunction())
                .bodyToMono(GetPtyContactsResponse.class)
        .switchIfEmpty(Mono.error(() -> new InvalidResponseException("Empty MCP response body.")));
    }

    public Mono<GetPtyAddressesResponse> getPtyAddressMono(String bncId, String oktaToken) {
        return webClient
                .get()
                .uri(endpoint.ptyAddress, bncId)
                .headers(httpHeaders -> httpHeaders.setBearerAuth(oktaToken))
                .retrieve()
                .onStatus(checkSpecificHttpStatus(HttpStatus.BAD_REQUEST), mcpExceptionFunction())
                .bodyToMono(GetPtyAddressesResponse.class)
        .switchIfEmpty(Mono.error(() -> new InvalidResponseException("Empty MCP response body.")));
    }

    public Mono<GetPtyIdentificationsResponse> getPtyIdentificationMono(
            String bncId, String oktaToken) {
        return webClient
                .get()
                .uri(endpoint.ptyIdentification, bncId)
                .headers(httpHeaders -> httpHeaders.setBearerAuth(oktaToken))
                .retrieve()
                .onStatus(checkSpecificHttpStatus(HttpStatus.BAD_REQUEST), mcpExceptionFunction())
                .bodyToMono(GetPtyIdentificationsResponse.class)
        .switchIfEmpty(Mono.error(() -> new InvalidResponseException("Empty MCP response body.")));
    }

    public Mono<GetIndividualSocioDemographicsResponse> getSocioDemoMono(
            String bncId, String oktaToken) {
        return webClient
                .get()
                .uri(endpoint.socioDemo, bncId)
                .headers(httpHeaders -> httpHeaders.setBearerAuth(oktaToken))
                .retrieve()
                .onStatus(checkSpecificHttpStatus(HttpStatus.BAD_REQUEST), mcpExceptionFunction())
                .bodyToMono(GetIndividualSocioDemographicsResponse.class)
        .switchIfEmpty(Mono.error(() -> new InvalidResponseException("Empty MCP response body.")));
    }

    public Mono<GetRelationshipsResponse> getPtyRelationshipMono(String bncId, String partyFilter, String oktaToken) {

        return webClient
                .get()
                .uri(uriBuilder -> {
                    uriBuilder
                            .path(endpoint.ptyRelationship)
                            .queryParam("bncId", bncId);
                    if (StringUtils.isNotBlank(partyFilter)) {
                        uriBuilder.queryParam("partyFilter", partyFilter);
                    }
                    return uriBuilder.build();
                })
                .headers(httpHeaders -> httpHeaders.setBearerAuth(oktaToken))
                .retrieve()
                .onStatus(checkSpecificHttpStatus(HttpStatus.BAD_REQUEST), mcpExceptionFunction())
                .bodyToMono(GetRelationshipsResponse.class)
        .switchIfEmpty(Mono.error(() -> new InvalidResponseException("Empty MCP response body.")));
    }

    public Mono<StandardResponse> postSystemKeysByBncId(
            AddPartySysKeyRequestBncId request, String oktaToken, String bncId) {
        return webClient
                .post()
                .uri(endpoint.systemKeys, bncId)
                .headers(httpHeaders -> httpHeaders.setBearerAuth(oktaToken))
                .bodyValue(request)
                .exchange()
        .flatMap(systemKeysFunction());
    }

    public Mono<GetIndividualBaseResponse> getIndividual(String systemId, String srcCd, String oktaToken) {
        return webClient
                .get()
                .uri(endpoint.uriLookupIndividual, systemId, srcCd)
                .headers(httpHeaders -> httpHeaders.setBearerAuth(oktaToken))
                .retrieve()
                .onStatus(HttpStatus::isError, clientResponse -> Mono.error(new McpWriteException(McpWriteException.FAILED_TO_LOOKUP_INDIVIDUAL_IN_MCP)))
                .bodyToMono(GetIndividualBaseResponse.class)
                .switchIfEmpty(Mono.error(() -> new McpWriteException(McpWriteException.FAILED_TO_LOOKUP_INDIVIDUAL_IN_MCP)))
                .doOnSuccess(ok -> logger.info("Individual profile found in MCP for systemId={} srcCd={}", systemId, srcCd))
                .doOnError(err -> logger.error("Individual profile lookup in MCP failed", err));
    }

    public Mono<CreateIndividualResponse> createIndividual(String originSrcCd, CreateIndividualRequest requestBody, String oktaToken) {
        return webClient
                .post()
                .uri(endpoint.uriCreateIndividual, originSrcCd)
                .bodyValue(requestBody)
                .headers(httpHeaders -> httpHeaders.setBearerAuth(oktaToken))
                .retrieve()
                .onStatus(HttpStatus::isError, clientResponse ->
                        clientResponse.createException())
                .bodyToMono(CreateIndividualResponse.class)
                .doOnSuccess(ok -> logger.info("Individual profile created in MCP for individual={}", requestBody.getIndividual().getIndividualName()))
                .doOnError(err -> logger.error("Individual profile creation in MCP failed", err))
                .onErrorMap(err -> new McpWriteException(McpWriteException.FAILED_TO_CREATE_INDIVIDUAL_IN_MCP, err));
    }

    public Mono<Void> linkIndividualToOrganization(PostRelationship requestBody, String oktaToken) {
        return webClient
                .post()
                .uri(endpoint.uriLinkIndividual)
                .bodyValue(requestBody)
                .headers(httpHeaders -> httpHeaders.setBearerAuth(oktaToken))
                .retrieve()
                .onStatus(HttpStatus::isError, clientResponse -> clientResponse.createException())
                .bodyToMono(Void.class)
                .doOnSuccess(ok -> logger.info("Individual profile linked in MCP for individual={} organization={}", requestBody.getInitiatingBncId(), requestBody.getOppositeBncId()))
                .doOnError(err -> logger.error("Individual profile linking in MCP failed", err))
                .onErrorResume(err -> Mono.error(new McpWriteException(McpWriteException.FAILED_TO_LINK_INDIVIDUAL_TO_ORGANIZATION_IN_MCP, err)));
    }

    public Mono<String> linkIndividualToOrganizationExchange(PostRelationship requestBody, String oktaToken) {
        return webClient
                .post()
                .uri(endpoint.uriLinkIndividual)
                .bodyValue(requestBody)
                .headers(httpHeaders -> httpHeaders.setBearerAuth(oktaToken))
                .exchange()
                .map(clientResponse -> {// TODO: has not confirmed the exact key, assign a fake one "schema"
                    String linkUrl = clientResponse.headers().header("schema").get(0);

                    String relationshipId = StringUtils.substringAfterLast(linkUrl, "/");

                    return relationshipId;
                }).onErrorResume(e -> Mono.error(new McpWriteException(McpWriteException.FAILED_TO_LINK_INDIVIDUAL_TO_ORGANIZATION_IN_MCP, e)));
    }

    public Mono<Void> unlinkIndividualToOrganization(String uid, RemovedRelationship requestBody, String oktaToken) {
        return webClient
                .method(HttpMethod.DELETE)
                .uri(endpoint.uriUnlinkIndividual, uid)
                .bodyValue(requestBody)
                .headers(httpHeaders -> httpHeaders.setBearerAuth(oktaToken))
                .retrieve()
                .onStatus(HttpStatus::isError, clientResponse -> clientResponse.createException())
                .bodyToMono(Void.class)
                .doOnSuccess(ok -> logger.info("Individual profile unlinked in MCP for relationship_uid={}", uid))
                .doOnError(err -> logger.error("Individual profile unlinking in MCP failed", err))
                .onErrorResume(err -> Mono.error(new McpWriteException(McpWriteException.FAILED_TO_UNLINK_INDIVIDUAL_TO_ORGANIZATION_IN_MCP, err)));
    }

    public Mono<UpdateIndividualBaseResponse> updateIndividualBase(UpdateIndividualBaseRequest requestBody, String oktaToken) {
        return webClient
                .put()
                .uri(endpoint.uriModifyIndividualBase)
                .bodyValue(requestBody)
                .headers(httpHeaders -> httpHeaders.setBearerAuth(oktaToken))
                .retrieve()
                .onStatus(HttpStatus::isError, clientResponse -> clientResponse.createException())
                .bodyToMono(UpdateIndividualBaseResponse.class)
                .doOnSuccess(ok -> logger.info("Individual profile base updated in MCP for individual={}", requestBody.getIndividual().getIndividualName()))
                .doOnError(err -> logger.error("Individual profile base update in MCP failed", err))
                .onErrorResume(err -> Mono.error(new McpWriteException(McpWriteException.FAILED_TO_UPDATE_INDIVIDUAL_BASE_IN_MCP, err)));
    }

    public Mono<UpdateIndividualBaseResponse> updateIndividualBaseByBncId(String bncId, UpdateIndividualBaseRequest requestBody,
                                                                          String oktaToken) {
        return webClient
                .put()
                .uri(endpoint.uriModifyIndividualBaseBncId, bncId)
                .bodyValue(requestBody)
                .headers(httpHeaders -> httpHeaders.setBearerAuth(oktaToken))
                .retrieve()
                .onStatus(HttpStatus::isError,
                        clientResponse -> clientResponse.createException())
                .bodyToMono(UpdateIndividualBaseResponse.class).log()
                .doOnSuccess(ok -> logger.info("Individual profile base updated in MCP for individual={}", requestBody.getIndividual().getIndividualName()))
                .doOnError(err -> logger.error("Individual profile base update in MCP failed", err));
    }

    public Mono<UpdatePtyContactsResponse> updateIndividualContact(String bncId, UpdatePtyContactsWithBNCIDRequest requestBody, String oktaToken) {
        return webClient
                .put()
                .uri(endpoint.uriModifyIndividualContact, bncId)
                .headers(httpHeaders -> httpHeaders.setBearerAuth(oktaToken))
                .bodyValue(requestBody)
                .retrieve()
                .onStatus(HttpStatus::isError,
                        clientResponse -> clientResponse.createException())
                .bodyToMono(UpdatePtyContactsResponse.class)
                .doOnSuccess(ok -> logger.info("Individual profile contact updated in MCP for individual={}", bncId))
                .doOnError(err -> logger.error("Individual profile contact update in MCP failed", err))
                .onErrorResume(err -> Mono.error(new McpWriteException(McpWriteException.FAILED_TO_UPDATE_INDIVIDUAL_CONTACT_IN_MCP, err)));
    }

    public Mono<UpdatePtyAddressesResponse> updateIndividualAddress(String bncId, UpdatePtyAddressesRequest requestBody, String oktaToken) {
        return webClient
                .put()
                .uri(endpoint.uriModifyIndividualAddress, bncId)
                .bodyValue(requestBody)
                .headers(httpHeaders -> httpHeaders.setBearerAuth(oktaToken))
                .retrieve()
                .onStatus(HttpStatus::isError,
                        clientResponse -> clientResponse.createException())
                .bodyToMono(UpdatePtyAddressesResponse.class)
                .doOnSuccess(ok -> logger.info("Individual profile address updated in MCP for individual={}", bncId))
                .doOnError(err -> logger.error("Individual profile address update in MCP failed", err))
                .onErrorResume(err -> Mono.error(new McpWriteException(McpWriteException.FAILED_TO_UPDATE_INDIVIDUAL_ADDRESS_IN_MCP, err)));
    }

    public Mono<UpdateIndividualSocioDemographicsResponse> updateIndividualSocio(String bncId, UpdateIndividualSocioDemographicsWithBNCIDRequest requestBody, String oktaToken) {
        return webClient
                .put()
                .uri(endpoint.uriModifyIndividualSocio, bncId)
                .bodyValue(requestBody)
                .headers(httpHeaders -> httpHeaders.setBearerAuth(oktaToken))
                .retrieve()
                .onStatus(HttpStatus::isError,
                        clientResponse -> clientResponse.createException())
                .bodyToMono(UpdateIndividualSocioDemographicsResponse.class)
                .doOnSuccess(ok -> logger.info("Individual profile socio updated in MCP for individual={}", bncId))
                .doOnError(err -> logger.error("Individual profile socio update in MCP failed", err))
                .onErrorMap(err -> new McpWriteException(McpWriteException.FAILED_TO_UPDATE_INDIVIDUAL_SOCIO_DEMOGRAPHICS_IN_MCP, err));
    }

    public Mono<StandardResponse> deleteSystemKeysByBncId(String bncId, RemovePartySysKeyRequestBncId request, String oktaToken) {
        return webClient
                .method(HttpMethod.DELETE)
                .uri(endpoint.uriDeleteSystemKeys, bncId)
                .headers(HttpHeaders -> HttpHeaders.setBearerAuth(oktaToken))
                .bodyValue(request)
                .retrieve()
                .onStatus(HttpStatus::isError, clientResponse -> clientResponse.createException())
                .bodyToMono(StandardResponse.class)
                .doOnSuccess(ok -> logger.info("System key deleted for party={}", bncId))
                .doOnError(err -> logger.error("System key delete in MCP failed", err))
                .log("ca.bnc.bne.mcp.event.orchestrator.service.mcp")
                .onErrorMap(err -> new McpWriteException(McpWriteException.FAILED_TO_DELETE_SYSTEM_KEY_IN_MCP, err));
    }

    private Function<ClientResponse, Mono<? extends StandardResponse>> systemKeysFunction() {
        List<String> acceptedStatusCode = List.of("0", "9000087");

        return clientResponse -> {
            if (clientResponse.statusCode().is2xxSuccessful()
                    || clientResponse.statusCode() == HttpStatus.BAD_REQUEST
                    || clientResponse.statusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
                return clientResponse
                        .bodyToMono(StandardResponse.class)
                        .filter(
                                standardResponse ->
                                        acceptedStatusCode.contains(standardResponse.getReturnStatusCode()))
                        .switchIfEmpty(
                                Mono.defer(
                                        () -> Mono.error(() -> new AddSystemKeyException("Status code invalid."))));
            } else {
                return clientResponse.createException().flatMap(Mono::error);
            }
        };
    }

    private Predicate<HttpStatus> checkSpecificHttpStatus(HttpStatus... toCheck) {
        return status -> Stream.of(toCheck).anyMatch(check -> check == status);
    }

    private Function<ClientResponse, Mono<? extends Throwable>> mcpExceptionFunction() {
        return clientResponse ->
                clientResponse
                        .bodyToMono(Problem.class)
                        .map(Problem::getElements)
                        .flatMapMany(Flux::fromIterable)
                        .filter(elements -> elements.getReasonCode().contains("9000"))
                        .reduce(
                                (e1, e2) ->
                                        e2.message(
                                                e1.getMessage()
                                                        + " ,"
                                                        + e2.getMessage())) // invoked only when there are more than one objects
                        .flatMap(e -> Mono.defer(() -> Mono.just(new McpBusinessRuleException(e.getMessage()))))
                        .switchIfEmpty(
                                Mono.defer(() -> Mono.just(new McpBusinessRuleException("Bad MCP Request"))))
                        .flatMap(Mono::error);
    }

    private Retry retry() {
        return Retry.backoff(3, Duration.ofSeconds(1))
                .jitter(0d)
                .doBeforeRetry(
                        retrySignal ->
                                logger.info(
                                        "Service failed. Retrying. Error message = {}. ",
                                        retrySignal.failure().getMessage()))
                .doAfterRetry(
                        retrySignal -> logger.info("Retry count = {}", retrySignal.totalRetries() + 1))
                .onRetryExhaustedThrow((retryBackoffSpec, retrySignal) -> retrySignal.failure());
    }

    public Endpoint getEndpoint() {
        return endpoint;
    }

    public McpService setEndpoint(Endpoint endpoint) {
        this.endpoint = endpoint;
        return this;
    }

    public WebClient getWebClient() {
        return webClient;
    }

    static class Endpoint {

        private String individual;
        private String organization;
        private String ptyContacts;
        private String ptyAddress;
        private String ptyIdentification;
        private String socioDemo;
        private String ptyRelationship;
        private String systemKeys;
        private String uriLookupIndividual;
        private String uriCreateIndividual;
        private String uriModifyIndividualBase;
        private String uriModifyIndividualContact;
        private String uriModifyIndividualAddress;
        private String uriModifyIndividualSocio;
        private String uriLinkIndividual;
        private String uriUnlinkIndividual;
        private String uriDeleteSystemKeys;
        private String uriModifyIndividualBaseBncId;

        public void setUriModifyIndividualBaseBncId(String uriModifyIndividualBaseBncId) {
            this.uriModifyIndividualBaseBncId = uriModifyIndividualBaseBncId;
        }

        public String getIndividual() {
            return individual;
        }

        public Endpoint setIndividual(String individual) {
            this.individual = individual;
            return this;
        }

        public String getOrganization() {
            return organization;
        }

        public Endpoint setOrganization(String organization) {
            this.organization = organization;
            return this;
        }

        public String getPtyContacts() {
            return ptyContacts;
        }

        public Endpoint setPtyContacts(String ptyContacts) {
            this.ptyContacts = ptyContacts;
            return this;
        }

        public String getPtyAddress() {
            return ptyAddress;
        }

        public Endpoint setPtyAddress(String ptyAddress) {
            this.ptyAddress = ptyAddress;
            return this;
        }

        public String getPtyIdentification() {
            return ptyIdentification;
        }

        public Endpoint setPtyIdentification(String ptyIdentification) {
            this.ptyIdentification = ptyIdentification;
            return this;
        }

        public String getSocioDemo() {
            return socioDemo;
        }

        public Endpoint setSocioDemo(String socioDemo) {
            this.socioDemo = socioDemo;
            return this;
        }

        public String getPtyRelationship() {
            return ptyRelationship;
        }

        public Endpoint setPtyRelationship(String ptyRelationship) {
            this.ptyRelationship = ptyRelationship;
            return this;
        }

        public String getSystemKeys() {
            return systemKeys;
        }

        public Endpoint setSystemKeys(String systemKeys) {
            this.systemKeys = systemKeys;
            return this;
        }

        public String getUriLookupIndividual() {
            return uriLookupIndividual;
        }

        public void setUriLookupIndividual(String uriLookupIndividual) {
            this.uriLookupIndividual = uriLookupIndividual;
        }

        public String getUriCreateIndividual() {
            return uriCreateIndividual;
        }

        public Endpoint setUriCreateIndividual(String uriCreateIndividual) {
            this.uriCreateIndividual = uriCreateIndividual;
            return this;
        }

        public String getUriModifyIndividualBase() {
            return uriModifyIndividualBase;
        }

        public Endpoint setUriModifyIndividualBase(String uriModifyIndividualBase) {
            this.uriModifyIndividualBase = uriModifyIndividualBase;
            return this;
        }

        public String getUriModifyIndividualContact() {
            return uriModifyIndividualContact;
        }

        public Endpoint setUriModifyIndividualContact(String uriModifyIndividualContact) {
            this.uriModifyIndividualContact = uriModifyIndividualContact;
            return this;
        }

        public String getUriModifyIndividualAddress() {
            return uriModifyIndividualAddress;
        }

        public Endpoint setUriModifyIndividualAddress(String uriModifyIndividualAddress) {
            this.uriModifyIndividualAddress = uriModifyIndividualAddress;
            return this;
        }

        public String getUriModifyIndividualSocio() {
            return uriModifyIndividualSocio;
        }

        public Endpoint setUriModifyIndividualSocio(String uriModifyIndividualSocio) {
            this.uriModifyIndividualSocio = uriModifyIndividualSocio;
            return this;
        }

        public String getUriLinkIndividual() {
            return uriLinkIndividual;
        }

        public Endpoint setUriLinkIndividual(String uriLinkIndividual) {
            this.uriLinkIndividual = uriLinkIndividual;
            return this;
        }

        public String getUriUnlinkIndividual() {
            return uriUnlinkIndividual;
        }

        public Endpoint setUriUnlinkIndividual(String uriUnlinkIndividual) {
            this.uriUnlinkIndividual = uriUnlinkIndividual;
            return this;
        }

        public String getUriDeleteSystemKeys() {
            return uriDeleteSystemKeys;
        }

        public Endpoint setUriDeleteSystemKeys(String uriDeleteSystemKeys) {
            this.uriDeleteSystemKeys = uriDeleteSystemKeys;
            return this;
        }
    }
}
