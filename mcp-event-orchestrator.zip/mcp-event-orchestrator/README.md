# mcp-event-orchestrator

The repository contains the source code and documentation for mcp-event-orchestrator microservice developed using spring-boot WebFlex.
The basic function of this API is to operate MCP information via api, process events which are from MCP as well.

## Table of contents

* [Getting Started](#getting-started)
* [Testing](#testing)
* [Deployment](#deployment)
* [Additional Resources](#additional-resources)

## Getting Started

### Prerequisites

* Access to [[Github-BNE]](https://github-studio.bnc.ca/BNE)
* Access to [[CircleCI]](https://circleci-studio.bnc.ca/gh/BNE/access-control-pip/tree/master)

1.add below configuration section to maven setting.xml file
```
<servers>
	<server>
	  <id>bnc-maven-central</id>
	  <username>${replaced with your short id}</username>
	  <password>${replaced with your password}</password>
	</server>
	<server>
      <id>digital-factory</id>            
      <username>${replaced with your short id}</username>
      <password>${replaced with your password}</password>
    </server>
    <server>
      <id>5327dev</id>            
      <username>${replaced with your short id}</username>
      <password>${replaced with your password}</password>
    </server>
	<server>
      <id>nexus</id>            
      <username>${replaced with your short id}</username>
      <password>${replaced with your password}</password>
    </server>
</servers>
<profiles>
  <profile>
    <id>bnc-maven-central</id>
	<repositories>
	  <repository>
	    <id>bnc-maven-central-repo</id>
	    <name>BNC_central</name>
	    <url>https://nexus.bnc.ca/repository/maven-central/</url>
	    <releases>
	      <enabled>true</enabled>
	    </releases>
	    <snapshots>
	      <enabled>false</enabled>
	    </snapshots>
	  </repository>
	</repositories>
  </profile>
  <profile>
    <id>digital-factory</id>
	<repositories>
	  <repository>
	    <id>digital-factory</id>
		<name>digital-factory</name>
		<url>https://nexus.bnc.ca/repository/digital-factory/</url>
		<releases>
		  <enabled>true</enabled>
		</releases>
		<snapshots>
		  <enabled>false</enabled>
		</snapshots>
	  </repository>
	</repositories>
  </profile>
  <profile>
    <id>5327dev</id>
	<repositories>
	  <repository>
	    <id>digital-factory</id>
		<name>digital-factory</name>
		<url>https://nexus.bnc.ca/repository/5327-mvn-development/</url>
		<releases>
		  <enabled>true</enabled>
		</releases>
     	<snapshots>
		  <enabled>false</enabled>
		</snapshots>
	  </repository>
    </repositories>
  </profile>
</profiles>
<activeProfiles>
  <activeProfile>5327dev</activeProfile>
  <activeProfile>digital-factory</activeProfile>
  <activeProfile>bnc-maven-central</activeProfile>
</activeProfiles> 
```

2.Clone the project from Github-BNE using    
```
git clone https://github-studio.bnc.ca/BNE/mcp-event-orchestrator.git
```

3.Run application locally.

To run the Application locally, you need to provide '--spring.profiles.active=local' or '-Dspring.profiles.active=local' config as application or JVM arguments.

## Testing
```
mvn clean test

mvn clean test org.pitest:pitest-maven:mutationCoverage 
```

## Deployment

The source-code from master/develop branch gets deployed in all the environment using helm charts.
Follow the procedure as mentioned in deployment repo. [[cd-pipeline]](https://github-studio.bnc.ca/BNE/cd-pipeline-v2)

## Additional Resources

1. [Wiki](https://wiki.bnc.ca/pages/viewpage.action?pageId=770149634)
