package ca.bnc.bne.individualapi.restassured;

import java.io.IOException;
import java.net.URISyntaxException;

import org.springframework.http.MediaType;

import ca.bnc.bne.individualapi.utils.Constants;
import ca.bnc.bne.individualapi.utils.JsonFileUtil;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

/**
 * Business scenarios specified in Rest Assured
 */
public class IndividualServiceScenarios {
        public void testAddAdminSuccessfully() throws IOException {
                given().header("requestId", "1").header("Authorization", "token").queryParam("orgBncId","1").queryParam("adminBncId", "2").queryParam("sysId", "3")
                                .queryParam("srcCd", "3").
                when()
                        .request("PATCH", Constants.REST_API_PATH_ADMIN).
                then()
                        .log().all()
                        .statusCode(200)
                        .body("Status", equalTo(0))
                        .body("Message", equalTo("FakeMessage"))
                        .body("RequestId", equalTo("FakeRequestId"))
                        .body("timestamp", equalTo("2017-07-21T17:32:28Z"));
        }

        public void testAddAdminStatus424() throws IOException {
                given().header("requestId", "1").header("Authorization", "token").queryParam("orgBncId","1").queryParam("adminBncId", "2").queryParam("sysId", "3")
                                .queryParam("srcCd", "3").when()
                                .request("PATCH", Constants.REST_API_PATH_ADMIN).then().log().all()
                                .statusCode(424)
                                .body("Status", equalTo(1))
                                .body("Message", equalTo("FakeMessage"))
                                .body("Error", equalTo("FakeErrorMessage")).body("RequestId", equalTo("FakeRequestId"))
                                .body("timestamp", equalTo("2017-07-21T17:32:28Z"));
        }

        public void testAddAdminStatus500() throws IOException {
                given().header("requestId", "1").header("Authorization", "token").queryParam("orgBncId","1").queryParam("adminBncId", "2").queryParam("sysId", "3")
                                .queryParam("srcCd", "3").when()
                                .request("PATCH", Constants.REST_API_PATH_ADMIN).then().log().all()
                                .statusCode(500).body("Status", equalTo(1)).body("Message", equalTo("FakeMessage"))
                                .body("Error", equalTo("FakeErrorMessage")).body("RequestId", equalTo("FakeRequestId"))
                                .body("timestamp", equalTo("2017-07-21T17:32:28Z"));
        }

        public void testAddUserSuccessfully() throws IOException, URISyntaxException {
        given().
                header("requestId","1").header("Authorization", "token").
                queryParam("orgBncId", "1").
                contentType(MediaType.APPLICATION_JSON_VALUE).
                body(JsonFileUtil.readString("controller/service/add-user-req.json")).
        when().
                request("POST", Constants.REST_API_PATH_USER).
        then().
                log().all()
                .statusCode(201)
                .body("partyIdentification.ptyIdentItemNo",equalTo("09OR32DE118643E0A09065DAAB6BDD2AD2C94995D593DE0BBD2A5F67C21k26jy"))
                .body("partyIdentification.ptyIdentItemTypeCd",equalTo("BNCID"))
                .body("partyIdentification.ptyIdentStatusCd",equalTo("ACTIVE"))
                .body("relationshipId",equalTo("string"));
        }

        public void testAddUserStatus424() throws IOException, URISyntaxException {
                given().
                        header("requestId","1").header("Authorization", "token").
                        queryParam("orgBncId", "1").
                        contentType(MediaType.APPLICATION_JSON_VALUE).
                        body(JsonFileUtil.readString("controller/service/add-user-req.json")).
                when().
                        request("POST", Constants.REST_API_PATH_USER).
                then().
                        log().all()
                        .statusCode(424)
                        .body("Status", equalTo(1))
                        .body("Message", equalTo("FakeMessage"))
                        .body("Error", equalTo("FakeErrorMessage")).body("RequestId", equalTo("FakeRequestId"))
                        .body("timestamp", equalTo("2017-07-21T17:32:28Z"));
        }

        public void testAddUserStatus500() throws IOException, URISyntaxException {
                given().
                        header("requestId","1").header("Authorization", "token").
                        queryParam("orgBncId", "1").
                        contentType(MediaType.APPLICATION_JSON_VALUE).
                        body(JsonFileUtil.readString("controller/service/add-user-req.json")).
                when().
                        request("POST", Constants.REST_API_PATH_USER).
                then().
                        log().all()
                        .statusCode(500)
                        .body("Status", equalTo(1))
                        .body("Message", equalTo("FakeMessage"))
                        .body("Error", equalTo("FakeErrorMessage")).body("RequestId", equalTo("FakeRequestId"))
                        .body("timestamp", equalTo("2017-07-21T17:32:28Z"));
        }

        public void testUpdateUserSuccessfully() throws IOException, URISyntaxException {
                given().
                        header("requestId","1").header("Authorization", "token").
                        queryParam("userBncId", "1").
                        contentType(MediaType.APPLICATION_JSON_VALUE).
                        body(JsonFileUtil.readString("controller/service/update-user-req.json")).
                when().
                        request("PUT", Constants.REST_API_PATH_USER).
                then().
                        log().all()
                        .statusCode(200)
                        .body("Status", equalTo(0))
                        .body("Message", equalTo("FakeMessage"))
                        .body("RequestId", equalTo("FakeRequestId"))
                        .body("timestamp", equalTo("2017-07-21T17:32:28Z"));
        }        

        public void testUpdateUserStatus424() throws IOException, URISyntaxException {
                given().
                        header("requestId","1").header("Authorization", "token").
                        queryParam("userBncId", "1").
                        contentType(MediaType.APPLICATION_JSON_VALUE).
                        body(JsonFileUtil.readString("controller/service/update-user-req.json")).
                when().
                        request("PUT", Constants.REST_API_PATH_USER).
                then().
                        log().all()
                        .statusCode(424)
                        .body("Status", equalTo(1))
                        .body("Message", equalTo("FakeMessage"))
                        .body("Error", equalTo("FakeErrorMessage")).body("RequestId", equalTo("FakeRequestId"))
                        .body("timestamp", equalTo("2017-07-21T17:32:28Z"));
        }

        public void testUpdateUserStatus500() throws IOException, URISyntaxException {
                given().
                        header("requestId","1").header("Authorization", "token").
                        queryParam("userBncId", "1").
                        contentType(MediaType.APPLICATION_JSON_VALUE).
                        body(JsonFileUtil.readString("controller/service/update-user-req.json")).
                when().
                        request("PUT", Constants.REST_API_PATH_USER).
                then().
                        log().all()
                        .statusCode(500)
                        .body("Status", equalTo(1))
                        .body("Message", equalTo("FakeMessage"))
                        .body("Error", equalTo("FakeErrorMessage")).body("RequestId", equalTo("FakeRequestId"))
                        .body("timestamp", equalTo("2017-07-21T17:32:28Z"));
        }

        public void testDeleteUserSuccessfully() throws IOException {
                given().
                        header("requestId", "1").header("Authorization", "token").
                        queryParam("userBncId", "1").queryParam("userSysId", "2").queryParam("srcCd", "3").queryParam("relationshipId", "4").
                when().        
                        request("DELETE", Constants.REST_API_PATH_USER).
                then().
                        log().all()
                        .statusCode(204);
        }

        public void testDeleteUserStatus424() throws IOException {
                given().
                        header("requestId", "1").header("Authorization", "token").
                        queryParam("userBncId", "1").queryParam("userSysId", "2").queryParam("srcCd", "3").queryParam("relationshipId", "4").
                when().        
                        request("DELETE", Constants.REST_API_PATH_USER).
                then().
                        log().all()
                        .statusCode(424)
                        .body("Status", equalTo(1))
                        .body("Message", equalTo("FakeMessage"))
                        .body("Error", equalTo("FakeErrorMessage")).body("RequestId", equalTo("FakeRequestId"))
                        .body("timestamp", equalTo("2017-07-21T17:32:28Z"));
        }


        public void testDeleteUserStatus500() throws IOException {
                given().
                        header("requestId", "1").header("Authorization", "token").
                        queryParam("userBncId", "1").queryParam("userSysId", "2").queryParam("srcCd", "3").queryParam("relationshipId", "4").
                when().        
                        request("DELETE", Constants.REST_API_PATH_USER).
                then().
                        log().all()
                        .statusCode(500)
                        .body("Status", equalTo(1))
                        .body("Message", equalTo("FakeMessage"))
                        .body("Error", equalTo("FakeErrorMessage")).body("RequestId", equalTo("FakeRequestId"))
                        .body("timestamp", equalTo("2017-07-21T17:32:28Z"));
        }
}
