package ca.bnc.bne.individualapi.controller.service;

import java.io.IOException;
import java.net.URISyntaxException;

import ca.bnc.bne.individualapi.restassured.IndividualEventSbieScenarios;
import ca.bnc.bne.individualapi.restassured.IndividualServiceScenarios;
import ca.bnc.bne.individualapi.utils.JsonFileUtil;
import okhttp3.mockwebserver.MockResponse;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;


import io.restassured.RestAssured;
import okhttp3.mockwebserver.MockWebServer;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class IndividualServiceControllerTest {
    @LocalServerPort
    private int port;

    @Value("${mock.webserver.port}")
    private int mockServerPort;

    private MockWebServer mockWebServer;//Orchestrator

    private IndividualServiceScenarios restAssuredTests;

    @BeforeEach
    public  void setup() throws IOException {
        System.out.println("Setting up test");
        mockWebServer = new MockWebServer();
        mockWebServer.start(mockServerPort);

        RestAssured.baseURI = "http://localhost:" + this.port;
        restAssuredTests = new IndividualServiceScenarios();
    }

    @AfterEach
    void tearDown() throws IOException {
        System.out.println("Tearing down test");
        mockWebServer.shutdown();
    }

    @Test
    public void testAddAdminSuccessfully() throws IOException, URISyntaxException {
        specifyMocksAddAdminSuccessfully();
        restAssuredTests.testAddAdminSuccessfully();
    }

    @Test
    public void testAddAdminStatus424() throws IOException, URISyntaxException {
        specifyMocksStatus424();
        restAssuredTests.testAddAdminStatus424();
    }

    @Test
    public void testAddAdminStatus500() throws IOException, URISyntaxException {
        specifyMocksStatus500();
        restAssuredTests.testAddAdminStatus500();
    }

    @Test
    public void testAddUserSuccessfully() throws IOException, URISyntaxException {
        specifyMocksAddUserSuccessfully();
        restAssuredTests.testAddUserSuccessfully();
    }

    @Test
    public void testAddUserStatus424() throws IOException, URISyntaxException {
        specifyMocksStatus424();
        restAssuredTests.testAddUserStatus424();
    }

    @Test
    public void testAddUserStatus500() throws IOException, URISyntaxException {
        specifyMocksStatus500();
        restAssuredTests.testAddUserStatus500();
    }

    @Test
    public void testUpdateUserSuccessfully() throws IOException, URISyntaxException {
        specifyMocksUpdateUserSuccessfully();
        restAssuredTests.testUpdateUserSuccessfully();
    }    

    @Test
    public void testUpdateUserStatus424() throws IOException, URISyntaxException {
        specifyMocksStatus424();
        restAssuredTests.testUpdateUserStatus424();
    }

    @Test
    public void testUpdateUserStatus500() throws IOException, URISyntaxException {
        specifyMocksStatus500();
        restAssuredTests.testUpdateUserStatus500();
    }

    @Test
    public void testDeleteUserSuccessfully() throws IOException, URISyntaxException {
        specifyMocksDeleteUserSuccessfully();
        restAssuredTests.testDeleteUserSuccessfully();
    }    

    @Test
    public void testDeleteUserStatus424() throws IOException, URISyntaxException {
        specifyMocksStatus424();
        restAssuredTests.testDeleteUserStatus424();
    }

    @Test
    public void testDeleteUserStatus500() throws IOException, URISyntaxException {
        specifyMocksStatus500();
        restAssuredTests.testDeleteUserStatus500();
    }

    private void specifyMocksAddAdminSuccessfully() throws IOException, URISyntaxException {
        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(200)
                .addHeader("Content-Type", "application/json; charset=utf-8")
                .setBody(JsonFileUtil.readString("controller/service/add-admin-resp.json")));
    }

    private void specifyMocksAddUserSuccessfully() throws IOException, URISyntaxException {
        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(200)
                .addHeader("Content-Type", "application/json; charset=utf-8")
                .setBody(JsonFileUtil.readString("controller/service/add-user-resp.json")));
    }

    private void specifyMocksUpdateUserSuccessfully() throws IOException, URISyntaxException {
        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(200)
                .addHeader("Content-Type", "application/json; charset=utf-8")
                .setBody(JsonFileUtil.readString("controller/service/update-user-resp.json")));
    }

    private void specifyMocksDeleteUserSuccessfully() throws IOException, URISyntaxException {
        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(204));
    }

    private void specifyMocksStatus424() throws IOException, URISyntaxException {
        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(424)
                .addHeader("Content-Type", "application/json; charset=utf-8")
                .setBody(JsonFileUtil.readString("controller/service/individual-service-error-resp.json")));
    }

    private void specifyMocksStatus500() throws IOException, URISyntaxException {
        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(500)
                .addHeader("Content-Type", "application/json; charset=utf-8")
                .setBody(JsonFileUtil.readString("controller/service/individual-service-error-resp.json")));
    }
}

