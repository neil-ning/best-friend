package ca.bnc.bne.individualapi.exception.model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class GccErrorExceptionTest {

    @Mock
    private GccErrorException error;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void constructorTest(){
        error = new GccErrorException(200, "Test");
        assertEquals(200, error.getGccStatus());
    }



}