package ca.bnc.bne.individualapi.controller.event;

import ca.bnc.bne.gen.individual.IndividualRequest.EventBusinessObjectEnum;
import ca.bnc.bne.gen.individual.IndividualRequest.EventTechActionEnum;
import ca.bnc.bne.gen.individual.IndividualRequest.EventPtyActionEnum;
import ca.bnc.bne.gen.individual.IndividualResponse;
import ca.bnc.bne.individualapi.dto.TargetSystemResponse;
import ca.bnc.bne.individualapi.request.CreateTestRequest;
import static org.junit.jupiter.api.Assertions.*;

import ca.bnc.bne.individualapi.service.IndividualServiceGcc;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class IndividualControllerTest {


    @Spy
    public CreateTestRequest req ;

    @InjectMocks
    private IndividualController controller;

    @Mock
    private IndividualServiceGcc service;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void createRequestWithNull(){
        assertThrows(NullPointerException.class, () -> controller.create(TargetSystem.GCC.value, req.buildRequest(EventBusinessObjectEnum.BASEIND,EventPtyActionEnum.EDIT, EventTechActionEnum.CREATE, null, "716487614358761349")));
    }

    @Test
    public void updateRequestWithNull(){
        assertThrows(NullPointerException.class, () -> controller.update(TargetSystem.GCC.value, req.buildRequest(EventBusinessObjectEnum.BASEIND,EventPtyActionEnum.EDIT, EventTechActionEnum.UPDATE, null, "716487614358761349")));
    }

    @Test
    public void deleteRequestWithNull(){
        assertThrows(NullPointerException.class, () -> controller.delete(TargetSystem.GCC.value, req.buildRequest(EventBusinessObjectEnum.BASEIND,EventPtyActionEnum.EDIT, EventTechActionEnum.DELETE, null, "716487614358761349")));
    }

    @Test
    public void createRequestWithWrongAct(){
        assertThrows(IllegalArgumentException.class, () -> controller.create(TargetSystem.GCC.value, req.buildRequest(EventBusinessObjectEnum.BASEIND,EventPtyActionEnum.EDIT, EventTechActionEnum.DELETE, "414D5120554D534242303138202020205EA83E862D7D1D87", "716487614358761349")));
    }

    @Test
    public void updateRequestWithWrongAct(){
        assertThrows(IllegalArgumentException.class, () -> controller.update(TargetSystem.GCC.value, req.buildRequest(EventBusinessObjectEnum.BASEIND,EventPtyActionEnum.EDIT, EventTechActionEnum.CREATE, "414D5120554D534242303138202020205EA83E862D7D1D87", "716487614358761349")));
    }

    @Test
    public void deleteRequestWithWrongAct(){
        assertThrows(IllegalArgumentException.class, () -> controller.delete(TargetSystem.GCC.value, req.buildRequest(EventBusinessObjectEnum.BASEIND,EventPtyActionEnum.EDIT, EventTechActionEnum.UPDATE, "414D5120554D534242303138202020205EA83E862D7D1D87", "716487614358761349")));
    }

    @Test
    void createRequest_HappyPath() {
        when(service.invoke(any())).thenReturn(new TargetSystemResponse().setStatus(201));
        final ResponseEntity<IndividualResponse> response = controller.create(TargetSystem.GCC.value, req.buildRequest(EventBusinessObjectEnum.BASEIND,EventPtyActionEnum.EDIT, EventTechActionEnum.CREATE, null, "716487614358761349"));
        assertEquals(HttpStatus.CREATED,response.getStatusCode());
        assertEquals(201, response.getStatusCodeValue());
    }

    @Test
    void updateRequest_HappyPath() {
        when(service.invoke(any())).thenReturn(new TargetSystemResponse().setStatus(201));
        final ResponseEntity<IndividualResponse> response = controller.update(TargetSystem.GCC.value, req.buildRequest(EventBusinessObjectEnum.BASEIND,EventPtyActionEnum.EDIT, EventTechActionEnum.UPDATE, null, "716487614358761349"));
        assertEquals(HttpStatus.OK,response.getStatusCode());
        assertEquals(200, response.getStatusCodeValue());
    }

    @Test
    void deleteRequest_HappyPath() {
        when(service.invoke(any())).thenReturn(new TargetSystemResponse().setStatus(201));
        final ResponseEntity<IndividualResponse> response = controller.delete(TargetSystem.GCC.value, req.buildRequest(EventBusinessObjectEnum.BASEIND,EventPtyActionEnum.EDIT, EventTechActionEnum.DELETE, null, "716487614358761349"));
        assertEquals(HttpStatus.OK,response.getStatusCode());
        assertEquals(200, response.getStatusCodeValue());
    }

}
