package ca.bnc.bne.individualapi.repository.sbie.dao;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlConfig;

@SpringBootTest
@ActiveProfiles("dev")
public class ClientDaoSbieTest {
    @Autowired
    @Qualifier("ClientDaoSbie")
    ClientDao clientDao;
    
    @Test
    @Sql(scripts = {"classpath:sbie-schema-h2.sql",
            "classpath:sbie-data-h2.sql",
            "classpath:sbie-data-test-crud-h2.sql"},
            config = @SqlConfig(dataSource = "dataSourceSbie"))
    public void testInsert(){
        Client jack = new Client();
        jack.setName("jack");
        jack.setAge(41);
        Assertions.assertFalse(clientDao.exist(jack));

        int id = clientDao.create(jack); 
        Assertions.assertEquals(3, id);
        
        Client jackNew = new Client();
        jackNew.setId(id);
        jackNew.setName("jack");
        jackNew.setAge(41);
        Assertions.assertTrue(clientDao.exist(jackNew));

        Client jackRead = clientDao.read(id);
        Assertions.assertEquals(jackRead.getName(),"jack");
    }

    @Test
    @Sql(scripts = {"classpath:sbie-schema-h2.sql",
            "classpath:sbie-data-h2.sql",
            "classpath:sbie-data-test-crud-h2.sql"},
            config = @SqlConfig(dataSource = "dataSourceSbie"))
    public void testUpdate(){
        Client anna = clientDao.read(1);
        Assertions.assertEquals(anna.getName(), "anna");
        Assertions.assertEquals(anna.getAge(), 5);

        anna.setId(1);
        anna.setName("anna_new");
        anna.setAge(6);

        clientDao.update(anna);

        Client annaUpdate = clientDao.read(1);
        Assertions.assertEquals(annaUpdate.getName(), "anna_new");
        Assertions.assertEquals(annaUpdate.getAge(), 6);
    }

    @Test
    @Sql(scripts = {"classpath:sbie-schema-h2.sql",
            "classpath:sbie-data-h2.sql",
            "classpath:sbie-data-test-crud-h2.sql"},
            config = @SqlConfig(dataSource = "dataSourceSbie"))
    public void testUpdateNotExist(){
        Client tom = new Client();
        tom.setId(10);
        tom.setName("tom");
        tom.setAge(9);
        Assertions.assertFalse(clientDao.exist(tom));
        clientDao.update(tom);
        Assertions.assertFalse(clientDao.exist(tom)); 
    }

    @Test
    @Sql(scripts = {"classpath:sbie-schema-h2.sql",
            "classpath:sbie-data-h2.sql",
            "classpath:sbie-data-test-crud-h2.sql"},
            config = @SqlConfig(dataSource = "dataSourceSbie"))
    public void testDelete(){        
        Client anna = new Client();
        anna.setId(1);
        anna.setName("anna");
        anna.setAge(5);
        Assertions.assertTrue(clientDao.exist(anna));
        clientDao.delete(anna);
        Assertions.assertFalse(clientDao.exist(anna));
        
        Client brian = new Client();
        brian.setId(2);
        brian.setName("brian");
        brian.setAge(10);
        Assertions.assertTrue(clientDao.exist(brian));
        clientDao.delete(brian);
        Assertions.assertFalse(clientDao.exist(brian)); 
    }

    @Test
    @Sql(scripts = {"classpath:sbie-schema-h2.sql",
            "classpath:sbie-data-h2.sql",
            "classpath:sbie-data-test-crud-h2.sql"},
            config = @SqlConfig(dataSource = "dataSourceSbie"))
    public void testDeleteNotExist(){        
        Client tom = new Client();
        tom.setId(10);
        tom.setName("tom");
        tom.setAge(9);
        Assertions.assertFalse(clientDao.exist(tom));
        clientDao.delete(tom);
        Assertions.assertFalse(clientDao.exist(tom)); 
    }    
}
