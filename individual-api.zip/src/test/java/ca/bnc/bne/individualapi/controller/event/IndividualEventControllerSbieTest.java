package ca.bnc.bne.individualapi.controller.event;

import ca.bnc.bne.individualapi.restassured.IndividualEventSbieScenarios;
import ca.bnc.bne.individualapi.utils.JsonFileUtil;
import io.restassured.RestAssured;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlConfig;

import java.io.IOException;
import java.net.URISyntaxException;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("dev")
public class IndividualEventControllerSbieTest {
    @LocalServerPort
    private int port;

    private IndividualEventSbieScenarios restAssuredTests;

    @BeforeEach
    public void setup() throws IOException {
        RestAssured.baseURI = "http://localhost:" + this.port;
        restAssuredTests = new IndividualEventSbieScenarios();
    }

    @AfterEach
    void tearDown() throws IOException {
    }

    @Test
    @Sql(scripts = {"classpath:sbie-schema-h2.sql",
            "classpath:sbie-data-h2.sql",
            "classpath:sbie-data-test-crud-h2.sql",
            "classpath:sbie-schema-WEPROFUTIL.sql"},
            config = @SqlConfig(dataSource = "dataSourceSbie"))
    public void testAddAdminSuccessfully() throws IOException, URISyntaxException {
        restAssuredTests.testUpdateIndividualSuccessfully();
    }

    @Test
    @Sql(scripts = {"classpath:sbie-schema-h2.sql",
            "classpath:sbie-data-h2.sql",
            "classpath:sbie-data-test-crud-h2.sql",
            "classpath:sbie-schema-WEPROFUTIL.sql"},
            config = @SqlConfig(dataSource = "dataSourceSbie"))
    public void test_EDIT_UPDATE_BASEIND_with200() throws IOException, URISyntaxException {
        given().log().all().
                header("target-system", TargetSystem.SBIE.value).
                contentType(MediaType.APPLICATION_JSON_VALUE).
                body(JsonFileUtil.readString("controller/event/update-individual-req-wrong-action.json")).
                when().log().all().
                request("PUT", "/v1/individual").
                then().
                log().all()
                .statusCode(200)
                .body("code", equalTo(200));
    }
}

