package ca.bnc.bne.individualapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("dev")
public class IndividualApiApplicationTest {
    @Test
    void contextLoads() {
    }    
}
