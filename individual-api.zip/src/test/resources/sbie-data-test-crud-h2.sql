delete from CLIENT;

insert into CLIENT(id, name, age) values (1, 'anna',5);
insert into CLIENT(id, name, age) values (2, 'brian',10);