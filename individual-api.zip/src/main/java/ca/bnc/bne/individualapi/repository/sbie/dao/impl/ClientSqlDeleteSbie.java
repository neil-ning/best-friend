package ca.bnc.bne.individualapi.repository.sbie.dao.impl;

import java.sql.Types;
import javax.sql.DataSource;

import ca.bnc.bne.individualapi.repository.sbie.dao.Client;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.SqlUpdate;

public class ClientSqlDeleteSbie extends SqlUpdate{
    public ClientSqlDeleteSbie(final DataSource ds) {
         setDataSource(ds);
         setSql("delete from client where id = ?");
         declareParameter(new SqlParameter(Types.BIGINT));
         compile();
     }

     //return number of updated rows
     public int run(final Client client) {
         Object[] params =
             new Object[] {
                 client.getId()};
         return update(params);
     }
}
