package ca.bnc.bne.individualapi.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IndvReqDto {

    private String eventPtyAction;
    private String eventTechAction;
    private String eventBusinessObject;

    private String requestId = null;

    private String indBncId = null;

    private GeneralDto general = null;

    private ProfileDto profile = null;

    private OtherDto other = null;

    public IndvReqDto requestId(String requestId) {
        this.requestId = requestId;
        return this;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public IndvReqDto indBncId(String indBncId) {
        this.indBncId = indBncId;
        return this;
    }

    public String getIndBncId() {
        return indBncId;
    }

    public void setIndBncId(String indBncId) {
        this.indBncId = indBncId;
    }

    public IndvReqDto eventPtyAction(String eventPtyAction) {
        this.eventPtyAction = eventPtyAction;
        return this;
    }

    public String getEventPtyAction() {
        return eventPtyAction;
    }

    public void setEventPtyAction(String eventPtyAction) {
        this.eventPtyAction = eventPtyAction;
    }

    public IndvReqDto eventTechAction(String eventTechAction) {
        this.eventTechAction = eventTechAction;
        return this;
    }

    public String getEventTechAction() {
        return eventTechAction;
    }

    public void setEventTechAction(String eventTechAction) {
        this.eventTechAction = eventTechAction;
    }

    public IndvReqDto eventBusinessObject(String eventBusinessObject) {
        this.eventBusinessObject = eventBusinessObject;
        return this;
    }

    public String getEventBusinessObject() {
        return eventBusinessObject;
    }

    public void setEventBusinessObject(String eventBusinessObject) {
        this.eventBusinessObject = eventBusinessObject;
    }

    public IndvReqDto general(GeneralDto general) {
        this.general = general;
        return this;
    }

    public GeneralDto getGeneral() {
        return general;
    }

    public void setGeneral(GeneralDto general) {
        this.general = general;
    }

    public IndvReqDto profile(ProfileDto profile) {
        this.profile = profile;
        return this;
    }


    public ProfileDto getProfile() {
        return profile;
    }

    public void setProfile(ProfileDto profile) {
        this.profile = profile;
    }

    public IndvReqDto other(OtherDto other) {
        this.other = other;
        return this;
    }

    public OtherDto getOther() {
        return other;
    }

    public void setOther(OtherDto other) {
        this.other = other;
    }

}

