package ca.bnc.bne.individualapi.configuration;

import javax.sql.DataSource;

import com.zaxxer.hikari.HikariDataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.init.DataSourceInitializer;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;

@Configuration
public class DataSourceSbieConfiguration {

    @Bean("sbieDataSourceProperties")
    @ConfigurationProperties("sbie.datasource")
    public DataSourceProperties dataSourcePropertiesSbie() {
        return new DataSourceProperties();
    }

    @Bean("dataSourceSbie")
    //@ConfigurationProperties("sbie.datasource")
    public DataSource dataSourceSbie(@Qualifier("sbieDataSourceProperties")DataSourceProperties sbieDataSourceProperties) {
        return sbieDataSourceProperties
                .initializeDataSourceBuilder()
                .type(HikariDataSource.class)
                .build();
    }

    @Bean("dataSourceTransactionManagerSbie")
    DataSourceTransactionManager dataSourceTransactionManagerSbie(@Qualifier("dataSourceSbie")DataSource sbieDataSource) {
        DataSourceTransactionManager manager  = new DataSourceTransactionManager(sbieDataSource);
        return manager;
    }
    
    //@Profile("dev")
    //@Bean
    public DataSourceInitializer dataSourceInitializerDev(@Qualifier("dataSourceSbie")DataSource sbieDataSource) {
        ResourceDatabasePopulator resourceDatabasePopulator = new ResourceDatabasePopulator();
        resourceDatabasePopulator.addScript(new ClassPathResource("sbie-schema-h2.sql"));
        resourceDatabasePopulator.addScript(new ClassPathResource("sbie-data-h2.sql"));

        DataSourceInitializer dataSourceInitializer = new DataSourceInitializer();
        dataSourceInitializer.setDataSource(sbieDataSource);
        dataSourceInitializer.setDatabasePopulator(resourceDatabasePopulator);
        return dataSourceInitializer;
    }
}
