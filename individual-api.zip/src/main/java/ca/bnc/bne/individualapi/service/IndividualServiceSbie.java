package ca.bnc.bne.individualapi.service;

import ca.bnc.bne.gen.individual.IndividualRequest;
import ca.bnc.bne.individualapi.dto.IndvReqDto;
import ca.bnc.bne.individualapi.dto.TargetSystemResponse;
import ca.bnc.bne.individualapi.repository.sbie.SbieRepository;
import ca.bnc.bne.individualapi.repository.sbie.dao.Client;
import ca.bnc.bne.individualapi.repository.sbie.dao.ClientDao;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service
@Transactional
public class IndividualServiceSbie {
    private final ClientDao clientDao;

    private final SbieRepository sbieRepository;

    public IndividualServiceSbie(@Qualifier("ClientDaoSbie") ClientDao clientDao,
                                 SbieRepository sbieRepository) {
        this.clientDao = clientDao;
        this.sbieRepository = sbieRepository;
    }


    public TargetSystemResponse invoke(IndividualRequest request) {
        Client client = new Client();
        client.setId(Long.valueOf(request.getGeneral().getIndGccNbr()));
        client.setName("name");
        client.setAge(111);
        clientDao.update(client);


        TargetSystemResponse result = new TargetSystemResponse();
        result.setStatus(200);
        result.setTargetSystemId(request.getGeneral().getIndGccNbr());
        result.setMessage("message");

        return result;
    }

    public <T> T invoke(IndvReqDto request) {

        String operatorName = String.join("_", request.getEventPtyAction(),
                request.getEventTechAction(),
                request.getEventBusinessObject());

        return sbieRepository.invoke(operatorName, request);
    }
}
