package ca.bnc.bne.individualapi.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;

import java.util.Objects;

/**
 * Profile
 */
public class ProfileDto   {
  private String lastname = null;

  private String firstname = null;

  private String birthday = null;

  private String phone = null;

  private String email = null;

  private String cell = null;

  public String language;

  public String sex;


  public ProfileDto lastname(String lastname) {
    this.lastname = lastname;
    return this;
  }

  public String getLastname() {
    return lastname;
  }

  public void setLastname(String lastname) {
    this.lastname = lastname;
  }

  public ProfileDto firstname(String firstname) {
    this.firstname = firstname;
    return this;
  }

  public String getFirstname() {
    return firstname;
  }

  public void setFirstname(String firstname) {
    this.firstname = firstname;
  }

  public ProfileDto birthday(String birthday) {
    this.birthday = birthday;
    return this;
  }

  public String getBirthday() {
    return birthday;
  }

  public void setBirthday(String birthday) {
    this.birthday = birthday;
  }

  public ProfileDto phone(String phone) {
    this.phone = phone;
    return this;
  }

  public String getPhone() {
    return phone;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }

  public ProfileDto email(String email) {
    this.email = email;
    return this;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public ProfileDto cell(String cell) {
    this.cell = cell;
    return this;
  }

  public String getCell() {
    return cell;
  }

  public void setCell(String cell) {
    this.cell = cell;
  }

  public ProfileDto language(String language) {
    this.language = language;
    return this;
  }

  public String getLanguage() {
    return language;
  }

  public void setLanguage(String language) {
    this.language = language;
  }

  public ProfileDto sex(String sex) {
    this.sex = sex;
    return this;
  }

  public String getSex() {
    return sex;
  }

  public void setSex(String sex) {
    this.sex = sex;
  }

}

