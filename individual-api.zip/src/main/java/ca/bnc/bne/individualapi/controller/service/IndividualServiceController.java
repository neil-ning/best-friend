package ca.bnc.bne.individualapi.controller.service;

import java.util.Map;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import ca.bnc.bne.gen.individual.AddIndividualResponse;
import ca.bnc.bne.gen.individual.CreateIndividualRequest;
import ca.bnc.bne.gen.individual.IndividualAdminResponse;
import ca.bnc.bne.gen.individual.UpdateIndividualRequest;
import ca.bnc.bne.gen.individual.UpdateIndividualResponse;
import ca.bnc.bne.individualapi.orchestrator.OrchestratorClient;
import ca.bnc.bne.individualapi.utils.Constants;


@RestController
public class IndividualServiceController {

    @Autowired
    private OrchestratorClient orchestrator;

    @ResponseStatus(HttpStatus.OK)
    @PatchMapping(value = Constants.REST_API_PATH_ADMIN, produces = {MediaType.APPLICATION_JSON_VALUE})
    public IndividualAdminResponse addAdmin(
            @RequestParam @Valid String orgBncId,
            @RequestParam @Valid String adminBncId,
            @RequestParam @Valid String sysId,
            @RequestParam @Valid String srcCd,
            @RequestHeader(required = false) @Valid String requestId,
            @RequestHeader(required = true) @Valid String Authorization) {
        final String requestIdAssigned = StringUtils.isEmpty(requestId) ? UUID.randomUUID().toString() : requestId;        
        return orchestrator.addAdmin(
                Map.of("orgBncId",orgBncId,"adminBncId", adminBncId,"sysId",sysId,"srcCd",srcCd),
                Map.of("requestId",requestIdAssigned, "Authorization", Authorization));
    }

    @ResponseStatus(HttpStatus.CREATED)
    @PostMapping(value = Constants.REST_API_PATH_USER, consumes = {MediaType.APPLICATION_JSON_VALUE}
    , produces = {MediaType.APPLICATION_JSON_VALUE})
    public AddIndividualResponse addUser(
            @RequestBody @Valid CreateIndividualRequest createIndividualRequest,
            @RequestParam @Valid String orgBncId,
            @RequestHeader(required = false) @Valid String requestId,
            @RequestHeader(required = true) @Valid String Authorization) {
        final String requestIdAssigned = StringUtils.isEmpty(requestId) ? UUID.randomUUID().toString() : requestId;         
        return orchestrator.addUser(
            Map.of("orgBncId",orgBncId), 
            Map.of("requestId", requestIdAssigned, "Authorization", Authorization), 
            createIndividualRequest);
    }

    @ResponseStatus(HttpStatus.OK)
    @PutMapping(value = Constants.REST_API_PATH_USER, consumes = {MediaType.APPLICATION_JSON_VALUE}
            , produces = {MediaType.APPLICATION_JSON_VALUE})
    public UpdateIndividualResponse updateUser(
            @RequestParam @Valid String userBncId,
            @RequestBody @Valid UpdateIndividualRequest updateIndividualRequest,
            @RequestHeader(required = false) @Valid String requestId,
            @RequestHeader(required = true) @Valid String Authorization) { 
        final String requestIdAssigned = StringUtils.isEmpty(requestId) ? UUID.randomUUID().toString() : requestId;
        return orchestrator.updateIndividual(
            Map.of("userBncId", userBncId), 
            Map.of("requestId", requestIdAssigned, "Authorization", Authorization), 
            updateIndividualRequest);
    }

    @ResponseStatus(HttpStatus.NO_CONTENT)
    @DeleteMapping(value = Constants.REST_API_PATH_USER, produces = {MediaType.APPLICATION_JSON_VALUE})
    public void deleteUser(
            @RequestParam @Valid String userBncId,
            @RequestParam @Valid String userSysId,
            @RequestParam @Valid String srcCd,
            @RequestParam @Valid String relationshipId,
            @RequestHeader(required = false) @Valid String requestId,
            @RequestHeader(required = true) @Valid String Authorization) {
        final String requestIdAssigned = StringUtils.isEmpty(requestId) ? UUID.randomUUID().toString() : requestId;
        orchestrator.deleteUser(
            Map.of("userBncId",userBncId,"userSysId",userSysId,"srcCd",srcCd,"relationshipId", relationshipId), 
            Map.of("requestId", requestIdAssigned, "Authorization", Authorization));
    }
}