package ca.bnc.bne.individualapi.exception.model;

public class GccErrorException extends RuntimeException {

    private int gccStatus;

    public GccErrorException(int status, String message) {
        super(message);
        this.gccStatus = status;
    }

//    public GccErrorException(String message, Throwable cause) { super(message, cause); }
//
//    public GccErrorException(Throwable cause) { super(cause); }

    public int getGccStatus() { return gccStatus; }
}
