package ca.bnc.bne.individualapi.dto;

/**
 * Other
 */
public class OtherDto {
    private String identificationType1 = null;

    private String identificationValue1 = null;

    private String identificationType2 = null;

    private String identificationValue2 = null;

    public OtherDto identificationType1(String identificationType1) {
        this.identificationType1 = identificationType1;
        return this;
    }

    public String getIdentificationType1() {
        return identificationType1;
    }

    public void setIdentificationType1(String identificationType1) {
        this.identificationType1 = identificationType1;
    }

    public OtherDto identificationValue1(String identificationValue1) {
        this.identificationValue1 = identificationValue1;
        return this;
    }

    public String getIdentificationValue1() {
        return identificationValue1;
    }

    public void setIdentificationValue1(String identificationValue1) {
        this.identificationValue1 = identificationValue1;
    }

    public OtherDto identificationType2(String identificationType2) {
        this.identificationType2 = identificationType2;
        return this;
    }

    public String getIdentificationType2() {
        return identificationType2;
    }

    public void setIdentificationType2(String identificationType2) {
        this.identificationType2 = identificationType2;
    }

    public OtherDto identificationValue2(String identificationValue2) {
        this.identificationValue2 = identificationValue2;
        return this;
    }

    public String getIdentificationValue2() {
        return identificationValue2;
    }

    public void setIdentificationValue2(String identificationValue2) {
        this.identificationValue2 = identificationValue2;
    }

}

