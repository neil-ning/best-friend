package ca.bnc.bne.individualapi.controller.event;

import ca.bnc.bne.gen.individual.General;
import ca.bnc.bne.gen.individual.IndividualRequest;
import ca.bnc.bne.gen.individual.IndividualResponse;
import ca.bnc.bne.gen.individual.Other;
import ca.bnc.bne.gen.individual.Profile;
import ca.bnc.bne.individualapi.dto.GeneralDto;
import ca.bnc.bne.individualapi.dto.IndvReqDto;
import ca.bnc.bne.individualapi.dto.OtherDto;
import ca.bnc.bne.individualapi.dto.ProfileDto;
import ca.bnc.bne.individualapi.dto.TargetSystemResponse;
import ca.bnc.bne.individualapi.repository.sbie.SbieRepository;
import ca.bnc.bne.individualapi.service.IndividualServiceGcc;
import ca.bnc.bne.individualapi.service.IndividualServiceSbie;
import org.springframework.beans.BeanUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequestMapping("/v1/individual")
public class IndividualController {
    public static final String HERDER_TARGET_SYSTEM = "target-system";
    private final IndividualServiceGcc individualServiceGcc;
    private final IndividualServiceSbie individualServiceSbie;

    private final SbieRepository sbieRepository;

    public IndividualController(IndividualServiceGcc individualServiceGcc
            , IndividualServiceSbie individualServiceSbie,
                                SbieRepository sbieRepository) {
        this.individualServiceGcc = individualServiceGcc;
        this.individualServiceSbie = individualServiceSbie;
        this.sbieRepository = sbieRepository;
    }

    /**
     * Add new Date from MCP to store procedure
     *
     * @param request
     * @return
     */
    @ResponseStatus(HttpStatus.CREATED)
    @PostMapping(
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<IndividualResponse> create(@RequestHeader(HERDER_TARGET_SYSTEM) @Valid String target, @Valid @RequestBody IndividualRequest request) {
        if (request.getEventTechAction() != IndividualRequest.EventTechActionEnum.CREATE) {
            throw new IllegalArgumentException();
        }
        return invokeService(target, request, HttpStatus.CREATED);
    }

    /**
     * update data from MCP to GCC store procedure
     *
     * @param request
     * @return
     */
    @PutMapping(
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<IndividualResponse> update(@RequestHeader(HERDER_TARGET_SYSTEM) @Valid String target, @Valid @RequestBody IndividualRequest request) {
        if (request.getEventTechAction() != IndividualRequest.EventTechActionEnum.UPDATE) {
            throw new IllegalArgumentException();
        }
        return invokeService(target, request, HttpStatus.OK);
    }

    /**
     * Delete from GCC store procedure
     *
     * @param request
     * @return
     */
    @DeleteMapping(
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<IndividualResponse> delete(@RequestHeader(HERDER_TARGET_SYSTEM) @Valid String target, @Valid @RequestBody IndividualRequest request) {
        if (request.getEventTechAction() != IndividualRequest.EventTechActionEnum.DELETE) {
            throw new IllegalArgumentException();
        }
        return invokeService(target, request, HttpStatus.OK);
    }

    private ResponseEntity<IndividualResponse> invokeService(String target, IndividualRequest request, HttpStatus resultStatus) {
        if (target.equals(TargetSystem.GCC.value)) {
            final TargetSystemResponse serviceResp = individualServiceGcc.invoke(request);
            return ResponseEntity.status(resultStatus).body(new IndividualResponse().code(serviceResp.getStatus()).message(serviceResp.getTargetSystemId()));
        } else if (target.equals(TargetSystem.SBIE.value)) {

            ResponseEntity responseEntity = null;

            Object o = individualServiceSbie.invoke(convert2Dto(request));

            if(o == null){
                responseEntity = ResponseEntity.ok(new IndividualResponse().code(200)
                        .message("Sorry, we did nothing!"));
                return responseEntity;
            }

            responseEntity = ResponseEntity.ok(new IndividualResponse().code(200)
                    .message(o.toString()));

            return responseEntity;
        } else
            throw new IllegalArgumentException("GCC/SBIE only for target system");
    }

    private IndvReqDto convert2Dto(IndividualRequest req) {

        General general = req.getGeneral();
        GeneralDto generalDto = new GeneralDto();
        BeanUtils.copyProperties(general, generalDto);

        Profile profile = req.getProfile();
        ProfileDto profileDto = new ProfileDto();
        BeanUtils.copyProperties(profile, profileDto);

        Other other = req.getOther();
        OtherDto otherDto = new OtherDto();
        BeanUtils.copyProperties(other, otherDto);

        IndvReqDto indvReqDto = new IndvReqDto()
                .requestId(req.getRequestId())
                .indBncId(req.getIndBncId())
                .eventPtyAction(req.getEventPtyAction().toString())
                .eventTechAction(req.getEventTechAction().toString())
                .eventBusinessObject(req.getEventBusinessObject().toString())
                .general(generalDto)
                .profile(profileDto)
                .other(otherDto);

        return indvReqDto;
    }
}
