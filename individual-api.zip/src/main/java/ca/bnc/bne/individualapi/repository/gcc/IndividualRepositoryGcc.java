package ca.bnc.bne.individualapi.repository.gcc;

import ca.bnc.bne.gen.individual.IndividualRequest;
import ca.bnc.bne.individualapi.dto.TargetSystemResponse;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import java.sql.Types;
import java.util.LinkedHashMap;
import java.util.Map;

@Repository
@ConfigurationProperties("gcc")
public class IndividualRepositoryGcc {

    private final JdbcTemplate jdbcTemplate;
    private String storedProcedureName = "usp_MCP_AddModifyIndividual";

    public IndividualRepositoryGcc(@Qualifier("jdbcTemplateGcc") JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * Sends the request to GCC store procedure
     *
     * @param request
     * @return
     */
    public TargetSystemResponse invokeGccStoredProcedure(IndividualRequest request) {
        SimpleJdbcCall simpleJdbcCall = simpleJdbcCall(inputParameters(request), outputParameter());
        Map<String, Object> execute = simpleJdbcCall.execute(mapSqlParameterSource(inputParameters(request)));
        return new TargetSystemResponse()
                .setTargetSystemId((String) execute.get("gccNbr"))
                .setMessage((String) execute.get("message"))
                .setRequestId((String) execute.get("requestId"))
                .setStatus(Integer.valueOf((String)execute.get("status")));
    }


    /**
     * Map sql parameter Source
     *
     * @param params
     * @return
     */
    protected MapSqlParameterSource mapSqlParameterSource(Map<String, ParameterWrapper> params) {
        MapSqlParameterSource parameterSource = new MapSqlParameterSource();
        params.forEach((key, value) -> parameterSource.addValue(key, value.getValue()));
        return parameterSource;
    }

    /**
     * Simple JDBC call
     *
     * @param in
     * @param out
     * @return
     */
    protected SimpleJdbcCall simpleJdbcCall(Map<String, ParameterWrapper> in, Map<String, ParameterWrapper> out) {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
                        .withoutProcedureColumnMetaDataAccess()
                        .withProcedureName(storedProcedureName);
        in.forEach((key, value) -> simpleJdbcCall.declareParameters(new SqlParameter(key, value.getSqlType())));
        out.forEach((key, value) -> simpleJdbcCall.declareParameters(new SqlOutParameter(key, value.getSqlType())));
        return simpleJdbcCall;
    }

    /**
     * Input parameters for GCC
     *
     * @param r
     * @return
     */
    protected Map<String, ParameterWrapper> inputParameters(IndividualRequest r) {
        LinkedHashMap<String, ParameterWrapper> map = new LinkedHashMap<>();
        map.put("RequestId", new ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getRequestId()));
        map.put("OrgGccNbr", new ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getGeneral().getOrgGccNbr()));
        map.put("IndGccNbr", new ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getGeneral().getIndGccNbr()));
        map.put("OrgBncId", new ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getGeneral().getOrgBncId()));
        map.put("IndBncId", new ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getIndBncId()));
        map.put("NewIndBncId", new ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getGeneral().getNewIndBncId()));
        map.put("EventPtyAction", new ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getEventPtyAction().toString()));
        map.put("EventTechAction", new ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getEventPtyAction().toString()));
        map.put("EventBusinessObject", new ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getEventBusinessObject().toString()));
        map.put("Lastname", new ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getProfile().getLastname()));
        map.put("Firstname", new ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getProfile().getFirstname()));
        map.put("Birthday", new ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getProfile().getBirthday()));
        map.put("Phone", new ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getProfile().getPhone()));
        map.put("Email", new ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getProfile().getEmail()));
        map.put("Cell", new ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getProfile().getCell()));
        map.put("IdentificationType1", new ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getOther().getIdentificationType1()));
        map.put("IdentificationValue1", new ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getOther().getIdentificationValue1()));
        map.put("IdentificationType2", new ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getOther().getIdentificationType2()));
        map.put("IdentificationValue2", new ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getOther().getIdentificationValue2()));
        map.put("Language", new ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getProfile().getLanguage().toString()));
        map.put("Sex", new ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getProfile().getSex().toString()));
        return map;
    }

    /**
     * Output parameters from GCC
     *
     * @return
     */
    protected Map<String, ParameterWrapper> outputParameter() {
        LinkedHashMap<String, ParameterWrapper> map = new LinkedHashMap<>();
        map.put("status", new ParameterWrapper().setSqlType(Types.VARCHAR));
        map.put("message", new ParameterWrapper().setSqlType(Types.VARCHAR));
        map.put("gccNbr", new ParameterWrapper().setSqlType(Types.VARCHAR));
        map.put("RequestIdReturn", new ParameterWrapper().setSqlType(Types.VARCHAR));
        return map;
    }


    protected static class ParameterWrapper {
        private int sqlType;
        private Object value;

        public int getSqlType() {
            return sqlType;
        }

        public Object getValue() {
            return value;
        }

        public ParameterWrapper setSqlType(int sqlType) {
            this.sqlType = sqlType;
            return this;
        }

        public ParameterWrapper setValue(Object value) {
            this.value = value;
            return this;
        }
    }
}
