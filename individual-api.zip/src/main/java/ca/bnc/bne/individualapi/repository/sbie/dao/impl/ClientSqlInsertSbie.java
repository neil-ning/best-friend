package ca.bnc.bne.individualapi.repository.sbie.dao.impl;

import java.sql.Types;
import javax.sql.DataSource;

import ca.bnc.bne.individualapi.repository.sbie.dao.Client;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

public class ClientSqlInsertSbie extends SqlUpdate {
    public ClientSqlInsertSbie(final DataSource ds) {
        setDataSource(ds);
        setSql("insert into client(name,age) values(?,?)");
        declareParameter(new SqlParameter(Types.VARCHAR));
        declareParameter(new SqlParameter(Types.INTEGER));
        setReturnGeneratedKeys(true);
        setGeneratedKeysColumnNames(new String[] {"id"});//Assumeing auto-generated column is named "id" 
        compile();
    }

    public int run(final Client client) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        Object[] params = new Object[] { client.getName(), client.getAge()};
        update(params, keyHolder);
        return keyHolder.getKey().intValue();//Returning auto-generated column "id"
    }
}
