package ca.bnc.bne.individualapi.utils;

public class Constants {
    public static final String REST_API_PATH_ADMIN = "/v1/individual/admin";//Aligned with Swagger definition
    public static final String REST_API_PATH_USER = "/v1/individual/user";//Aligned with Swagger definition    
}
