package ca.bnc.bne.individualapi.dto;

/**
 * General
 */
public class GeneralDto {
    private String orgGccNbr = null;

    private String indGccNbr = null;

    private String orgBncId = null;

    private String newIndBncId = null;

    public GeneralDto orgGccNbr(String orgGccNbr) {
        this.orgGccNbr = orgGccNbr;
        return this;
    }

    public String getOrgGccNbr() {
        return orgGccNbr;
    }

    public void setOrgGccNbr(String orgGccNbr) {
        this.orgGccNbr = orgGccNbr;
    }

    public GeneralDto indGccNbr(String indGccNbr) {
        this.indGccNbr = indGccNbr;
        return this;
    }

    public String getIndGccNbr() {
        return indGccNbr;
    }

    public void setIndGccNbr(String indGccNbr) {
        this.indGccNbr = indGccNbr;
    }

    public GeneralDto orgBncId(String orgBncId) {
        this.orgBncId = orgBncId;
        return this;
    }

    public String getOrgBncId() {
        return orgBncId;
    }

    public void setOrgBncId(String orgBncId) {
        this.orgBncId = orgBncId;
    }

    public GeneralDto newIndBncId(String newIndBncId) {
        this.newIndBncId = newIndBncId;
        return this;
    }

    public String getNewIndBncId() {
        return newIndBncId;
    }

    public void setNewIndBncId(String newIndBncId) {
        this.newIndBncId = newIndBncId;
    }

}

