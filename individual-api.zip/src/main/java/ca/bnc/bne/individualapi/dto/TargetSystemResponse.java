package ca.bnc.bne.individualapi.dto;


public class TargetSystemResponse {

    private int status;
    private String message;
    private String targetSystemId;
    private String requestId;

    public TargetSystemResponse() {
    }

    public int getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public String getTargetSystemId() {
        return targetSystemId;
    }

    public String getRequestId() {
        return requestId;
    }

    public TargetSystemResponse setStatus(int status) {
        this.status = status;
        return this;
    }

    public TargetSystemResponse setMessage(String message) {
        this.message = message;
        return this;
    }

    public TargetSystemResponse setTargetSystemId(String targetSystemId) {
        this.targetSystemId = targetSystemId;
        return this;
    }

    public TargetSystemResponse setRequestId(String requestId) {
        this.requestId = requestId;
        return this;
    }
}
