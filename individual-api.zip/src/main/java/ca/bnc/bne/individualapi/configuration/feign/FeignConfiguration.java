package ca.bnc.bne.individualapi.configuration.feign;

import feign.Logger;
import feign.codec.Decoder;
import feign.codec.Encoder;
import feign.codec.ErrorDecoder;
import okhttp3.OkHttpClient;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.cloud.openfeign.support.ResponseEntityDecoder;
import org.springframework.cloud.openfeign.support.SpringDecoder;
import org.springframework.cloud.openfeign.support.SpringEncoder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableFeignClients
public class FeignConfiguration {
  @Bean
  public Decoder decoder(ObjectFactory<HttpMessageConverters> converters) {
    return new ResponseEntityDecoder(new SpringDecoder(converters));
  }

  @Bean
  public Encoder encoder(ObjectFactory<HttpMessageConverters> converters) {
    return new SpringEncoder(converters);
  }

  @Bean(name = "feignOkHttpClient")
  public feign.okhttp.OkHttpClient okHttpClient(OkHttpClient okHttpClient) {
    return new feign.okhttp.OkHttpClient(okHttpClient);
  }

  @Bean
  public Logger.Level feignLoggerLevel() {
    return Logger.Level.FULL;
  }

  @Bean
  @ConditionalOnMissingBean
  public ErrorDecoder errorDecoder(FeignErrorDecoder errorDecoder) {
    return errorDecoder;
  }
}
