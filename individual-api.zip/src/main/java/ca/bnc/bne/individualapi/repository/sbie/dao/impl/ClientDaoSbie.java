package ca.bnc.bne.individualapi.repository.sbie.dao.impl;

import javax.sql.DataSource;

import ca.bnc.bne.individualapi.repository.sbie.dao.ClientDao;
import ca.bnc.bne.individualapi.repository.sbie.dao.Client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("ClientDaoSbie")
public class ClientDaoSbie implements ClientDao {
    private final ClientSqlReadSbie sqlRead;
    private final ClientSqlInsertSbie sqlInsert;
    private final ClientSqlUpdateSbie sqlUpdate;
    private final ClientSqlDeleteSbie sqlDelete;
    private final ClientSqlCountSbie sqlCount;

    @Autowired
    ClientDaoSbie(final @Qualifier("dataSourceSbie") DataSource ds) {
        sqlRead = new ClientSqlReadSbie(ds);
        sqlInsert = new ClientSqlInsertSbie(ds);
        sqlUpdate = new ClientSqlUpdateSbie(ds);
        sqlDelete = new ClientSqlDeleteSbie(ds);
        sqlCount = new ClientSqlCountSbie(ds);
    }

    @Override
    public Client read(long id){
        return sqlRead.execute(id).get(0);
    }

    @Override
    public int create(Client client) {
        return sqlInsert.run(client);
    }

    @Override
    public void update(Client client) {
        sqlUpdate.run(client);

    }

    @Override
    public void delete(Client client) {
        sqlDelete.run(client);
    }

    @Override
    public boolean exist(Client client) {
        return sqlCount.run(client) != 0;
    }
}