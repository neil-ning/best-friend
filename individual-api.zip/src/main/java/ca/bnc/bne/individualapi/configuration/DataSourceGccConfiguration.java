package ca.bnc.bne.individualapi.configuration;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;

import com.zaxxer.hikari.HikariDataSource;

@Configuration
public class DataSourceGccConfiguration {
    @Bean("gccDataSourceProperties")
    @Primary
    @ConfigurationProperties("gcc.datasource")
    public DataSourceProperties dataSourcePropertiesGcc() {
        return new DataSourceProperties();
    }

    @Bean("gccDatasource")
    @Primary
    //@ConfigurationProperties("gcc.datasource")
    public DataSource dataSourceGcc(@Qualifier("gccDataSourceProperties")DataSourceProperties gccDataSourceProperties) {
        return gccDataSourceProperties
                .initializeDataSourceBuilder()
                .type(HikariDataSource.class)
                .build();
    }
    
    @Bean
    @Primary
    public JdbcTemplate jdbcTemplateGcc(@Qualifier("gccDatasource")DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }
}
