package ca.bnc.bne.individualapi.controller.event;

public enum TargetSystem {
    GCC("GCC"),        
    SBIE("SBIE");

    public String value;

    TargetSystem(String value) {
      this.value = value;
    }
}
