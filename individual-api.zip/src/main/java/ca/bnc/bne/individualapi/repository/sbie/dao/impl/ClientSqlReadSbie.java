package ca.bnc.bne.individualapi.repository.sbie.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import javax.sql.DataSource;

import ca.bnc.bne.individualapi.repository.sbie.dao.Client;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.MappingSqlQuery;

public class ClientSqlReadSbie extends MappingSqlQuery<Client> {
    public ClientSqlReadSbie(final DataSource ds) {
        setDataSource(ds);
        setSql("select id, name, age from client where id = ?");
        declareParameter(new SqlParameter("id", Types.BIGINT));
        compile();
    }

    @Override
    protected Client mapRow(ResultSet rs, int rowNum) throws SQLException {
        Client result = new Client();
        result.setId(((Long) rs.getObject("id")).longValue());
        result.setAge((Integer) rs.getObject("age"));
        result.setName(rs.getString("name"));

        return result;
    }
}
