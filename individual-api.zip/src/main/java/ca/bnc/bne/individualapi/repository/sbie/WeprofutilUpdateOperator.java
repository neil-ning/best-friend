package ca.bnc.bne.individualapi.repository.sbie;

import ca.bnc.bne.individualapi.dto.IndvReqDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;

@Repository("EDIT_UPDATE_BASEIND")
public class WeprofutilUpdateOperator
        implements TableDataOperator<IndvReqDto, TbWeprofcl, Integer> {

    private static final Logger LOGGER = LoggerFactory.getLogger(WeprofutilUpdateOperator.class);

    private SqlUpdate updateBncId;

    public WeprofutilUpdateOperator(@Qualifier("dataSourceSbie") final DataSource ds) {
        updateBncId = new SqlUpdate();
        updateBncId.setDataSource(ds);
        updateBncId.setSql("update TB_WEPROFUTIL set WEN_UTBNCID = ? where WENIUB_UT = ? limit 1");
        updateBncId.declareParameter(new SqlParameter(Types.VARCHAR));
        updateBncId.declareParameter(new SqlParameter(Types.BIGINT));
        updateBncId.compile();
    }

    @Override
    public Integer operate(TbWeprofcl wep) {
        LOGGER.info("processing update table TB_WEPROFUTIL with WEN_UTBNCID:[{}], WENIUB_UT:[{}]",
                wep.getWenUtbncid(), wep.getWeniubUt());

        Object[] params =
                new Object[]{
                        wep.getWenUtbncid(),
                        wep.getWeniubUt()};
        return updateBncId.update(params);
    }

    public TbWeprofcl convertDtoToDomain(IndvReqDto req) {
        return new TbWeprofcl().weniubUt(Long.valueOf(req.getGeneral().getIndGccNbr()))
                .wenUtbncid(req.getIndBncId());
    }

}
