package ca.bnc.bne.individualapi.restassured;

import java.io.IOException;
import java.net.URISyntaxException;

import org.springframework.http.MediaType;

import ca.bnc.bne.individualapi.controller.event.TargetSystem;
import ca.bnc.bne.individualapi.utils.JsonFileUtil;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;


/**
 * Business scenarios specified in Rest Assured
 */
public class IndividualEventSbieScenarios {
        public static final String API_PATH = "/v1/individual";

        public void testUpdateIndividualSuccessfully() throws IOException, URISyntaxException {
                given().
                        header("target-system",TargetSystem.SBIE.value).
                        contentType(MediaType.APPLICATION_JSON_VALUE).
                        body(JsonFileUtil.readString("controller/event/update-individual-req.json")).
                when().
                        request("PUT", API_PATH).
                then().
                        log().all()
                        .statusCode(200)
                        .body("code", equalTo(200))
                        .body("message", equalTo("1"));
        }
}
