package ca.bnc.bne.individualapi.request;

import ca.bnc.bne.gen.individual.General;
import ca.bnc.bne.gen.individual.IndividualRequest;
import ca.bnc.bne.gen.individual.Other;
import ca.bnc.bne.gen.individual.Profile;
import ca.bnc.bne.individualapi.dto.TargetSystemResponse;
import org.springframework.stereotype.Component;

@Component
public class CreateTestRequest {

    public IndividualRequest buildRequest(IndividualRequest.EventBusinessObjectEnum ebo, IndividualRequest.EventPtyActionEnum epa, IndividualRequest.EventTechActionEnum eta, String reqId, String IndBncId) {
        IndividualRequest individualRequest = new IndividualRequest();
        individualRequest.setEventBusinessObject(ebo);
        individualRequest.setEventPtyAction(epa);
        individualRequest.setEventTechAction(eta);
        individualRequest.setRequestId(reqId);
        individualRequest.setIndBncId(IndBncId);
        return individualRequest;
    }

    public IndividualRequest buildFullRequest(IndividualRequest.EventBusinessObjectEnum ebo, IndividualRequest.EventPtyActionEnum epa,
                                               IndividualRequest.EventTechActionEnum eta, String reqId, String IndBncId , Profile p, General g, Other o) {
        IndividualRequest individualRequest = new IndividualRequest();
        individualRequest.setEventBusinessObject(ebo);
        individualRequest.setEventPtyAction(epa);
        individualRequest.setEventTechAction(eta);
        individualRequest.setRequestId(reqId);
        individualRequest.setIndBncId(IndBncId);
        individualRequest.setProfile(p);
        individualRequest.setGeneral(g);
        individualRequest.setOther(o);
        return individualRequest;
    }


    public IndividualRequest newRequest(){
        return buildRequest(
                IndividualRequest.EventBusinessObjectEnum.BASEIND,
                IndividualRequest.EventPtyActionEnum.EDIT,
                IndividualRequest.EventTechActionEnum.CREATE,
                "414D5120554D534242303138202020205EA83E862D7D1D87",
                "716487614358761349"
        );
    }

    public IndividualRequest newFullwRequest(){
        return buildFullRequest(
                IndividualRequest.EventBusinessObjectEnum.BASEIND,
                IndividualRequest.EventPtyActionEnum.EDIT,
                IndividualRequest.EventTechActionEnum.CREATE,
                "414D5120554D534242303138202020205EA83E862D7D1D87",
                "716487614358761349",
               new Profile().lastname("").email("").firstname("").language(Profile.LanguageEnum.EN).phone("").sex(Profile.SexEnum._1),
               new General().orgGccNbr("").orgBncId(""),
                new Other().identificationType1("")
        );
    }

    public TargetSystemResponse newResponse(){
        return new TargetSystemResponse().setRequestId("414D5120554D534242303138202020205EA83E862D7D1D87")
                .setMessage("Success").setTargetSystemId("12345").setStatus(200);
    }
}
