package ca.bnc.bne.individualapi.integration;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlConfig;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.testcontainers.containers.MSSQLServerContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import ca.bnc.bne.individualapi.controller.event.TargetSystem;

import ca.bnc.bne.individualapi.controller.event.IndividualEventController;

@Disabled("Run it when the docker container is available")
@Testcontainers
@AutoConfigureMockMvc
@ActiveProfiles("container")
@TestMethodOrder(OrderAnnotation.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class IndividualIntegrationTest {

  @Container
  public static MSSQLServerContainer mssqlServerContainer =
      new MSSQLServerContainer("mcr.microsoft.com/mssql/server:2017-CU12").acceptLicense();

  @Autowired private MockMvc mockMvc;

  @DynamicPropertySource
  static void mssqlProperties(DynamicPropertyRegistry registry) {
    registry.add("gcc.datasource.url", mssqlServerContainer::getJdbcUrl);
    registry.add("gcc.datasource.password", mssqlServerContainer::getPassword);
    registry.add("gcc.datasource.username", mssqlServerContainer::getUsername);
  }

  @Test
  @Sql(scripts = {"classpath:storedProcedure.sql"}, config = @SqlConfig(dataSource = "dataSourceGcc", transactionManager = "transactionManagerGcc"))
  @Order(1)
  public void testCreateIndividual() throws Exception {
    String input =
        "{\"RequestId\":\"414D5120554D534242303138202020205EA83E862D7D1D87\",\"IndBncId\":\"200\",\"EventPtyAction\":\"EDIT\",\"EventTechAction\":\"CREATE\",\"EventBusinessObject\":\"BASEIND\",\"General\":{\"OrgGccNbr\":\"testOrgGcc\",\"IndGccNbr\":\"testIndGcc\",\"OrgBncId\":\"01603866C185640E83882CF387AABD18114A13D938B941C5646E24E824675930\",\"NewIndBncId\":\"testNewIndBnc\"},\"Profile\":{\"Lastname\":\"Williams\",\"Firstname\":\"Liam\",\"Birthday\":\"string\",\"Phone\":\"9057689354\",\"Email\":\"liam@gmail.com\",\"Cell\":\"4673567263\",\"Language\":\"EN\",\"Sex\":\"0\"},\"Other\":{\"IdentificationType1\":\"BELL - bellIdent012345\",\"IdentificationValue1\":\"BELL - bellIdent012345\",\"IdentificationType2\":\"BELL - bellIdent012345\",\"IdentificationValue2\":\"BELL - bellIdent012345\"}}";
    mockMvc
        .perform(post("/v1/individual")
                  .header(IndividualEventController.HERDER_TARGET_SYSTEM, TargetSystem.GCC.value)
                  .content(input)
                  .contentType(MediaType.APPLICATION_JSON))
        .andExpect(MockMvcResultMatchers.status().is2xxSuccessful())
        .andReturn()
        .getResponse()
        .getContentAsString();
  }

  @Test
  public void testCreateIndividual_400() throws Exception {
    String input =
        "{\"RequestId\":\"414D5120554D534242303138202020205EA83E862D7D1D87\",\"IndBncId\":\"400\",\"EventPtyAction\":\"EDIT\",\"EventTechAction\":\"CREATE\",\"EventBusinessObject\":\"BASEIND\",\"General\":{\"OrgGccNbr\":\"testOrgGcc\",\"IndGccNbr\":\"testIndGcc\",\"OrgBncId\":\"01603866C185640E83882CF387AABD18114A13D938B941C5646E24E824675930\",\"NewIndBncId\":\"testNewIndBnc\"},\"Profile\":{\"Lastname\":\"Williams\",\"Firstname\":\"Liam\",\"Birthday\":\"string\",\"Phone\":\"9057689354\",\"Email\":\"liam@gmail.com\",\"Cell\":\"4673567263\",\"Language\":\"EN\",\"Sex\":\"0\"},\"Other\":{\"IdentificationType1\":\"BELL - bellIdent012345\",\"IdentificationValue1\":\"BELL - bellIdent012345\",\"IdentificationType2\":\"BELL - bellIdent012345\",\"IdentificationValue2\":\"BELL - bellIdent012345\"}}";
    mockMvc
        .perform(post("/v1/individual")
                  .header(IndividualEventController.HERDER_TARGET_SYSTEM, TargetSystem.GCC.value)
                  .content(input)
                  .contentType(MediaType.APPLICATION_JSON))
        .andExpect(MockMvcResultMatchers.status().is4xxClientError())
        .andReturn()
        .getResponse()
        .getContentAsString();
  }

  @Test
  public void testCreateIndividual_500() throws Exception {
    String input =
        "{\"RequestId\":\"414D5120554D534242303138202020205EA83E862D7D1D87\",\"IndBncId\":\"254632gve2efe1ed322fds\",\"EventPtyAction\":\"EDIT\",\"EventTechAction\":\"CREATE\",\"EventBusinessObject\":\"BASEIND\",\"General\":{\"OrgGccNbr\":\"testOrgGcc\",\"IndGccNbr\":\"testIndGcc\",\"OrgBncId\":\"01603866C185640E83882CF387AABD18114A13D938B941C5646E24E824675930\",\"NewIndBncId\":\"testNewIndBnc\"},\"Profile\":{\"Lastname\":\"Williams\",\"Firstname\":\"Liam\",\"Birthday\":\"string\",\"Phone\":\"9057689354\",\"Email\":\"liam@gmail.com\",\"Cell\":\"4673567263\",\"Language\":\"EN\",\"Sex\":\"0\"},\"Other\":{\"IdentificationType1\":\"BELL - bellIdent012345\",\"IdentificationValue1\":\"BELL - bellIdent012345\",\"IdentificationType2\":\"BELL - bellIdent012345\",\"IdentificationValue2\":\"BELL - bellIdent012345\"}}";
    mockMvc
        .perform(post("/v1/individual")
                  .header(IndividualEventController.HERDER_TARGET_SYSTEM, TargetSystem.GCC.value)
                  .content(input)
                  .contentType(MediaType.APPLICATION_JSON))
        .andExpect(MockMvcResultMatchers.status().is5xxServerError())
        .andReturn()
        .getResponse()
        .getContentAsString();
  }
}
