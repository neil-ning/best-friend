package ca.bnc.bne.individualapi.configuration;

import static org.junit.jupiter.api.Assertions.assertEquals;

import javax.sql.DataSource;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.jdbc.core.JdbcTemplate;

@Disabled("Maybe not needed in multipel DB configuration")
class JdbcConfigurationTest {

    @Spy
    @InjectMocks
    private DataSourceGccConfiguration conf;

    @Mock
    private DataSource ds;

    @Mock
    private JdbcTemplate templateMock;

    @BeforeEach
    void setUp() {

        MockitoAnnotations.initMocks(this);
        templateMock = new JdbcTemplate(ds);
    }

    @Test
    public void jdbcTemplate() {
        //JdbcTemplate tmp = conf.jdbcTemplateGcc();
        //assertEquals(templateMock.getDataSource(),tmp.getDataSource());
    }
}