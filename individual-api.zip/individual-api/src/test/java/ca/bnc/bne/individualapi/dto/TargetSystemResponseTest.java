package ca.bnc.bne.individualapi.dto;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import ca.bnc.bne.individualapi.dto.TargetSystemResponse;

class TargetSystemResponseTest {

    @InjectMocks
    private TargetSystemResponse gccResr;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void setStatusTest() {
        gccResr.setStatus(200);
        assertEquals(200,gccResr.getStatus());
    }

    @Test
    public void setMessageTest() {
        gccResr.setMessage("test");
        assertEquals("test", gccResr.getMessage());
    }

    @Test
    public void setGccNbrTest() {
        gccResr.setTargetSystemId("12345");
        assertEquals("12345", gccResr.getTargetSystemId());
    }

    @Test
    public void setRequestIdTest() {
        gccResr.setRequestId("12345");
        assertEquals("12345", gccResr.getRequestId());
    }


}