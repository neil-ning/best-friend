package ca.bnc.bne.individualapi.exception.handler;

import ca.bnc.bne.gen.individual.IndividualResponse;
import ca.bnc.bne.individualapi.exception.model.GccErrorException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;

class GlobalExceptionHandlerTest {

    @InjectMocks
    private EventExceptionHandler globalExceptionHandler;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void handleGccErrorException() {
        final ResponseEntity<IndividualResponse> handled = globalExceptionHandler.handleGccErrorException(new GccErrorException(300,"something wrong"));
        assertEquals(HttpStatus.MULTIPLE_CHOICES,handled.getStatusCode());
        assertEquals(300, handled.getStatusCodeValue());
    }

    @Test
    void handleWrongInputException() {
        final ResponseEntity<IndividualResponse> handled = globalExceptionHandler.handleWrongInputException();
        assertEquals(HttpStatus.BAD_REQUEST, handled.getStatusCode());
        assertEquals(400, handled.getStatusCodeValue());
    }

    @Test
    void handleUnknownException() {
        final ResponseEntity<IndividualResponse> handled = globalExceptionHandler.handleUnknownException(new Exception());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, handled.getStatusCode());
        assertEquals(500, handled.getStatusCodeValue());
    }
}