package ca.bnc.bne.individualapi.service;

import ca.bnc.bne.individualapi.dto.GeneralDto;
import ca.bnc.bne.individualapi.dto.IndvReqDto;
import ca.bnc.bne.individualapi.repository.sbie.dao.Client;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlConfig;

import javax.sql.DataSource;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
@ActiveProfiles("h2")
public class IndividualServiceSbieTest {

    private static final Logger logger = LoggerFactory.getLogger(IndividualServiceSbieTest.class);

    @Autowired
    private IndividualServiceSbie srv;

    @Autowired
    @Qualifier("dataSourceSbie")
    private DataSource sbieDatasource;

    private JdbcTemplate jdbcTemplate;

    @BeforeEach
    public void initialization(){
        jdbcTemplate = new JdbcTemplate(sbieDatasource);
    }

    @Test
    @Sql(scripts = {"classpath:sbie-schema-h2.sql",
            "classpath:sbie-data-h2.sql",
            "classpath:sbie-data-test-crud-h2.sql",
            "classpath:sbie-schema-WEPROFUTIL.sql"}, config = @SqlConfig(dataSource = "dataSourceSbie", transactionManager = "transactionManagerSbie"))
    public void whenTestUpdate_TB_WEPROFUTIL_happyPath(){

        Map<String, Object> rowmap = jdbcTemplate
                .queryForMap("select WENIUB_UT, WEOFAMIL, WEOPREN, WEN_UTBNCID from TB_WEPROFUTIL where WENIUB_UT=?",
                        1);

        logger.info("query result is {}", rowmap);

        IndvReqDto dto = new IndvReqDto()
                .eventPtyAction("EDIT")
                .eventTechAction("UPDATE")
                .eventBusinessObject("BASEIND")
                .general(new GeneralDto().newIndBncId("123456").indGccNbr("1"));
        Integer rows = srv.invoke(dto);
        logger.info("invoking result is {}", rows);
        assertEquals(rows, 1);

        rowmap = jdbcTemplate
                .queryForMap("select WENIUB_UT, WEOFAMIL, WEOPREN, WEN_UTBNCID from TB_WEPROFUTIL where WENIUB_UT=?",
                        1);
        logger.info("after update result is {}", rowmap);

        assertEquals(rowmap.get("WEN_UTBNCID"), "123456");
    }

    @Test
    @Sql(scripts = {"classpath:sbie-schema-h2.sql",
            "classpath:sbie-data-h2.sql",
            "classpath:sbie-data-test-crud-h2.sql",
            "classpath:sbie-schema-WEPROFUTIL.sql"}, config = @SqlConfig(dataSource = "dataSourceSbie", transactionManager = "transactionManagerSbie"))
    public void whenTestUpdate_TB_WEPROFUTIL_badPath(){

        IndvReqDto dto = new IndvReqDto()
                .eventPtyAction("EDIT")
                .eventTechAction("UPDATE")
                .eventBusinessObject("BASEIND")
                .general(new GeneralDto().newIndBncId("123456").indGccNbr("3"));
        Integer rows = srv.invoke(dto);
        logger.info("invoking result is {}", rows);
        assertEquals(rows, 0);
    }

    @Test
    @Sql(statements = {"drop table if exists TB_WEPROFUTIL"}, config = @SqlConfig(dataSource = "dataSourceSbie", transactionManager = "transactionManagerSbie"))
    public void whenTestUpdate_TB_WEPROFUTIL_Exception(){

        IndvReqDto dto = new IndvReqDto()
                .eventPtyAction("EDIT")
                .eventTechAction("UPDATE")
                .eventBusinessObject("BASEIND")
                .general(new GeneralDto().newIndBncId("123456").indGccNbr("3"));

        assertThrows(DataAccessException.class, ()->{
            try {
                Integer rows = srv.invoke(dto);
                logger.info("invoking result is {}", rows);
            }catch (DataAccessException e){
                logger.error("update TB_WEPROFUTIL occurred exception ", e);
                throw e;
            }
        });
    }
}
