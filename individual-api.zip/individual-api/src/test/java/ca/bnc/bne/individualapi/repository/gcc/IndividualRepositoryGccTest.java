package ca.bnc.bne.individualapi.repository.gcc;

import ca.bnc.bne.gen.individual.IndividualRequest;
import ca.bnc.bne.individualapi.request.CreateTestRequest;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import javax.sql.DataSource;
import java.sql.*;
import java.util.LinkedHashMap;
import java.util.Map;

import static org.mockito.BDDMockito.*;

public class IndividualRepositoryGccTest {
    @Mock
    private SimpleJdbcCall MockSimpleJdbcCall;

    @Mock
    private JdbcTemplate jdbcTemplate;

    @InjectMocks
    private IndividualRepositoryGcc repo;

    @Mock
    private DataSource dataSource;

    @Mock
    private Connection connection;

    @Mock
    private DatabaseMetaData databaseMetaData;

    @Spy
    public CreateTestRequest req ;

    @BeforeEach
    public void setup() throws SQLException {
        MockitoAnnotations.initMocks(this);
        given(connection.getMetaData()).willReturn(databaseMetaData);
        given(dataSource.getConnection()).willReturn(connection);
    }


    @Test
    public void inputParametersTest(){
        IndividualRequest r =  req.newFullwRequest();
        LinkedHashMap<String, IndividualRepositoryGcc.ParameterWrapper> map = new LinkedHashMap<>();
        map.put("RequestId", new IndividualRepositoryGcc.ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getRequestId()));
        map.put("OrgGccNbr", new IndividualRepositoryGcc.ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getGeneral().getOrgGccNbr()));
        map.put("IndGccNbr", new IndividualRepositoryGcc.ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getGeneral().getIndGccNbr()));
        map.put("OrgBncId", new IndividualRepositoryGcc.ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getGeneral().getOrgBncId()));
        map.put("IndBncId", new IndividualRepositoryGcc.ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getIndBncId()));
        map.put("NewIndBncId", new IndividualRepositoryGcc.ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getGeneral().getNewIndBncId()));
        map.put("EventPtyAction", new IndividualRepositoryGcc.ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getEventPtyAction().toString()));
        map.put("EventTechAction", new IndividualRepositoryGcc.ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getEventPtyAction().toString()));
        map.put("EventBusinessObject", new IndividualRepositoryGcc.ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getEventBusinessObject().toString()));
        map.put("Lastname", new IndividualRepositoryGcc.ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getProfile().getLastname()));
        map.put("Firstname", new IndividualRepositoryGcc.ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getProfile().getFirstname()));
        map.put("Birthday", new IndividualRepositoryGcc.ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getProfile().getBirthday()));
        map.put("Phone", new IndividualRepositoryGcc.ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getProfile().getPhone()));
        map.put("Email", new IndividualRepositoryGcc.ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getProfile().getEmail()));
        map.put("Cell", new IndividualRepositoryGcc.ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getProfile().getCell()));
        map.put("Language", new IndividualRepositoryGcc.ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getProfile().getLanguage().toString()));
        map.put("Sex", new IndividualRepositoryGcc.ParameterWrapper().setSqlType(Types.VARCHAR).setValue(r.getProfile().getSex().toString()));
        Map<String, IndividualRepositoryGcc.ParameterWrapper> request = repo.inputParameters(r);
        assertEquals(map.keySet() ,request.keySet());
    }

    @Test
    public void outputParametersTest(){
        LinkedHashMap<String, IndividualRepositoryGcc.ParameterWrapper> map = new LinkedHashMap<>();
        map.put("status", new IndividualRepositoryGcc.ParameterWrapper().setSqlType(Types.VARCHAR));
        map.put("message", new IndividualRepositoryGcc.ParameterWrapper().setSqlType(Types.VARCHAR));
        map.put("IndGccNbrReturn", new IndividualRepositoryGcc.ParameterWrapper().setSqlType(Types.VARCHAR));
        map.put("RequestIdReturn", new IndividualRepositoryGcc.ParameterWrapper().setSqlType(Types.VARCHAR));
        Map<String, IndividualRepositoryGcc.ParameterWrapper> call = repo.outputParameter();
        assertEquals(map.keySet(), call.keySet());
    }

    public class ParameterWrapperTest {

        @InjectMocks
        private IndividualRepositoryGcc.ParameterWrapper wrapper;

        @BeforeEach
        void setUp() {
            MockitoAnnotations.initMocks(this);
            wrapper.setSqlType(Types.VARCHAR);
            wrapper.setValue("test");
        }

        @Test
        public void setSqlTypeTest() {
            assertEquals(Types.VARCHAR, wrapper.getSqlType());
        }

        @Test
        public void setValueTest() {
            assertEquals("test", wrapper.getValue());
        }
    }
}
