package ca.bnc.bne.individualapi.service;

import ca.bnc.bne.individualapi.dto.TargetSystemResponse;
import ca.bnc.bne.individualapi.exception.model.GccErrorException;
import ca.bnc.bne.individualapi.repository.gcc.IndividualRepositoryGcc;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.any;
import org.mockito.MockitoAnnotations;


public class IndividualServiceImplGccTest {

    @InjectMocks
    private IndividualServiceGcc indSer;

    @Mock
    private IndividualRepositoryGcc repo;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }



    @Test
    public void invokeTest_Success() {
        when(repo.invokeGccStoredProcedure(any())).thenReturn(new TargetSystemResponse().setStatus(200).setTargetSystemId("").setMessage("").setRequestId(""));
        TargetSystemResponse res = indSer.invoke(any());
        assertEquals(res.getStatus(), 200);
        assertNotNull(res);
    }

    @Test
    public void invokeTest_Error() {
        when(repo.invokeGccStoredProcedure(any())).thenReturn(new TargetSystemResponse().setStatus(500).setTargetSystemId("").setMessage("").setRequestId(""));
        GccErrorException thrown = assertThrows(GccErrorException.class, () -> indSer.invoke(any()));
        assertEquals(500, thrown.getGccStatus());
    }
}
