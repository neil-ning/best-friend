CREATE PROCEDURE usp_MCP_AddModifyIndividual @RequestId nvarchar(100),
                                             @OrgGccNbr nvarchar(100),
                                             @IndGccNbr nvarchar(100),
                                             @OrgBncId nvarchar(100),
                                             @IndBncId nvarchar(100),
                                             @NewIndBncId nvarchar(100),
                                             @EventPtyAction nvarchar(100),
                                             @EventTechAction nvarchar(100),
                                             @EventBusinessObject nvarchar(100),
                                             @Lastname nvarchar(100),
                                             @Firstname nvarchar(100),
                                             @Birthday nvarchar(100),
                                             @Phone nvarchar(100),
                                             @Email nvarchar(100),
                                             @Cell nvarchar(100),
                                             @Language nvarchar(100),
                                             @Sex nvarchar(100),
                                             @status nvarchar(100) OUTPUT,
                                             @message nvarchar(100) OUTPUT,
                                             @IndGccNbrReturn nvarchar(100) Output,
                                             @RequestIdReturn nvarchar(100) OUTPUT
AS
BEGIN
    SELECT @IndGccNbrReturn = '123',
           @message = 'testMessage',
           @RequestIdReturn = 'testId'

    IF @IndBncId = '200'
        SELECT @status = '200'
    ELSE
        BEGIN
            IF @IndBncId = '400'
                SELECT @status = '400'
            ELSE
                SELECT @status = '500'
        END

end;