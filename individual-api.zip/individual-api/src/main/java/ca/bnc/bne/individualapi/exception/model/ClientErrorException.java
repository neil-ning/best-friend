package ca.bnc.bne.individualapi.exception.model;


public class ClientErrorException extends RuntimeException {
  static final long serialVersionUID = 1L;

  public ClientErrorException() {
    super();
  }

  public ClientErrorException(Throwable cause) {
    super(cause);
  }

  public ClientErrorException(String message) {
    super(message);
  }

  public ClientErrorException(String message, Throwable cause) {
    super(message, cause);
  }
}
