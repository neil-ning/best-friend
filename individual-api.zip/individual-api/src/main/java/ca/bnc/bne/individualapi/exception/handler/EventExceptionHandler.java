package ca.bnc.bne.individualapi.exception.handler;

import ca.bnc.bne.gen.individual.IndividualResponse;
import ca.bnc.bne.individualapi.exception.model.GccErrorException;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@Order(Ordered.HIGHEST_PRECEDENCE)
@RestControllerAdvice(basePackages = "ca.bnc.bne.individualapi.controller.event")
public class EventExceptionHandler {

    @ExceptionHandler(GccErrorException.class)
    public ResponseEntity<IndividualResponse> handleGccErrorException(GccErrorException ex) {
        return ResponseEntity.status(ex.getGccStatus())
                .body(new IndividualResponse().code(ex.getGccStatus()).message(ex.getMessage()));
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<IndividualResponse> handleWrongInputException() {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new IndividualResponse().code(400).message("Wrong endpoint, please check EventTechAction and try again"));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<IndividualResponse> handleUnknownException(Exception ex) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new IndividualResponse().code(500).message(ex.getMessage()));
    }
}
