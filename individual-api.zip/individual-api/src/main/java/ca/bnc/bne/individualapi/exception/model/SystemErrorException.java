package ca.bnc.bne.individualapi.exception.model;

public class SystemErrorException extends RuntimeException {
  static final long serialVersionUID = 1L;

  public SystemErrorException() {
    super();
  }

  public SystemErrorException(Throwable cause) {
    super(cause);
  }

  public SystemErrorException(String message) {
    super(message);
  }

  public SystemErrorException(String message, Throwable cause) {
    super(message, cause);
  }
}
