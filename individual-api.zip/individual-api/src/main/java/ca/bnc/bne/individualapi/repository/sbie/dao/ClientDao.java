package ca.bnc.bne.individualapi.repository.sbie.dao;


public interface ClientDao {
    Client read(long id);
    int create(Client client);
    void update(Client client);
    void delete(Client client);
    boolean exist(Client client);
}