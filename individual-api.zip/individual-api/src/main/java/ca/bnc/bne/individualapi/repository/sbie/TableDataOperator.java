package ca.bnc.bne.individualapi.repository.sbie;

import org.bouncycastle.cert.ocsp.Req;

public interface TableDataOperator<T, D, R> {

    R operate(D domain);

    D convertDtoToDomain(T t);
}
