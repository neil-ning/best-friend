package ca.bnc.bne.individualapi.repository.sbie.dao.impl;

import java.sql.Types;
import javax.sql.DataSource;

import ca.bnc.bne.individualapi.repository.sbie.dao.Client;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.SqlUpdate;

public class ClientSqlUpdateSbie extends SqlUpdate {
    public ClientSqlUpdateSbie(final DataSource ds) {
        setDataSource(ds);
        setSql("update client set name = ?, age = ? where id = ?");
        declareParameter(new SqlParameter(Types.VARCHAR));
        declareParameter(new SqlParameter(Types.INTEGER));
        declareParameter(new SqlParameter(Types.BIGINT));
        compile();
    }

    public int run(final Client client) {
        Object[] params =
            new Object[] {
                client.getName(),
                client.getAge(),
                client.getId()};
        return update(params);
    }
}