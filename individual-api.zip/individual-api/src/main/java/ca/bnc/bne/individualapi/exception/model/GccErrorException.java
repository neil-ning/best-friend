package ca.bnc.bne.individualapi.exception.model;

public class GccErrorException extends RuntimeException {

    private int gccStatus;

    public GccErrorException(int status, String message) {
        super(message);
        this.gccStatus = status;
    }

    public int getGccStatus() { return gccStatus; }
}
