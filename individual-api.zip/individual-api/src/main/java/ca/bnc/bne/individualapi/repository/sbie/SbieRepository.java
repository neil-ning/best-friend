package ca.bnc.bne.individualapi.repository.sbie;

import ca.bnc.bne.individualapi.repository.sbie.TableDataOperator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository
@Transactional
public class SbieRepository implements ApplicationContextAware {

    private static final Logger LOGGER = LoggerFactory.getLogger(SbieRepository.class);

    private ApplicationContext applicationContext;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    /**
     * concrete method to invoke business logic
     *
     * @param operatorName combine
     * @param t
     * @param <T>
     * @param <D>
     * @param <R>
     * @return
     */
    public <T, D, R> R invoke(String operatorName, T t){
        // if operator does not exist, log it but do nothing
        if(!applicationContext.containsBean(operatorName)){
            LOGGER.warn("Bean named [{}] does not exist, please confirm with your developer.", operatorName);
            return null;
        }

        TableDataOperator<T, D, R> operator = applicationContext
                .getBean(operatorName, TableDataOperator.class);

        D domian = operator.convertDtoToDomain(t);

        return operator.operate(domian);
    }
}
