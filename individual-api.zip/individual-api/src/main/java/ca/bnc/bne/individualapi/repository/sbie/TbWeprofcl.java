package ca.bnc.bne.individualapi.repository.sbie;

public class TbWeprofcl {

    private String wenUtbncid;

    private Long weniubUt;

    public TbWeprofcl wenUtbncid(String wenUtbncid) {
        this.wenUtbncid = wenUtbncid;
        return this;
    }

    public TbWeprofcl weniubUt(Long weniubUt) {
        this.weniubUt = weniubUt;
        return this;
    }

    public String getWenUtbncid() {
        return wenUtbncid;
    }

    public void setWenUtbncid(String wenUtbncid) {
        this.wenUtbncid = wenUtbncid;
    }

    public Long getWeniubUt() {
        return weniubUt;
    }

    public void setWeniubUt(Long weniubUt) {
        this.weniubUt = weniubUt;
    }
}
