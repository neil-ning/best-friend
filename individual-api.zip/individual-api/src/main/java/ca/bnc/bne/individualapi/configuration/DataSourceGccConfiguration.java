package ca.bnc.bne.individualapi.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import javax.sql.DataSource;

import com.zaxxer.hikari.HikariDataSource;

@Configuration
public class DataSourceGccConfiguration {
    @Value( "${gcc.storedProcedureName}" )
    private String sp;
    
    @Bean
    @Primary
    @ConfigurationProperties("gcc.datasource")
    public DataSourceProperties dataSourcePropertiesGcc() {
        return new DataSourceProperties();
    }

    @Bean
    @Primary
    @ConfigurationProperties("gcc.datasource")
    public DataSource dataSourceGcc() {
        return dataSourcePropertiesGcc()
                .initializeDataSourceBuilder()
                .type(HikariDataSource.class)
                .build();
    }
    
    @Bean
    @Primary
    public DataSourceTransactionManager transactionManagerGcc(){
        return new DataSourceTransactionManager(dataSourceGcc());
    }
    
    @Bean
    @Primary
    public JdbcTemplate jdbcTemplateGcc() {
        return new JdbcTemplate(dataSourceGcc());
    }

    @Bean
    public SimpleJdbcCall simpleJdbcCallGcc() {
      return new SimpleJdbcCall(dataSourceGcc()).withProcedureName(sp);
    }
}
