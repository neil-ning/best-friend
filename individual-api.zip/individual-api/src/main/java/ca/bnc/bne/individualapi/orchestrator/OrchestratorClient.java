package ca.bnc.bne.individualapi.orchestrator;

import ca.bnc.bne.gen.individual.IndividualAdminResponse;
import ca.bnc.bne.gen.individual.CreateIndividualRequest;
import ca.bnc.bne.gen.individual.AddIndividualResponse;
import ca.bnc.bne.gen.individual.UpdateIndividualRequest;
import ca.bnc.bne.gen.individual.UpdateIndividualResponse;
import ca.bnc.bne.individualapi.configuration.feign.FeignConfiguration;
import ca.bnc.bne.individualapi.utils.Constants;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.SpringQueryMap;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@FeignClient(name = "orchestratorClient", url = "${bne.orchestrator.service.base-url}", configuration = FeignConfiguration.class)
public interface OrchestratorClient {
        @PatchMapping(value = Constants.REST_API_PATH_SERVICE_ADMIN)
        IndividualAdminResponse addAdmin(@SpringQueryMap Map<String, String> parameters,@RequestHeader Map<String, String> headers);

        @PostMapping(value = Constants.REST_API_PATH_SERVICE_USER)
        AddIndividualResponse addUser(@SpringQueryMap Map<String, String> parameters,@RequestHeader Map<String, String> headers,  @RequestBody CreateIndividualRequest createIndividualRequest);

        @PutMapping(value = Constants.REST_API_PATH_SERVICE_USER)
        UpdateIndividualResponse updateIndividual(@SpringQueryMap Map<String, String> parameters,@RequestHeader Map<String, String> headers, @RequestBody UpdateIndividualRequest updateIndividualRequest);

        @DeleteMapping(value = Constants.REST_API_PATH_SERVICE_USER)
        void deleteUser(@SpringQueryMap Map<String, String> parameters,@RequestHeader Map<String, String> headers);
}
