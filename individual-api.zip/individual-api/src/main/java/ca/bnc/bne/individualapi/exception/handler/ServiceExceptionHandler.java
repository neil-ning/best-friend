package ca.bnc.bne.individualapi.exception.handler;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import ca.bnc.bne.gen.individual.IndividualError;
import ca.bnc.bne.individualapi.exception.model.BackEndErrorException;
import ca.bnc.bne.individualapi.exception.model.ClientErrorException;
import ca.bnc.bne.individualapi.exception.model.SystemErrorException;

/**
 * For service controller
 * > Return 400 for bad request
 * > Return 424 for back end service interaction errors MCP/IAM/OCTA
 * > Return 500 for all other unknown errors
 *
 * Refer to swagger files for the contract
 */
@Order(Ordered.HIGHEST_PRECEDENCE)
@RestControllerAdvice(basePackages = "ca.bnc.bne.individualapi.controller.service")
public class ServiceExceptionHandler {
  private ObjectMapper objectMapper =
          new ObjectMapper()
                  .setSerializationInclusion(JsonInclude.Include.NON_EMPTY)
                  .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, true)
                  .configure(JsonParser.Feature.ALLOW_COMMENTS, true)
                  .configure(MapperFeature.USE_STD_BEAN_NAMING, true)
                  .configure(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true)
                  .configure(SerializationFeature.WRAP_ROOT_VALUE, false)
                  .configure(DeserializationFeature.UNWRAP_ROOT_VALUE, false)
                  .configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, false)
                  .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
                  .findAndRegisterModules();

  @ExceptionHandler(ClientErrorException.class)
  public ResponseEntity<IndividualError> handleInvalidResponseException(ClientErrorException ex) throws JsonProcessingException {
    return ResponseEntity.status(400).body(objectMapper.readValue(ex.getMessage(), IndividualError.class));
  }

  @ExceptionHandler(BackEndErrorException.class)
  public ResponseEntity<IndividualError> handleMcpBusinessRuleException(BackEndErrorException ex) throws JsonProcessingException {
    return ResponseEntity.status(424).body(objectMapper.readValue(ex.getMessage(), IndividualError.class));
  }

  @ExceptionHandler(SystemErrorException.class)
  public ResponseEntity<IndividualError> handleOktaTokenException(SystemErrorException ex) throws JsonProcessingException {
    return ResponseEntity.status(500).body(objectMapper.readValue(ex.getMessage(), IndividualError.class));
  }
}
