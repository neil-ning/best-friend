package ca.bnc.bne.individualapi.configuration;

import javax.sql.DataSource;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

@Configuration
public class DataSourceSbieConfiguration {
    @Bean
    @ConfigurationProperties("sbie.datasource")
    public DataSourceProperties dataSourcePropertiesSbie() {
        return new DataSourceProperties();
    }

    @Bean
    @ConfigurationProperties("sbie.datasource")
    public DataSource dataSourceSbie() {
        return dataSourcePropertiesSbie()
                .initializeDataSourceBuilder()
                .type(HikariDataSource.class)
                .build();
    }

    @Bean
    DataSourceTransactionManager transactionManagerSbie() {
        DataSourceTransactionManager manager  = new DataSourceTransactionManager(dataSourceSbie());
        return manager;
    }
}
