package ca.bnc.bne.individualapi.repository.sbie.dao.impl;

import java.sql.Types;

import javax.sql.DataSource;

import ca.bnc.bne.individualapi.repository.sbie.dao.Client;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.SqlFunction;

public class ClientSqlCountSbie extends SqlFunction<Integer>{
    public ClientSqlCountSbie(final DataSource ds){
        setDataSource(ds);
        setSql("select count(*) from client where id = ?");
        declareParameter(new SqlParameter("id", Types.BIGINT));
        compile();
    }

    public int run(final Client client) {
        return run(client.getId());
    }    
}
