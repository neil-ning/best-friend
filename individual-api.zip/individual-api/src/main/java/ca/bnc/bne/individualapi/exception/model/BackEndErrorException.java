package ca.bnc.bne.individualapi.exception.model;

public class BackEndErrorException extends RuntimeException {
  static final long serialVersionUID = 1L;

  public BackEndErrorException() {
    super();
  }

  public BackEndErrorException(Throwable cause) {
    super(cause);
  }

  public BackEndErrorException(String message) {
    super(message);
  }

  public BackEndErrorException(String message, Throwable cause) {
    super(message, cause);
  }
}
