package ca.bnc.bne.individualapi.service;

import ca.bnc.bne.gen.individual.IndividualRequest;
import ca.bnc.bne.individualapi.dto.TargetSystemResponse;
import ca.bnc.bne.individualapi.exception.model.GccErrorException;
import ca.bnc.bne.individualapi.repository.gcc.IndividualRepositoryGcc;
import org.springframework.stereotype.Service;


@Service
public class IndividualServiceGcc {

    private final IndividualRepositoryGcc individualRepository;

    public IndividualServiceGcc(IndividualRepositoryGcc individualRepository) {
        this.individualRepository = individualRepository;
    }

    /**
     *
     * @param request
     * @return
     */
    public TargetSystemResponse invoke(IndividualRequest request) {
        TargetSystemResponse gccResponse = individualRepository.invokeGccStoredProcedure(request);
        if (gccResponse.getStatus() >= 400 ) {
            throw new GccErrorException(gccResponse.getStatus(), gccResponse.getMessage());
        }
        return gccResponse;
    }


}
