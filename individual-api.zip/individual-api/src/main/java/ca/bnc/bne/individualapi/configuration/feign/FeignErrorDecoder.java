package ca.bnc.bne.individualapi.configuration.feign;

import feign.Response;
import feign.codec.ErrorDecoder;
import org.apache.commons.io.IOUtils;
import org.springframework.stereotype.Component;

import ca.bnc.bne.individualapi.exception.model.BackEndErrorException;
import ca.bnc.bne.individualapi.exception.model.ClientErrorException;
import ca.bnc.bne.individualapi.exception.model.SystemErrorException;

import java.nio.charset.StandardCharsets;

@Component
public class FeignErrorDecoder implements ErrorDecoder {

  private final ErrorDecoder defaultDecoder = new Default();

  @Override
  public Exception decode(String methodKey, Response response) {
    try {
      String errorBody = IOUtils.toString(response.body().asReader(StandardCharsets.UTF_8));
      switch (response.status()) {
        case 400:
          return new ClientErrorException(errorBody);
        case 424:
          return new BackEndErrorException(errorBody);
        case 500:
          return new SystemErrorException(errorBody);
      }
      return defaultDecoder.decode(methodKey, response);
    } catch (Exception e) {
      return new SystemErrorException(e.getMessage());
    }
  }
}
