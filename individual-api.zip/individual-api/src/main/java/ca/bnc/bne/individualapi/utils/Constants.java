package ca.bnc.bne.individualapi.utils;

public class Constants {
    public static final String REST_API_PATH_EVENT = "/v1/individual";//Aligned with Swagger definition
    public static final String REST_API_PATH_SERVICE_ADMIN = "/sbie/service/admin";//Aligned with Swagger definition
    public static final String REST_API_PATH_SERVICE_USER = "/sbie/service/user";//Aligned with Swagger definition    
}
