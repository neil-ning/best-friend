# individual-api
The repository contains the source code and documentation for Individual-api microservice developed using spring-boot.
The basic function of this API is to add/modify Individual information in GCC.


## Documentation
Discover this magnificent [wiki](https://wiki.bnc.ca/pages/viewpage.action?pageId=756289452)




